﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//game idea: enemies glide across screen, character collects coins and dodges them
//ALL CURRENTLY UNUSED ARGUMENTS AND PARAMETERS HAVE BEEN IMPLEMENTED IN CASE FUTURE DEVELOPMENT NECESSITATES THEM
namespace gameProject
{
    class Program

    {
//MAIN FUNCTION AND LOOP============================================================================================== MAIN FUNCTION AND LOOP
        static void Main(string[] args)
        {
            string patchVersion = "1.0";
            ConsoleColor borderColor = ConsoleColor.White;
            ConsoleColor screenGrassColor = ConsoleColor.White;
            ConsoleColor charForegroundColor = ConsoleColor.Green;
            ConsoleColor charBackgroundColor = ConsoleColor.Magenta;

            int enemyCount = 125;
            int coinCount = 25;
            Int32[] coinGenArrayX = new Int32[coinCount];
            Int32[] coinGenArrayY = new Int32[coinCount];
            Int32[] enemyGenArrayX = new Int32[enemyCount]; //enemy x coordinates
            int enemyYCoordProgressionState = 1;
            int enemyGenNumber = 425; //DIFFICULTY SETTING, LOWER NUMBER = FASTER ENEMIES
            int enemyGenCounter = 0;

            char myChar = '0'; //later possibly change it as user levels up
            char enemyChar = 'X';

            int roundNumber = 0;
            int maxRoundNumber = 3;
            int livesRemaining = 3;
            int coinsCollected = 0;

            int charPosX = 1; //current character position
            int charPosY = 1;
            int oldCharPosX = 0; //old character position stored
            int oldCharPosY = 0;

            int bufferSizeX = 14; //left side padding
            int bufferSizeY = 1; //top side padding

            int playAreaSizeX = 103; //right side padding
            int playAreaSizeY = 34; //bottom side padding

            int charStartingPosX = 59; //starting x coord
            int charStartingPosY = playAreaSizeY; //starting y coord
         
            bool drawEnemies = false;
            bool drawCoins = true;

            mainMenuScreen(ref playAreaSizeX, ref playAreaSizeY, ref bufferSizeX, ref bufferSizeY, ref myChar, ref enemyChar, ref charForegroundColor, ref charBackgroundColor, ref patchVersion);

            Console.CursorVisible = false;

            ConsoleKey userKeyPress;

            Console.SetCursorPosition(0, 0);
            screenBackground(borderColor, screenGrassColor, charForegroundColor, charBackgroundColor);
            bottomDisplay(ref playAreaSizeX, ref roundNumber, ref livesRemaining, ref coinsCollected, ref coinCount, ref charPosX, ref charPosY, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);

            charPosX = charStartingPosX;
            charPosY = charStartingPosY;
            Console.SetCursorPosition(charPosX, charPosY);


            do //main loop
            {
                userKeyPress = getUserKeyPress(ref charPosX, ref charPosY, ref oldCharPosX, ref oldCharPosY); //gets key input from user, stores old char pos
                                                  
                move(userKeyPress, ref charPosX, ref charPosY, ref oldCharPosX, ref oldCharPosY, ref myChar, ref playAreaSizeX, ref playAreaSizeY, ref bufferSizeX, ref bufferSizeY); //changes character coordinates depending on key press

                draw(userKeyPress, ref charPosX, ref charPosY, ref oldCharPosX, ref oldCharPosY, ref myChar, ref enemyChar, ref playAreaSizeX, ref playAreaSizeY, ref bufferSizeX, ref bufferSizeY, enemyGenArrayX, ref enemyYCoordProgressionState, coinGenArrayX, coinGenArrayY, ref drawCoins, ref drawEnemies, ref enemyCount, ref enemyGenNumber, ref enemyGenCounter, ref roundNumber, ref livesRemaining, ref coinsCollected, ref coinCount, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor); //draws everything seen on screen while in play

            } while (!checkGameOver(userKeyPress, ref playAreaSizeX, ref playAreaSizeY, ref bufferSizeX, ref bufferSizeY, ref roundNumber, ref maxRoundNumber, ref livesRemaining, ref coinsCollected, ref coinCount, ref charPosX, ref charPosY, ref oldCharPosX, ref oldCharPosY, ref charStartingPosX, ref charStartingPosY, ref enemyCount, ref enemyGenNumber, ref drawEnemies, ref drawCoins, ref enemyYCoordProgressionState, coinGenArrayX, coinGenArrayY, ref myChar, ref enemyChar, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor, ref patchVersion)); //end of main loop
            //end of main loop
        }

//MOVE FUNCTION================================================================================================== MOVE FUNCTION
        static void move(ConsoleKey dUserKeyPress, ref int dCharPosX, ref int dCharPosY, ref int dOldCharPosX, ref int dOldCharPosY, ref char dMyChar, ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY)// pass here
        {
            int charSpeed = 1; //possibly change this later

                if (dUserKeyPress == ConsoleKey.RightArrow)
                {
                    if (dCharPosX < dPlayAreaSizeX)
                    {
                        dCharPosX += charSpeed;
                    }
                    else
                    {
                        dCharPosX = dOldCharPosX;
                    }
                }

                if (dUserKeyPress == ConsoleKey.LeftArrow)
                {
                    if (dCharPosX > dBufferSizeX)
                    {
                        dCharPosX -= charSpeed;
                    }
                    else
                    {
                        dCharPosX = dOldCharPosX;
                    }

                }

                if (dUserKeyPress == ConsoleKey.UpArrow)
                {
                    if (dCharPosY > dBufferSizeY)
                    {
                        dCharPosY -= charSpeed;
                    }
                    else
                    {
                        dCharPosY = dOldCharPosY;
                    }
                }

                if (dUserKeyPress == ConsoleKey.DownArrow)
                {
                    if (dCharPosY != dPlayAreaSizeY)
                    {
                        dCharPosY += charSpeed;
                    }
                    else
                    {
                        dCharPosY = dOldCharPosY;
                    }

                }
        }//end of function

//DRAW FUNCITON================================================================================================== DRAW FUNCTION
        static void draw(ConsoleKey dUserKeyPress, ref int dCharPosX, ref int dCharPosY, ref int dOldCharPosX, ref int dOldCharPosY, ref char dMyChar, ref char dEnemyChar, ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, Int32[] enemyGenArrayX, ref int dEnemyYCoordProgressionState, Int32[] coinGenArrayX, Int32[] coinGenArrayY, ref bool dDrawCoins, ref bool dGenerateEnemies, ref int dEnemyCount, ref int dEnemyGenNumber, ref int dEnemyGenCounter, ref int dRoundNumber, ref int dLivesRemaining, ref int dCoinsCollected, ref int dCoinCount, ref ConsoleColor borderColor, ref ConsoleColor screenGrassColor, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor)
        {

            bool enemyHit; // = false;
            bool coinHit;

            if (dGenerateEnemies)
            {
                enemyGenerator(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, enemyGenArrayX, ref dEnemyYCoordProgressionState, ref dEnemyCount, ref dEnemyChar, ref dRoundNumber, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);
            }
            dGenerateEnemies = false;

            if (dDrawCoins)
            {
                coinGenerator(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, coinGenArrayX, coinGenArrayY, ref dCoinCount);
            }
            dDrawCoins = false;

            if (dEnemyGenCounter < dEnemyGenNumber)
            {
                dEnemyGenCounter++;
            }
            else
            {
                dEnemyGenCounter = 0;
            }
            
            if (dEnemyYCoordProgressionState < dPlayAreaSizeY && dEnemyGenCounter == dEnemyGenNumber) 
            {
                eraseEnemies(enemyGenArrayX, coinGenArrayX, coinGenArrayY, ref dEnemyYCoordProgressionState, ref dEnemyCount, ref dCoinCount, ref dRoundNumber, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);
                drawNewEnemies(enemyGenArrayX, ref dEnemyYCoordProgressionState, ref dEnemyCount, ref dEnemyChar, ref dRoundNumber, ref charForegroundColor, ref charBackgroundColor);
            }
            if (dEnemyYCoordProgressionState == dPlayAreaSizeY) //if enemies have reached the edge of the screen
            {
                dGenerateEnemies = true;
                dEnemyYCoordProgressionState = 1; //resets this to 1 so enemies will generate at top of screen
            }
            
            Console.SetCursorPosition(dCharPosX, dCharPosY);
            Console.ForegroundColor = charForegroundColor;
            Console.BackgroundColor = charBackgroundColor;
            Console.WriteLine(dMyChar);
            Console.BackgroundColor = ConsoleColor.Black;

            Console.CursorVisible = false; //this line is put in because when fullscreening it would glitch and become visible again.

            // if your old or old y do not match your current x, y
            //then

            if (dOldCharPosX != dCharPosX | dOldCharPosY != dCharPosY)
            {
                Console.SetCursorPosition(dCharPosX, dCharPosY);

                Console.WriteLine(dMyChar);
                // go to oldx, oldy, write screen grass

                Console.SetCursorPosition(dOldCharPosX, dOldCharPosY);
                Console.ForegroundColor = screenGrassColor;
                Console.Write(".");             //this line writes screen background
                Console.ForegroundColor = charForegroundColor;

                Console.SetCursorPosition(dCharPosX, dCharPosY);
                Console.Write(dMyChar); // put your me symbol here
                Console.BackgroundColor = ConsoleColor.Black;
            }

            //program hit detection here         
            if (dRoundNumber != 0)
            {
                enemyHit = enemyHitDetection(ref dUserKeyPress, ref dCharPosX, ref dCharPosY, ref dOldCharPosX, ref dOldCharPosY, enemyGenArrayX, ref dEnemyYCoordProgressionState, ref dEnemyCount, ref dPlayAreaSizeY, ref dEnemyGenNumber, ref dEnemyGenCounter);
                if (enemyHit)// && dEnemyGenCounter == dEnemyGenNumber)
                {
                    dLivesRemaining--;
                    bottomDisplay(ref dPlayAreaSizeX, ref dRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dCoinCount, ref dCharPosX, ref dCharPosY, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);
                    Console.Beep();
                }
            }
            coinHit = coinHitDetection(ref dCharPosX, ref dCharPosY, coinGenArrayX, coinGenArrayY, ref dCoinsCollected, ref dCoinCount);
            if (coinHit)
            {
                dCoinsCollected++;
                bottomDisplay(ref dPlayAreaSizeX, ref dRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dCoinCount, ref dCharPosX, ref dCharPosY, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);
            }
        } //end of draw

//ENEMY HIT DETECTION============================================================================================ ENEMY HIT DETECTION
        static bool enemyHitDetection(ref ConsoleKey dUserKeyPress, ref int dCharPosX, ref int dCharPosY, ref int dOldCharPosX, ref int dOldCharPosY, Int32[] enemyGenArrayX, ref int dEnemyYCoordProgressionState, ref int dEnemyCount, ref int dPlayAreaSizeY, ref int dEnemyGenNumber, ref int dEnemyGenCounter)
        {
            int arrayCounter;

            for (arrayCounter = 0; arrayCounter < dEnemyCount; arrayCounter++)
            {
                if ((dCharPosX == enemyGenArrayX[arrayCounter] && dCharPosY == dEnemyYCoordProgressionState && dEnemyGenNumber == dEnemyGenCounter ) | (dCharPosX == enemyGenArrayX[arrayCounter] && dCharPosY == dEnemyYCoordProgressionState + 1 && dCharPosY == dPlayAreaSizeY && dEnemyGenNumber == dEnemyGenCounter) | (dCharPosX == enemyGenArrayX[arrayCounter] && dUserKeyPress == ConsoleKey.UpArrow && dCharPosY == dEnemyYCoordProgressionState) | (dCharPosX == enemyGenArrayX[arrayCounter] && dUserKeyPress == ConsoleKey.DownArrow && dCharPosY == dEnemyYCoordProgressionState + 1))
                {
                    return true;
                }          
            }
            return false;
        }

//COIN HIT DETECTION============================================================================================= COIN HIT DETECTION
        static bool coinHitDetection(ref int dCharPosX, ref int dCharPosY, Int32[] coinGenArrayX, Int32[] coinGenArrayY, ref int dCoinsCollected, ref int dCoinCount)
        {
            int coinArrayCounter;

            for (coinArrayCounter = 0; coinArrayCounter < dCoinCount; coinArrayCounter++)
            {
                if (dCharPosX == coinGenArrayX[coinArrayCounter] && dCharPosY == coinGenArrayY[coinArrayCounter])
                {
                    coinGenArrayX[coinArrayCounter] = 0;
                    coinGenArrayY[coinArrayCounter] = 0;
                    return true;
                }
            }
            return false;
        }

//GET USER KEY PRESS============================================================================================ GET USER KEY PRESS
        static ConsoleKey getUserKeyPress(ref int dCharPosX, ref int dCharPosY, ref int dOldCharPosX, ref int dOldCharPosY)
        {

            ConsoleKey userInput = ConsoleKey.NoName; // reset the key
            if (Console.KeyAvailable)
            {
                userInput = Console.ReadKey(true).Key;
            }

            dOldCharPosX = dCharPosX; //remembers old X and Y to correctly redraw character
            dOldCharPosY = dCharPosY;

            return userInput;

        } //end of get user key press

//GENERATE SCREEN BACKGROUND============================================================================================ GENERATE SCREEN BACKGROUND
        static void screenBackground(ConsoleColor borderColor, ConsoleColor screenGrassColor, ConsoleColor charForegroundColor, ConsoleColor charBackgroundColor)
        {
            int numberOfBackgroundLines = 34;
            int numberOfBottomLines = 7;
            int genCounter;

            Console.ForegroundColor = borderColor;
            Console.WriteLine("######################################################################################################################");

            for (genCounter = 0; genCounter < numberOfBackgroundLines; genCounter++)
            {
                Console.ForegroundColor = borderColor; Console.Write("#            #"); Console.ForegroundColor = screenGrassColor; Console.Write(".........................................................................................."); Console.ForegroundColor = borderColor; Console.WriteLine("#            #"); Console.ForegroundColor = screenGrassColor;
            }

            Console.ForegroundColor = borderColor;
            Console.WriteLine("######################################################################################################################");

            for (genCounter = 0; genCounter < numberOfBottomLines; genCounter++)
            {
                Console.WriteLine("#                                                                                                                    #");
            }

            Console.WriteLine("######################################################################################################################");

            Console.ForegroundColor = charForegroundColor;
        }

//BOTTOM DISPLAY================================================================================================== BOTTOM DISPLAY
        static void bottomDisplay(ref int dPlayAreaSizeX, ref int dRoundNumber, ref int dLivesRemaining, ref int dCoinsCollected, ref int dMaxCoins, ref int dCharPosX, ref int dCharPosY, ref ConsoleColor borderColor, ref ConsoleColor screenGrassColor, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor)
        {
            int displayX = dPlayAreaSizeX / 2;
            int roundDisplayY = 37;
            int livesDisplayY = 39;
            int coinsDisplayY = 41;
            
            switch (dLivesRemaining)
            {
                case 3:
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case 2:
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    break;
                case 1:
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;

            }
            Console.SetCursorPosition(displayX, roundDisplayY);
            Console.WriteLine("ROUND " +dRoundNumber);
            Console.SetCursorPosition(displayX, livesDisplayY);
            Console.WriteLine("LIVES REMAINING: " +dLivesRemaining);
            Console.SetCursorPosition(displayX, coinsDisplayY);
            Console.WriteLine("COINS COLLECTED: " +dCoinsCollected+ " / " +dMaxCoins);
            Console.ForegroundColor = charForegroundColor;

            Console.SetCursorPosition(dCharPosX, dCharPosY);
        }

//GENERATE COINS=============================================================================================== GENERATE COINS
        static void coinGenerator(ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, Int32[] coinGenArrayX, Int32[] coinGenArrayY, ref int dCoinCount)
        {
            int arrayCounter;
            int randomCoord;

            Random randomX = new Random();
            for (arrayCounter = 0; arrayCounter < dCoinCount; arrayCounter++) //generates X coordinates for coins
            {
                randomCoord = randomX.Next(dBufferSizeX, dPlayAreaSizeX);
                coinGenArrayX[arrayCounter] = randomCoord;
            }

            
            for (arrayCounter = 0; arrayCounter < dCoinCount; arrayCounter++) //generates Y coordinates for coins
            {
                randomCoord = randomX.Next(dBufferSizeY, dPlayAreaSizeY);
                coinGenArrayY[arrayCounter] = randomCoord;           
            }

            drawCoins(ref dCoinCount, coinGenArrayX, coinGenArrayY);
        }
        
//DRAW COINS=====================================================================================================DRAW COINS
        static void drawCoins(ref int dCoinCount, Int32[] coinGenArrayX, Int32[] coinGenArrayY)
        {
            int arrayCounter;

            for (arrayCounter = 0; arrayCounter < dCoinCount; arrayCounter++)
            {
                Console.SetCursorPosition(coinGenArrayX[arrayCounter], coinGenArrayY[arrayCounter]);
                Console.BackgroundColor = ConsoleColor.DarkYellow;
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("o");
                Console.ResetColor();
            }
        }

//GENERATE ENEMIES================================================================================================= GENERATE ENEMIES     
        static void enemyGenerator(ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, Int32[] enemyGenArrayX, ref int dEnemyYCoordProgressionState, ref int dEnemyCount, ref char dEnemyChar, ref int dRoundNumber, ref ConsoleColor dScreenGrassColor, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor)
        {

            int enemyArrayCounter;
            int randomCoordX;

            if (dRoundNumber != 0)
            {
                Random randomX = new Random();
                for (enemyArrayCounter = 0; enemyArrayCounter < dEnemyCount; enemyArrayCounter++) //generates X coordinates for enemies
                {
                    randomCoordX = randomX.Next(dBufferSizeX, dPlayAreaSizeX + 1);

                    enemyGenArrayX[enemyArrayCounter] = randomCoordX;
                }


                for (enemyArrayCounter = 0; enemyArrayCounter < dEnemyCount; enemyArrayCounter++)
                {
                    Console.SetCursorPosition(enemyGenArrayX[enemyArrayCounter], dEnemyYCoordProgressionState);

                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write(dEnemyChar);
                    Console.ForegroundColor = charForegroundColor;
                }
                Console.SetCursorPosition(dBufferSizeX, dPlayAreaSizeY);
                Console.ForegroundColor = dScreenGrassColor;
                Console.WriteLine(".........................................................................................."); //erases old enemies at bottom of screen when a new wave is generated
            }
        }

//ERASE ENEMIES================================================================================================== ERASE ENEMIES
        static void eraseEnemies(Int32[] enemyGenArrayX, Int32[] coinGenArrayX, Int32[] coinGenArrayY, ref int dEnemyYCoordProgressionState, ref int dEnemyCount, ref int dCoinCount, ref int dRoundNumber, ref ConsoleColor screenGrassColor, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor)
        {
            int enemyArrayCounter;
            int coinArrayCounter;

            if (dRoundNumber != 0) //ensures no enemies spawn on round 0
            {
                for (enemyArrayCounter = 0; enemyArrayCounter < dEnemyCount; enemyArrayCounter++)
                {
                    Console.SetCursorPosition(enemyGenArrayX[enemyArrayCounter], dEnemyYCoordProgressionState);
                    Console.ForegroundColor = screenGrassColor;
                    Console.Write(".");
                    Console.ForegroundColor = charForegroundColor;              
                }

                for (coinArrayCounter = 0; coinArrayCounter < dCoinCount; coinArrayCounter++) //redraws coins after the enemies pass over them
                {
                    if (coinGenArrayY[coinArrayCounter] == dEnemyYCoordProgressionState)
                    {
                        Console.SetCursorPosition(coinGenArrayX[coinArrayCounter], dEnemyYCoordProgressionState);
                        Console.BackgroundColor = ConsoleColor.DarkYellow;
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("o");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Black;
                    }//end of if statement
                }//end of for loop
            }//end of if statement
        }//end of function

//DRAW NEW ENEMIES========================================================================================================== DRAW NEW ENEMIES
        static void drawNewEnemies(Int32[] enemyGenArrayX, ref int dEnemyYCoordProgressionState, ref int dEnemyCount, ref char dEnemyChar, ref int dRoundNumber, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor)
        {
            int enemyArrayCounter;

            if (dRoundNumber != 0)
            {
                dEnemyYCoordProgressionState++;

                for (enemyArrayCounter = 0; enemyArrayCounter < dEnemyCount; enemyArrayCounter++)
                {
                    Console.SetCursorPosition(enemyGenArrayX[enemyArrayCounter], dEnemyYCoordProgressionState);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write(dEnemyChar);
                    Console.ForegroundColor = charForegroundColor;
                    Console.BackgroundColor = ConsoleColor.Black;
                }
            }            
        }

//CHECK GAME OVER======================================================================================================== CHECK GAME OVER
        static bool checkGameOver(ConsoleKey dUserKeyPress, ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, ref int dRoundNumber, ref int dMaxRoundNumber, ref int dLivesRemaining, ref int dCoinsCollected, ref int dMaxCoins, ref int dCharPosX, ref int dCharPosY, ref int dOldCharPosX, ref int dOldCharPosY, ref int dCharStartingPosX, ref int dCharStartingPosY, ref int dEnemyCount, ref int dEnemyNumber, ref bool dGenerateEnemies, ref bool dGenerateCoins, ref int dEnemyYCoordProgressionState, Int32[] coinGenArrayX, Int32 [] coinGenArrayY, ref char dMyChar, ref char dEnemyChar, ref ConsoleColor borderColor, ref ConsoleColor screenGrassColor, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor, ref string patchVersion)
        {
            ConsoleKey gameOverKeyPress;
            if (dUserKeyPress == ConsoleKey.Escape) //IF USER PRESSES ESCAPE, PAUSE THE GAME
            {
                pauseScreen(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, ref dRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dMaxCoins, ref dCharPosX, ref dCharPosY, coinGenArrayX, coinGenArrayY, ref dEnemyYCoordProgressionState, ref dMyChar, ref dEnemyChar, ref dGenerateCoins, ref dGenerateCoins, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor, ref patchVersion);
            }

            if (dLivesRemaining <= 0) //IF USER RUNS OUT OF LIVES, DISPLAY GAME OVER SCREEN
            {
                gameOverKeyPress = youFuckingDied(dUserKeyPress, ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, ref dRoundNumber, ref dMaxRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dMaxCoins, ref dCharPosX, ref dCharPosY, ref dOldCharPosX, ref dOldCharPosY, ref dCharStartingPosX, ref dCharStartingPosY, ref dEnemyCount, ref dEnemyNumber, ref dGenerateEnemies, ref dGenerateCoins, ref dEnemyYCoordProgressionState, coinGenArrayX, coinGenArrayY, ref dMyChar, ref dEnemyChar, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);

                switch (gameOverKeyPress)
                {

                    case ConsoleKey.D1:
                        mainMenuScreen(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, ref dMyChar, ref dEnemyChar, ref charForegroundColor, ref charBackgroundColor, ref patchVersion);
                        dRoundNumber = 0;
                        dLivesRemaining = 3;
                        borderColor = ConsoleColor.White;
                        screenGrassColor = ConsoleColor.White;
                        screenBackground(borderColor, screenGrassColor, charForegroundColor, charBackgroundColor);
                        dCoinsCollected = 0;
                        bottomDisplay(ref dPlayAreaSizeX, ref dRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dMaxCoins, ref dCharPosX, ref dCharPosY, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);
                        dGenerateCoins = true;
                        dGenerateEnemies = false;
                        return false;

                    case ConsoleKey.D2:
                        dLivesRemaining = 3;
                        dEnemyYCoordProgressionState = 1;
                        screenBackground(borderColor, screenGrassColor, charForegroundColor, charBackgroundColor);
                        dCoinsCollected = 0;
                        bottomDisplay(ref dPlayAreaSizeX, ref dRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dMaxCoins, ref dCharPosX, ref dCharPosY, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);
                        dGenerateCoins = true;
                        dCharPosX = dCharStartingPosX;
                        dCharPosY = dCharStartingPosY;
                        return false;

                    case ConsoleKey.Escape:
                        return true; //user exits to desktop
                }//end of switch case statement
            }//end of dying if statement

            if (dCoinsCollected == dMaxCoins)             //IF USER GETS ALL COINS, CHANGE SCREEN BACKGROUND COLOR, CHANGE DIFFICULTY, PUT BACK INTO GAME, TIME COUNTER
            {
                dRoundNumber++;
                roundCompleteScreen(ref dUserKeyPress, ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, ref dMyChar, ref dEnemyChar, ref dRoundNumber, ref dMaxRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dCharPosX, ref dCharPosY, ref charForegroundColor, ref charBackgroundColor, ref patchVersion);

                dCoinsCollected = 0;
                dLivesRemaining = 3;

                switch (dRoundNumber)
                {
                    case 1:
                        borderColor = ConsoleColor.DarkBlue;
                        screenGrassColor = ConsoleColor.Cyan;
                        dEnemyNumber = 425; //difficulty, lower number = faster enemies
                        break;

                    case 2:
                        borderColor = ConsoleColor.DarkYellow;
                        screenGrassColor = ConsoleColor.Yellow;
                        dEnemyNumber = 350;
                        break;

                    case 3:
                        borderColor = ConsoleColor.DarkRed;
                        screenGrassColor = ConsoleColor.Red;                      
                        dEnemyNumber = 250;
                        break;

                    default:
                        Environment.Exit(0);
                        break;
                }
                //generate screen background and enemies for next round here
                Console.Clear();
                screenBackground(borderColor, screenGrassColor, charForegroundColor, charBackgroundColor);
                bottomDisplay(ref dPlayAreaSizeX, ref dRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dMaxCoins, ref dCharPosX, ref dCharPosY, ref borderColor, ref screenGrassColor, ref charForegroundColor, ref charBackgroundColor);

                dEnemyYCoordProgressionState = 1;
                dCharPosX = dPlayAreaSizeX / 2;
                dCharPosY = dPlayAreaSizeY;

                dGenerateEnemies = true;
                dGenerateCoins = true;
              
            }
            Console.SetCursorPosition(dOldCharPosX, dOldCharPosY);
            return false;
        } //end of check game over

//PAUSE SCREEN===================================================================================================== PAUSE SCREEN
        static void pauseScreen(ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, ref int dRoundNumber, ref int dLivesRemaining, ref int dCoinsCollected, ref int dMaxCoins, ref int dCharPosX, ref int dCharPosY, Int32[] coinGenArrayX, Int32[] coinGenArrayY, ref int dEnemyYCoordProgressionState, ref char dMyChar, ref char dEnemyChar, ref bool dGenerateCoins, ref bool dGenerateEnemies, ref ConsoleColor dBorderColor, ref ConsoleColor dScreenGrassColor, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor, ref string patchVersion)
        {
            ConsoleKey pauseScreenKeyPress = ConsoleKey.NoName;
            int colorCounter = 0;
            int blinkCounter = 0;
            int blinkCounterMax = 700;
            bool validKey = false;
            Console.Clear();
            Console.SetCursorPosition(0, dPlayAreaSizeY);
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("                             PRESS ESCAPE TO RETURN TO GAME");
            Console.WriteLine("                             PRESS M TO RETURN TO MAIN MENU");
            Console.WriteLine("                             PRESS R TO RESTART CURRENT LEVEL");
            Console.WriteLine("                             PRESS E TO EXIT TO DESKTOP");
            Console.ForegroundColor = ConsoleColor.Yellow;

            do
            {
                Console.SetCursorPosition(0, (dPlayAreaSizeY - dBufferSizeY) / 2);
                Console.WriteLine("                          ██████╗  █████╗ ███╗   ███╗███████╗    ██████╗  █████╗ ██╗   ██╗███████╗███████╗██████╗");
                Console.WriteLine("                         ██╔════╝ ██╔══██╗████╗ ████║██╔════╝    ██╔══██╗██╔══██╗██║   ██║██╔════╝██╔════╝██╔══██╗");
                Console.WriteLine("                         ██║  ███╗███████║██╔████╔██║█████╗      ██████╔╝███████║██║   ██║███████╗█████╗  ██║  ██║");
                Console.WriteLine("                         ██║   ██║██╔══██║██║╚██╔╝██║██╔══╝      ██╔═══╝ ██╔══██║██║   ██║╚════██║██╔══╝  ██║  ██║");
                Console.WriteLine("                         ╚██████╔╝██║  ██║██║ ╚═╝ ██║███████╗    ██║     ██║  ██║╚██████╔╝███████║███████╗██████╔╝");
                Console.WriteLine("                          ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝    ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚══════╝╚═════╝ ");
                if (blinkCounter == blinkCounterMax)
                {
                    blinkCounter = 0;
                    switch (colorCounter)
                    {
                        case 0:
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            colorCounter++;
                            break;

                        case 1:
                            Console.ForegroundColor = ConsoleColor.Black;
                            colorCounter = 0;
                            break;
                    }//end of switch statement
                }//end of if statement
                if (Console.KeyAvailable)
                {
                    pauseScreenKeyPress = Console.ReadKey(true).Key;

                    switch(pauseScreenKeyPress)
                    {

                        case ConsoleKey.Escape: //return to game
                            validKey = true;
                            Console.Clear();
                            break;

                        case ConsoleKey.M: //return to main menu
                            validKey = true;
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.White;
                            //reset char pos, coin count, etc
                            mainMenuScreen(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, ref dMyChar, ref dEnemyChar, ref charForegroundColor, ref charBackgroundColor, ref patchVersion);
                            dRoundNumber = 0;
                            dLivesRemaining = 3;
                            dCoinsCollected = 0;
                            dGenerateCoins = true;                            
                            dGenerateEnemies = false;
                            break;

                        case ConsoleKey.R: //restart round
                            validKey = true;
                            dLivesRemaining = 3;
                            dGenerateCoins = true;
                            dCoinsCollected = 0;
                            dCharPosX = dPlayAreaSizeX / 2;
                            dCharPosY = dPlayAreaSizeY;
                            dEnemyYCoordProgressionState = 1;
                            Console.Clear();
                            break;

                        case ConsoleKey.E: //exit to desktop
                            Environment.Exit(0);
                            break;
                    }//end of switch statement
                    
                }//end of if statement
                blinkCounter++;
            } while (!validKey);

            if (pauseScreenKeyPress == ConsoleKey.R | pauseScreenKeyPress == ConsoleKey.Escape | pauseScreenKeyPress == ConsoleKey.M)
            {
                if (pauseScreenKeyPress == ConsoleKey.M)
                {
                    dBorderColor = ConsoleColor.White;
                    dScreenGrassColor = ConsoleColor.White;
                    coinGenerator(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, coinGenArrayX, coinGenArrayY, ref dMaxCoins);
                }
                //rewrites background, bottom display, and coins when leaving pause screen
                Console.SetCursorPosition(0, 0);
                screenBackground(dBorderColor, dScreenGrassColor, charForegroundColor, charBackgroundColor);
                bottomDisplay(ref dPlayAreaSizeX, ref dRoundNumber, ref dLivesRemaining, ref dCoinsCollected, ref dMaxCoins, ref dCharPosX, ref dCharPosY, ref dBorderColor, ref dScreenGrassColor, ref charForegroundColor, ref charBackgroundColor);
                if (pauseScreenKeyPress == ConsoleKey.Escape | pauseScreenKeyPress == ConsoleKey.M) 
                {

                    drawCoins(ref dMaxCoins, coinGenArrayX, coinGenArrayY);
                    Console.SetCursorPosition(0, 0);
                    Console.ForegroundColor = dBorderColor;
                    Console.WriteLine("#");
                }
            }//end of if statement
        }//end of function

//ROUND COMPLETE SCREEN================================================================================================ROUND COMPLETE SCREEN
        static void roundCompleteScreen(ref ConsoleKey dUserKeyPress, ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, ref char dMyChar, ref char dEnemyChar, ref int dRoundNumber, ref int dMaxRoundNumber, ref int dLivesRemaining, ref int dCoinsCollected, ref int dCharPosX, ref int dCharPosY, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor, ref string patchVersion)
        {
            int timer = 3;
            int beepFrequency = 950;
            int beepDuration = 150;

            if (dRoundNumber <= dMaxRoundNumber)
            {
                do
                {
                    Console.Clear();
                    Console.SetCursorPosition(dPlayAreaSizeX / 2, dPlayAreaSizeY / 2);
                    Console.Beep(beepFrequency, beepDuration);
                    Console.Write("ROUND COMPLETE, MOVING TO ROUND " + dRoundNumber + " IN " + timer);
                    timer--;
                    System.Threading.Thread.Sleep(1000);
                } while (timer != 0);
                
                while (Console.KeyAvailable) //clears keyboard buffer so character can't move on the loading screen
                {
                    Console.ReadKey(false);
                }

            }
            else
            {
                endingScreen(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, ref dMyChar, ref dEnemyChar, ref dLivesRemaining, ref dCoinsCollected, ref charForegroundColor, ref charBackgroundColor, ref patchVersion);
            }

        }

//MENU SCREEN==========================================================================================================MENU SCREEN
        static void mainMenuScreen(ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, ref char dMyChar, ref char dEnemyChar, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor, ref string patchVersion)
        {
            ConsoleKey userKeyPress = ConsoleKey.NoName;
            int colorCounter = 0;
            Console.SetCursorPosition(0, dPlayAreaSizeY);
            Console.Write("\n                                                     HOW TO PLAY:");
            Console.Write("\n\n                                                     YOUR CHARACTER IS "); Console.ForegroundColor = charForegroundColor; Console.Write(dMyChar); Console.ResetColor();
            Console.Write("\n\n                                                     MOVE WITH THE ARROW KEYS, PRESS ESCAPE TO PAUSE");
            Console.Write("\n\n                                                     COLLECT ALL OF THE COINS "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("o"); Console.ResetColor();
            Console.Write("\n\n                                                     AVOID THE WAVES OF ENEMIES "); Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write(dEnemyChar); Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("\n\n                                                     (PLEASE FULLSCREEN AND SCROLL UP ALL THE WAY FOR THE BEST POSSIBLE EXPERIENCE)"); Console.ResetColor();
            Console.Write("\n\n                                                     PRESS ENTER TO BEGIN");
            Console.Write("\n\n                                                     OR PRESS C TO VIEW CREDITS");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n                                                       DEVELOPED BY ETHAN BRIFFETT");
            Console.WriteLine("\n                                                       ES LABS");
            Console.WriteLine("\n                                                       PRODUCED BY PROJECT DA3DALU5 PRODUCTIONS                              RELEASE " +patchVersion);
            
            do
            {

                Console.CursorVisible = false; //in case user fullscreens, it is put in the loop so the cursor remains hidden whereas without it it would get stuck on
                if (Console.KeyAvailable)
                {
                    userKeyPress = Console.ReadKey(true).Key;
                }
                colorCounter++;
                switch(colorCounter) //switch statement controls the RGB
                {
                    case 1:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        break;
                    case 2:
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;
                    case 3:
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        break;
                    case 4:
                        Console.ForegroundColor = ConsoleColor.Green;
                        break;
                    case 5:
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        break;
                    case 6:
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                        break;
                    case 7:
                        Console.ForegroundColor = ConsoleColor.DarkBlue;
                        break;
                    case 8:
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        break;
                    case 9:
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        colorCounter = 0;
                        break;
                }
                
                Console.SetCursorPosition(0, (dPlayAreaSizeY - dBufferSizeY) / 2);
                Console.WriteLine("                                  ██╗    ██╗ █████╗ ██╗   ██╗███████╗██████╗  ██████╗ ██████╗  ██████╗ ███████╗██████╗ ");
                Console.WriteLine("                                  ██║    ██║██╔══██╗██║   ██║██╔════╝██╔══██╗██╔═══██╗██╔══██╗██╔════╝ ██╔════╝██╔══██╗");
                Console.WriteLine("                                  ██║ █╗ ██║███████║██║   ██║█████╗  ██║  ██║██║   ██║██║  ██║██║  ███╗█████╗  ██████╔╝");
                Console.WriteLine("                                  ██║███╗██║██╔══██║╚██╗ ██╔╝██╔══╝  ██║  ██║██║   ██║██║  ██║██║   ██║██╔══╝  ██╔══██╗");
                Console.WriteLine("                                  ╚███╔███╔╝██║  ██║ ╚████╔╝ ███████╗██████╔╝╚██████╔╝██████╔╝╚██████╔╝███████╗██║  ██║");
                Console.WriteLine("                                   ╚══╝╚══╝ ╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═════╝  ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝");
                System.Threading.Thread.Sleep(100);
                if (userKeyPress == ConsoleKey.C)
                {
                    Console.Clear();
                    creditsScreen(ref userKeyPress, dPlayAreaSizeY, dMyChar, dEnemyChar, charForegroundColor, charBackgroundColor, patchVersion);
                }

            } while (userKeyPress != ConsoleKey.Enter);
            Console.Clear();
            roundZeroScreen(dPlayAreaSizeY, dBufferSizeY);
        } //end of function

//CREDITS SCREEN======================================================================================================== CREDITS SCREEN
        static void creditsScreen(ref ConsoleKey userKeyPress, int dPlayAreaSizeY, char dMyChar, char dEnemyChar, ConsoleColor charForegroundColor, ConsoleColor charBackgroundColor, string patchVersion)
        {
            ConsoleKey keyPress = ConsoleKey.NoName;
            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("                                                                     CREDITS");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\n\n\n\n                                                             DEVELOPER: ETHAN BRIFFETT");
            Console.WriteLine("\n\n                                                            IN ASSOCIATION WITH ES LABS");
            Console.WriteLine("\n\n                                                     PUBLISHED BY PROJECT DA3DALU5 PRODUCTIONS");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n\n\n\n                                                        SPECIAL THANKS TO MY GAME TESTERS");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\n\n                                                SENIOR BETA PLAYTESTER: "); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("ZACHARY GENEST AKA ZAITAMA");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\n\n\n                                                           TIMEWASTER DEVELOPER "); Console.ForegroundColor = ConsoleColor.Blue; Console.Write("PHIL AUBE");
            Console.WriteLine("\n\n\n                                                             TARIK BIKHANDAFNE");
            Console.WriteLine("\n\n                                                                 LARRY FAGEN");
            Console.WriteLine("\n\n                                                              ZAK GRANDMAISON");
            Console.WriteLine("\n\n                                                             VATHUSAN VIMALARAJAN");
            Console.WriteLine("\n\n                                                                 KYLE HOGUE");

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n\n\n\n\n                                                   PRESS BACKSPACE TO RETURN TO MAIN MENU");
            do
            {
                if (Console.KeyAvailable)
                {
                    keyPress = Console.ReadKey(true).Key;
                }
            } while (keyPress != ConsoleKey.Backspace);
            userKeyPress = ConsoleKey.NoName;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(0, dPlayAreaSizeY); //redraws the how to play instructions upon returning from credits
            Console.Write("\n                                                     HOW TO PLAY:");
            Console.Write("\n\n                                                     YOUR CHARACTER IS "); Console.ForegroundColor = charForegroundColor; Console.Write(dMyChar); Console.ResetColor();
            Console.Write("\n\n                                                     MOVE WITH THE ARROW KEYS, PRESS ESCAPE TO PAUSE");
            Console.Write("\n\n                                                     COLLECT ALL OF THE COINS "); Console.ForegroundColor = ConsoleColor.Yellow; Console.Write("o"); Console.ResetColor();
            Console.Write("\n\n                                                     AVOID THE WAVES OF ENEMIES "); Console.ForegroundColor = ConsoleColor.DarkRed; Console.Write(dEnemyChar); Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("\n\n                                                     (PLEASE FULLSCREEN AND SCROLL UP ALL THE WAY FOR THE BEST POSSIBLE EXPERIENCE)"); Console.ResetColor();
            Console.Write("\n\n                                                     PRESS ENTER TO BEGIN");
            Console.Write("\n\n                                                     OR PRESS C TO VIEW CREDITS");
            Console.WriteLine("\n\n\n\n\n\n\n\n\n\n\n                                                       DEVELOPED BY ETHAN BRIFFETT");
            Console.WriteLine("\n                                                       ES LABS");
            Console.WriteLine("\n                                                       PRODUCED BY PROJECT DA3DALU5 PRODUCTIONS                              RELEASE " + patchVersion);
        }//end of function

//ROUND ZERO SCREEN===================================================================================================== ROUND ZERO SCREEN
        static void roundZeroScreen(int dPlayAreaSizeY, int dBufferSizeY)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.SetCursorPosition(0, (dPlayAreaSizeY - dBufferSizeY) / 2);
            Console.WriteLine("                                                        ROUND 0");
            System.Threading.Thread.Sleep(1500);
            while (Console.KeyAvailable) //clears keyboard buffer so character can't move on the loading screen
            {
                Console.ReadKey(false);
            }
        }
//YOU FUCKING DIED SCREEN=============================================================================================== YOU FUCKING DIED SCREEN
        static ConsoleKey youFuckingDied(ConsoleKey dUserKeyPress, ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, ref int dRoundNumber, ref int dMaxRoundNumber, ref int dLivesRemaining, ref int dCoinsCollected, ref int dMaxCoins, ref int dCharPosX, ref int dCharPosY, ref int dOldCharPosX, ref int dOldCharPosY, ref int dCharStartingPosX, ref int dCharStartingPosY, ref int dEnemyCount, ref int dEnemyNumber, ref bool dGenerateEnemies, ref bool dGenerateCoins, ref int dEnemyYCoordProgressionState, Int32[] coinGenArrayX, Int32[] coinGenArrayY, ref char dMyChar, ref char dEnemyChar, ref ConsoleColor borderColor, ref ConsoleColor screenGrassColor, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor) //unused parameters may be used in future development
        {
            bool validKey = false;
            int colorCounter = 0;
            int blinkCounter = 0;
            int blinkCounterMax = 600;
            ConsoleKey userNumPress = ConsoleKey.NoName;

            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.SetCursorPosition(0, dPlayAreaSizeY);
            Console.WriteLine("                                                     PRESS 1 TO RETURN TO MAIN MENU");
            Console.WriteLine("                                                     PRESS 2 TO RESTART CURRENT ROUND");
            Console.WriteLine("                                                     PRESS ESCAPE TO EXIT GAME");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            do
            {
                Console.SetCursorPosition(0, (dPlayAreaSizeY - dBufferSizeY) / 2);
                Console.WriteLine("                     ██╗   ██╗ ██████╗ ██╗   ██╗    ███████╗██╗   ██╗ ██████╗██╗  ██╗██╗███╗   ██╗ ██████╗     ██████╗ ██╗███████╗██████╗");
                Console.WriteLine("                     ╚██╗ ██╔╝██╔═══██╗██║   ██║    ██╔════╝██║   ██║██╔════╝██║ ██╔╝██║████╗  ██║██╔════╝     ██╔══██╗██║██╔════╝██╔══██╗");
                Console.WriteLine("                      ╚████╔╝ ██║   ██║██║   ██║    █████╗  ██║   ██║██║     █████╔╝ ██║██╔██╗ ██║██║  ███╗    ██║  ██║██║█████╗  ██║  ██║");
                Console.WriteLine("                       ╚██╔╝  ██║   ██║██║   ██║    ██╔══╝  ██║   ██║██║     ██╔═██╗ ██║██║╚██╗██║██║   ██║    ██║  ██║██║██╔══╝  ██║  ██║");
                Console.WriteLine("                        ██║   ╚██████╔╝╚██████╔╝    ██║     ╚██████╔╝╚██████╗██║  ██╗██║██║ ╚████║╚██████╔╝    ██████╔╝██║███████╗██████╔╝");
                Console.WriteLine("                        ╚═╝    ╚═════╝  ╚═════╝     ╚═╝      ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝     ╚═════╝ ╚═╝╚══════╝╚═════╝");

                if (blinkCounter == blinkCounterMax)
                {
                    blinkCounter = 0;
                    switch (colorCounter)
                    {
                        case 0:
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            colorCounter++;
                            break;
                        case 1:
                            Console.ForegroundColor = ConsoleColor.Black;
                            colorCounter = 0;
                            break;
                    }//end of switch statement
                }//end of if statement
                if (Console.KeyAvailable)
                {
                    userNumPress = Console.ReadKey(true).Key;
                    if (userNumPress == ConsoleKey.D1 | userNumPress == ConsoleKey.D2 | userNumPress == ConsoleKey.Escape)
                    {
                        validKey = true;
                    }
                    
                }//end of if statement
                blinkCounter++;
            } while (!validKey); //end of loop
            Console.ResetColor();
            Console.Clear();
            return userNumPress;
        }//end of function 
//ENDING SCREEN=========================================================================================================ENDING SCREEN
        static void endingScreen(ref int dPlayAreaSizeX, ref int dPlayAreaSizeY, ref int dBufferSizeX, ref int dBufferSizeY, ref char dMyChar, ref char dEnemyChar, ref int dLivesRemaining, ref int dCoinsCollected, ref ConsoleColor charForegroundColor, ref ConsoleColor charBackgroundColor, ref string patchVersion)
        {
            ConsoleKey userKeyPress = ConsoleKey.NoName;
            int colorCounter = 0;

            Console.Clear();

            do
            {

                Console.CursorVisible = false;
                if (Console.KeyAvailable)
                {
                    userKeyPress = Console.ReadKey(true).Key;
                }
                colorCounter++;
                switch (colorCounter)
                {
                    case 1:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        break;
                    case 2:
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;
                    case 3:
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        break;
                    case 4:
                        Console.ForegroundColor = ConsoleColor.Green;
                        break;
                    case 5:
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        break;
                    case 6:
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                        break;
                    case 7:
                        Console.ForegroundColor = ConsoleColor.DarkBlue;
                        break;
                    case 8:
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        break;
                    case 9:
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        colorCounter = 0;
                        break;
                }
                Console.SetCursorPosition(0, (dPlayAreaSizeY - dBufferSizeY) / 2);
                Console.WriteLine(" ██████╗ ██████╗ ███╗   ██╗ ██████╗ ██████╗  █████╗ ████████╗██╗   ██╗██╗      █████╗ ████████╗██╗ ██████╗ ███╗   ██╗███████╗    ██╗");
                Console.WriteLine("██╔════╝██╔═══██╗████╗  ██║██╔════╝ ██╔══██╗██╔══██╗╚══██╔══╝██║   ██║██║     ██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║██╔════╝    ██║");
                Console.WriteLine("██║     ██║   ██║██╔██╗ ██║██║  ███╗██████╔╝███████║   ██║   ██║   ██║██║     ███████║   ██║   ██║██║   ██║██╔██╗ ██║███████╗    ██║");
                Console.WriteLine("██║     ██║   ██║██║╚██╗██║██║   ██║██╔══██╗██╔══██║   ██║   ██║   ██║██║     ██╔══██║   ██║   ██║██║   ██║██║╚██╗██║╚════██║    ╚═╝");
                Console.WriteLine("╚██████╗╚██████╔╝██║ ╚████║╚██████╔╝██║  ██║██║  ██║   ██║   ╚██████╔╝███████╗██║  ██║   ██║   ██║╚██████╔╝██║ ╚████║███████║    ██╗");
                Console.WriteLine(" ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝    ╚═╝");
                Console.WriteLine("\nYOU ARE ONE OF THE VERY FEW PEOPLE TO HAVE ACTUALLY BEATEN THIS GAME! AND ONE OF THE FEW WHO DIDN'T RAGEQUIT AFTER ROUND 1!");
                Console.WriteLine("\nAND FOR THAT, YOU ARE TRULY AMAZING!");
                Console.WriteLine("\nPRESS ESCAPE TO QUIT TO DESKTOP!");
                System.Threading.Thread.Sleep(100);

            } while (userKeyPress != ConsoleKey.Escape);

            //in case of future development

/*          Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            mainMenuScreen(ref dPlayAreaSizeX, ref dPlayAreaSizeY, ref dBufferSizeX, ref dBufferSizeY, ref dMyChar, ref dEnemyChar, ref charForegroundColor, ref charBackgroundColor, ref patchVersion);
*/            

        }//end of function
    } //end of class 
} //end of namespace