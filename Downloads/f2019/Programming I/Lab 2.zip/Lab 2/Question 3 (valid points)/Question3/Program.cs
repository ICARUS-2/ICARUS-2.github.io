﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    class Program
    {
        static void Main(string[] args)
        {
            double points;
            int validPointScore;
            double lowPoints;
            double highPoints;

            validPointScore = 0;
            lowPoints = 9;
            highPoints = 51;

            bool isnum;

            do
            {
                do
                {
                    Console.WriteLine("Please enter the number of points");
                    isnum = double.TryParse(Console.ReadLine(), out points);

                    if (!isnum)
                    {
                        Console.WriteLine("Error: Input must be a number");
                    }

                } while (!isnum);
                
                if (points >= lowPoints && points <= highPoints)
                {
                    Console.WriteLine("Valid Points");
                    Console.WriteLine();
                    validPointScore = validPointScore + 1;
                }
                else
                {
                    Console.WriteLine("Invalid Points");
                    Console.WriteLine();
                }

            }
            while (points != 100);

            Console.WriteLine("Valid points were entered " + validPointScore + " times");
            Console.ReadLine();
              
            
        }
    }
}
