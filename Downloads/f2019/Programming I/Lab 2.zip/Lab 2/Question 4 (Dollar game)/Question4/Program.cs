﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question4
{
    class Program
    {
        static void Main(string[] args)
        {
            int pennyNumber;
            int nickelNumber;
            int dimeNumber;
            int quarterNumber;
            int turns;

            double pennyValue;
            double nickelValue;
            double dimeValue;
            double quarterValue;
            double total;

            bool isnum;

            turns = 0;

            Console.WriteLine("You must enter an amount of pennies, nickels, dimes, and quarters. To win, the coins must total 1$");
            Console.WriteLine();
            do
            {
                total = 0;

                do
                {
                    Console.WriteLine("Please enter the number of pennies");
                    isnum = Int32.TryParse(Console.ReadLine(), out pennyNumber);

                    if (!isnum | pennyNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (pennyNumber < 0 | !isnum);

                isnum = false;

                do
                {

                    Console.WriteLine("Please enter the number of nickels");
                    isnum = Int32.TryParse(Console.ReadLine(), out nickelNumber);

                    if (!isnum | nickelNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (nickelNumber < 0 | !isnum);

                isnum = false;

                do
                {
                    Console.WriteLine("Please enter the number of dimes");
                    isnum = Int32.TryParse(Console.ReadLine(), out dimeNumber);

                    if (!isnum | dimeNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (dimeNumber < 0 | !isnum);

                isnum = false;

                do
                {
                    Console.WriteLine("Please enter the number of quarters");
                    isnum = Int32.TryParse(Console.ReadLine(), out quarterNumber);

                    if (!isnum | quarterNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (quarterNumber < 0 | !isnum);

                //all inputs validated

                pennyValue = pennyNumber * 0.01;
                nickelValue = nickelNumber * 0.05;
                dimeValue = dimeNumber * 0.10;
                quarterValue = quarterNumber * 0.25;

                total = pennyValue + nickelValue + dimeValue + quarterValue;

                turns = turns + 1;

                if (total == 1)
                {
                    //continue to end
                }
                else
                {
                    if (total > 1)
                    {
                        Console.WriteLine("The total calculated amount was more than 1$. Please try again");
                    }
                    else
                    {
                        Console.WriteLine("The total calculated amount was less than 1$, please try again");
                    }
                }



            }
            while (total != 1);

            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Magenta;

            Console.WriteLine("Congratulations! It took you " + turns + " turns to win!");
            Console.WriteLine();

            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Press any key to exit");

            Console.ReadKey();
              
        }
    }
}
