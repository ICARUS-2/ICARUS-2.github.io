﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int guess;
            int turns;
            int maxNumber = 100;


            Random random = new Random();
            int numberGenerated = random.Next(1,maxNumber);

            bool isnum;

            Console.WriteLine("I am thinking of an integer between 1 and 100, what is the number?");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            turns = 0;

            do
            {
                do
                {

                    Console.WriteLine("Type your guess");
                    //guess = Convert.ToInt32(Console.ReadLine());
                    isnum = Int32.TryParse(Console.ReadLine(), out guess);

                    if (!isnum | guess < 1 | guess > maxNumber)
                    {
                        Console.WriteLine("Error: Input must be an integer between 1 and 100");
                    }

                } while (!isnum | guess < 1 | guess > maxNumber);


                turns = turns + 1;

                if (guess == numberGenerated)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine();
                    Console.WriteLine("You have correctly guessed the number!");
                    Console.WriteLine();
                    Console.WriteLine();
                }
                else
                {
                    if (guess > numberGenerated)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine();
                        Console.WriteLine("Your guess was too high! Please try again!");
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine();
                        Console.WriteLine("Your guess was too low! Please try again!");
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }

            }
            while (guess != numberGenerated);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("You took " + turns + " tries to guess the correct number");
            Console.ReadLine();
        }
    }
}
