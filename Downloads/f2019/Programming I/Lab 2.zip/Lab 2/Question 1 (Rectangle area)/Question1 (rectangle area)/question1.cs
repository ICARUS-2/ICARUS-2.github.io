﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1__rectangle_area_
{
    class question1
    {
        static void Main(string[] args)
        {
            //user inputs here
            double length1;
            double width1;
            double length2;
            double width2;

            //stores area calculations
            double area1;
            double area2;

            //checks if input is number
            bool isnum;

            Console.WriteLine("This program will take the lengths and widths of two rectangles, calculate their areas,");
            Console.WriteLine("and will tell you which one has the larger area, or if the two are equal in size.");
            Console.WriteLine();

            do
            {
                Console.WriteLine("Please enter the length of the first rectangle");

                isnum = double.TryParse(Console.ReadLine(), out length1);

                Console.Clear();

                if (!isnum | length1 <0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum|| length1 < 0);


            Console.Clear(); //resets isnum and console
            isnum = false;

            do
            {
                Console.WriteLine("Please enter the width of the first rectangle");

                isnum = double.TryParse(Console.ReadLine(), out width1);

                Console.Clear();

                if (!isnum | width1 < 0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum || width1 < 0);


            Console.Clear(); //resets isnum and console
            isnum = false;



            do
            {
                Console.WriteLine("Please enter the length of the second rectangle");

                isnum = double.TryParse(Console.ReadLine(), out length2);

                Console.Clear();

                if (!isnum | length2 < 0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum || length2 < 0);

            Console.Clear();
            isnum = false;

            do
            {
                Console.WriteLine("Please enter the width of the second rectangle");

                isnum = double.TryParse(Console.ReadLine(), out width2);

                Console.Clear();

                if (!isnum | width2 < 0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum || width2 < 0);

            area1 = (length1 * width1);
            area2 = (length2 * width2);

            Console.WriteLine("The first rectangle has an area of " + area1 + " units squared");
            Console.WriteLine();
            Console.WriteLine("The second rectangle has an area of " + area2 + " units squared");
            Console.WriteLine();

            if (area1 > area2)
            {
                Console.WriteLine("Rectangle 1 has a greater area than rectangle 2");
                Console.ReadLine();
            }
            else if (area1 == area2)
            {
                Console.WriteLine("Rectangles 1 and 2 have the same area");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Rectangle 2 has a greater area than rectangle 1");
                Console.ReadLine();
            }

        }
    }
}
