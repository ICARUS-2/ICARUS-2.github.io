﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question5
{
    class Program
    {
        static void Main(string[] args)
        {
            string nameInput;
            double ageInput;
            string maxName;     //name of oldest person
            double maxAge;  //age of oldest person

            bool isnum;

           
            
            Console.WriteLine("Please enter a person's name"); //user enters name
            nameInput = Console.ReadLine();

            do
            {
                Console.WriteLine("Please enter the age of that person"); //user enters age
                isnum = double.TryParse(Console.ReadLine(), out ageInput);

                if (!isnum | ageInput <= 0)
                {
                    Console.WriteLine("Error: Input must be a number higher than 0");
                }

            } while (!isnum | ageInput <= 0);


            maxName = nameInput;
            maxAge = ageInput;

            // does once, guarantees a maximum age and a name associated

            do
            {

                Console.WriteLine("Please enter another person's name");
                nameInput = Console.ReadLine();

                if (nameInput != "end")
                {

                    do
                    {

                        Console.WriteLine("Now enter the age of that person");
                        isnum = double.TryParse(Console.ReadLine(), out ageInput);

                        if (!isnum | ageInput <= 0)
                        {
                            Console.WriteLine("Error: Input must be a number higher than 0");
                        }


                    } while (!isnum | ageInput <= 0);

                    if (ageInput > maxAge) 
                    {
                        maxAge = ageInput;
                        maxName = nameInput;
                    }



                }


            }
            while (nameInput != "end");

            Console.WriteLine("The oldest person was " + maxName + " at " + maxAge + " years old");
            Console.ReadLine();

        
           
        }
    }
}
