﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            double firstNumber;
            double secondNumber;
            double thirdNumber;

            double maxNumber = 100;

            bool isnum;


            Console.WriteLine("This program will take three numbers between 1 and 100 and then output the largest one");
            Console.WriteLine();

            //input 1

            do
            {
                Console.WriteLine("Please enter your first number");
                isnum = double.TryParse(Console.ReadLine(), out firstNumber);

                if (!isnum | firstNumber < 1 | firstNumber > maxNumber)
                {
                    Console.WriteLine("Error: Input must be a number between 1 and 100");                    
                }

            } while (!isnum || firstNumber < 1 | firstNumber > maxNumber);

            Console.Clear();
            isnum = false;

            //input 2

            do
            {
                Console.WriteLine("Please enter your second number");
                isnum = double.TryParse(Console.ReadLine(), out secondNumber);

                if (!isnum | secondNumber < 1 | secondNumber > maxNumber)
                {
                    Console.WriteLine("Error: Input must be a number between 1 and 100");
                }

            } while (!isnum || secondNumber < 1 | secondNumber > maxNumber);

            Console.Clear();
            isnum = false;

            //input 3

            do
            {
                Console.WriteLine("Please enter your third number");
                isnum = double.TryParse(Console.ReadLine(), out thirdNumber);

                if (!isnum | thirdNumber < 1 | thirdNumber > maxNumber)
                {
                    Console.WriteLine("Error: Input must be a number between 1 and 100");
                }

            } while (!isnum || thirdNumber < 1 | thirdNumber > maxNumber);

            Console.Clear();
            isnum = false;

            if (thirdNumber >= 1 && thirdNumber <= 100)
            {
                //output determination when inputs successful

                if (firstNumber >= secondNumber && firstNumber >= thirdNumber)
                {
                    Console.WriteLine("The largest number entered was " + firstNumber);
                    Console.ReadLine();
                }
                else if (secondNumber >= firstNumber && secondNumber >= thirdNumber)
                {
                    Console.WriteLine("The largest number entered was " + secondNumber);
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("The largest number entered was " + thirdNumber);
                    Console.ReadLine();
                }




            }

            }
    }
}
