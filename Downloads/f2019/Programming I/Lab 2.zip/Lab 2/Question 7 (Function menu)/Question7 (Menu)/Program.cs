﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question7__Menu_
{
    class Program
    {
        static void Main(string[] args)
        {

            int numberSelected;

            bool isnum;

            do
            {
                Console.Clear();
                Console.WriteLine();
                Console.WriteLine("1 - Area of Rectangles");
                Console.WriteLine();
                Console.WriteLine("2 - Biggest Number");
                Console.WriteLine();
                Console.WriteLine("3 - Valid Points");
                Console.WriteLine();
                Console.WriteLine("4 - Dollar Game");
                Console.WriteLine();
                Console.WriteLine("5 - Oldest Person");
                Console.WriteLine();
                Console.WriteLine("6 - Hi-Lo Game (Random Number)");
                Console.WriteLine();
                Console.WriteLine("7 - Exit Menu");
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Please enter your choice");

                do
                {
                    isnum = Int32.TryParse(Console.ReadLine(), out numberSelected);

                    if (!isnum | numberSelected < 1| numberSelected > 7)
                    {
                        {
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("Error: Input must be a whole number between 1 and 7 inclusive");
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.WriteLine();
                        }

                    }


                } while (!isnum | numberSelected < 1 | numberSelected > 7);

                Console.Clear();

                    switch (numberSelected)
                    {
                        case 1:
                            RectangleArea();
                            Console.Clear();
                            break;

                        case 2:
                            BiggestNumber();
                            Console.Clear();
                            break;

                        case 3:
                            ValidPoints();
                            Console.Clear();
                            break;

                        case 4:
                            DollarGame();
                            Console.Clear();
                            break;

                        case 5:
                            OldestPerson();
                            Console.Clear();
                            break;

                        case 6:
                            RandomNumber();
                            Console.Clear();
                            break;

                            
                    }



            }
            while (numberSelected != 7);

        }

        static void RectangleArea() //question 1 - rectangle area
        {
            //user inputs here
            double length1;
            double width1;
            double length2;
            double width2;

            //stores area calculations
            double area1;
            double area2;

            //checks if input is number
            bool isnum;

            Console.WriteLine("This program will take the lengths and widths of two rectangles, calculate their areas,");
            Console.WriteLine("and will tell you which one has the larger area, or if the two are equal in size.");
            Console.WriteLine();

            do
            {
                Console.WriteLine("Please enter the length of the first rectangle");

                isnum = double.TryParse(Console.ReadLine(), out length1);

                Console.Clear();

                if (!isnum | length1 < 0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum || length1 < 0);


            Console.Clear(); //resets isnum and console
            isnum = false;

            do
            {
                Console.WriteLine("Please enter the width of the first rectangle");

                isnum = double.TryParse(Console.ReadLine(), out width1);

                Console.Clear();

                if (!isnum | width1 < 0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum || width1 < 0);


            Console.Clear(); //resets isnum and console
            isnum = false;



            do
            {
                Console.WriteLine("Please enter the length of the second rectangle");

                isnum = double.TryParse(Console.ReadLine(), out length2);

                Console.Clear();

                if (!isnum | length2 < 0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum || length2 < 0);

            Console.Clear();
            isnum = false;

            do
            {
                Console.WriteLine("Please enter the width of the second rectangle");

                isnum = double.TryParse(Console.ReadLine(), out width2);

                Console.Clear();

                if (!isnum | width2 < 0)
                {
                    Console.WriteLine("Error: Input must be a number greater than 0");
                }


            } while (!isnum || width2 < 0);

            area1 = (length1 * width1);
            area2 = (length2 * width2);

            Console.WriteLine("The first rectangle has an area of " + area1 + " units squared");
            Console.WriteLine();
            Console.WriteLine("The second rectangle has an area of " + area2 + " units squared");
            Console.WriteLine();

            if (area1 > area2)
            {
                Console.WriteLine("Rectangle 1 has a greater area than rectangle 2");
                Console.WriteLine();
                Console.WriteLine("Press enter to continue");
                Console.ReadLine();
            }
            else if (area1 == area2)
            {
                Console.WriteLine("Rectangles 1 and 2 have the same area");
                Console.WriteLine();
                Console.WriteLine("Press enter to continue");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Rectangle 2 has a greater area than rectangle 1");
                Console.WriteLine();
                Console.WriteLine("Press enter to continue");
                Console.ReadLine();
            }
        }

        static void BiggestNumber() //question 2 - biggest number
        {
            double firstNumber;
            double secondNumber;
            double thirdNumber;

            double maxNumber = 100;

            bool isnum;


            Console.WriteLine("This program will take three numbers between 1 and 100 and then output the largest one");
            Console.WriteLine();

            //input 1

            do
            {
                Console.WriteLine("Please enter your first number");
                isnum = double.TryParse(Console.ReadLine(), out firstNumber);

                if (!isnum | firstNumber < 1 | firstNumber > maxNumber)
                {
                    Console.WriteLine("Error: Input must be a number between 1 and 100");
                }

            } while (!isnum || firstNumber < 1 | firstNumber > maxNumber);

            Console.Clear();
            isnum = false;

            //input 2

            do
            {
                Console.WriteLine("Please enter your second number");
                isnum = double.TryParse(Console.ReadLine(), out secondNumber);

                if (!isnum | secondNumber < 1 | secondNumber > maxNumber)
                {
                    Console.WriteLine("Error: Input must be a number between 1 and 100");
                }

            } while (!isnum || secondNumber < 1 | secondNumber > maxNumber);

            Console.Clear();
            isnum = false;

            //input 3

            do
            {
                Console.WriteLine("Please enter your third number");
                isnum = double.TryParse(Console.ReadLine(), out thirdNumber);

                if (!isnum | thirdNumber < 1 | thirdNumber > maxNumber)
                {
                    Console.WriteLine("Error: Input must be a number between 1 and 100");
                }

            } while (!isnum || thirdNumber < 1 | thirdNumber > maxNumber);

            Console.Clear();
            isnum = false;

            if (thirdNumber >= 1 && thirdNumber <= 100)
            {
                //output determination when inputs successful

                if (firstNumber >= secondNumber && firstNumber >= thirdNumber)
                {
                    Console.WriteLine("The largest number entered was " + firstNumber);
                    Console.WriteLine();
                    Console.WriteLine("Press enter to continue");
                    Console.ReadLine();
                }
                else if (secondNumber >= firstNumber && secondNumber >= thirdNumber)
                {
                    Console.WriteLine("The largest number entered was " + secondNumber);
                    Console.WriteLine();
                    Console.WriteLine("Press enter to continue");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("The largest number entered was " + thirdNumber);
                    Console.WriteLine();
                    Console.WriteLine("Press enter to continue");
                    Console.ReadLine();
                }
            }
        }

        static void ValidPoints() //question 3 - valid points
        {
            double points;
            int validPointScore;
            double lowPoints;
            double highPoints;

            validPointScore = 0;
            lowPoints = 9;
            highPoints = 51;

            bool isnum;

            do
            {
                do
                {
                    Console.WriteLine("Please enter the number of points");
                    isnum = double.TryParse(Console.ReadLine(), out points);

                    if (!isnum)
                    {
                        Console.WriteLine("Error: Input must be a number");
                    }

                } while (!isnum);

                if (points >= lowPoints && points <= highPoints)
                {
                    Console.WriteLine("Valid Points");
                    Console.WriteLine();
                    validPointScore = validPointScore + 1;
                }
                else
                {
                    Console.WriteLine("Invalid Points");
                    Console.WriteLine();
                }

            }
            while (points != 100);

            Console.WriteLine("Valid points were entered " + validPointScore + " times");
            Console.WriteLine();
            Console.WriteLine("Press enter to continue");
            Console.ReadLine();
        }

        static void DollarGame() //question 4 - dollar game
        {
            int pennyNumber;
            int nickelNumber;
            int dimeNumber;
            int quarterNumber;
            int turns;

            double pennyValue;
            double nickelValue;
            double dimeValue;
            double quarterValue;
            double total;

            bool isnum;

            turns = 0;

            Console.WriteLine("You must enter an amount of pennies, nickels, dimes, and quarters. To win, the coins must total 1$");
            Console.WriteLine();
            do
            {
                total = 0;

                do
                {
                    Console.WriteLine("Please enter the number of pennies");
                    isnum = Int32.TryParse(Console.ReadLine(), out pennyNumber);

                    if (!isnum | pennyNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (pennyNumber < 0 | !isnum);

                isnum = false;

                do
                {

                    Console.WriteLine("Please enter the number of nickels");
                    isnum = Int32.TryParse(Console.ReadLine(), out nickelNumber);

                    if (!isnum | nickelNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (nickelNumber < 0 | !isnum);

                isnum = false;

                do
                {
                    Console.WriteLine("Please enter the number of dimes");
                    isnum = Int32.TryParse(Console.ReadLine(), out dimeNumber);

                    if (!isnum | dimeNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (dimeNumber < 0 | !isnum);

                isnum = false;

                do
                {
                    Console.WriteLine("Please enter the number of quarters");
                    isnum = Int32.TryParse(Console.ReadLine(), out quarterNumber);

                    if (!isnum | quarterNumber < 0)
                        Console.WriteLine("Error: Input can only be an integer");

                }
                while (quarterNumber < 0 | !isnum);

                //all inputs validated

                pennyValue = pennyNumber * 0.01;
                nickelValue = nickelNumber * 0.05;
                dimeValue = dimeNumber * 0.10;
                quarterValue = quarterNumber * 0.25;

                total = pennyValue + nickelValue + dimeValue + quarterValue;

                turns = turns + 1;

                if (total == 1)
                {
                    //continue to end
                }
                else
                {
                    if (total > 1)
                    {
                        Console.WriteLine("The total calculated amount was more than 1$. Please try again");
                    }
                    else
                    {
                        Console.WriteLine("The total calculated amount was less than 1$, please try again");
                    }
                }



            }
            while (total != 1);

            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Magenta;

            Console.WriteLine("Congratulations! It took you " + turns + " turns to win!");
            Console.WriteLine();

            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Press any key to exit");
            Console.BackgroundColor = ConsoleColor.Black;

            Console.ReadKey();
        }

        static void OldestPerson() //question 5 - oldest person
        {
            string nameInput;
            double ageInput;
            string maxName;     //name of oldest person
            double maxAge;  //age of oldest person

            bool isnum;

            Console.WriteLine("Program requires you to repeatedly enter people's names and ages. Once end is entered, oldest person and age will be displayed");
            Console.WriteLine();
            Console.WriteLine("Please enter a person's name"); //user enters name
            nameInput = Console.ReadLine();

            do
            {
                Console.WriteLine("Please enter the age of that person"); //user enters age
                isnum = double.TryParse(Console.ReadLine(), out ageInput);

                if (!isnum | ageInput <= 0)
                {
                    Console.WriteLine("Error: Input must be a number higher than 0");
                }

            } while (!isnum | ageInput <= 0);


            maxName = nameInput;
            maxAge = ageInput;

            // does once, guarantees a maximum age and a name associated

            do
            {

                Console.WriteLine("Please enter another person's name");
                nameInput = Console.ReadLine();

                if (nameInput != "end")
                {

                    do
                    {

                        Console.WriteLine("Now enter the age of that person");
                        isnum = double.TryParse(Console.ReadLine(), out ageInput);

                        if (!isnum | ageInput <= 0)
                        {
                            Console.WriteLine("Error: Input must be a number higher than 0");
                        }


                    } while (!isnum | ageInput <= 0);

                    if (ageInput > maxAge)
                    {
                        maxAge = ageInput;
                        maxName = nameInput;
                    }



                }


            }
            while (nameInput != "end");

            Console.WriteLine("The oldest person was " + maxName + " at " + maxAge + " years old");
            Console.WriteLine();
            Console.WriteLine("Press enter to continue");
            Console.ReadLine();

        }

        static void RandomNumber() //question 6 - hi lo/random number
        {
            int guess;
            int turns;
            int maxNumber = 100;


            Random random = new Random();
            int numberGenerated = random.Next(1, maxNumber);

            bool isnum;

            Console.WriteLine("I am thinking of an integer between 1 and 100, what is the number?");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            turns = 0;

            do
            {
                do
                {

                    Console.WriteLine("Type your guess");
                    //guess = Convert.ToInt32(Console.ReadLine());
                    isnum = Int32.TryParse(Console.ReadLine(), out guess);

                    if (!isnum | guess < 1 | guess > maxNumber)
                    {
                        Console.WriteLine("Error: Input must be an integer between 1 and 100");
                    }

                } while (!isnum | guess < 1 | guess > maxNumber);


                turns = turns + 1;

                if (guess == numberGenerated)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine();
                    Console.WriteLine("You have correctly guessed the number!");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.White;

                }
                else
                {
                    if (guess > numberGenerated)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine();
                        Console.WriteLine("Your guess was too high! Please try again!");
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine();
                        Console.WriteLine("Your guess was too low! Please try again!");
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }

            }
            while (guess != numberGenerated);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("You took " + turns + " tries to guess the correct number");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Press enter to continue");
            Console.ReadLine();
        }






    }
}
