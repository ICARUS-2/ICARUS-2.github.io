﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3app
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isnum;
            int input;

            double rainfallOutput;

            do
            {
                Console.WriteLine(" Please select a menu option below by entering a number");
                Console.WriteLine("\n 1 - Rainfall Statistics");
                Console.WriteLine("\n 2 - Students & Grades");
                Console.WriteLine("\n 3 - Charge Account Validation");
                Console.WriteLine("\n 4 - Payroll");
                Console.WriteLine("\n 5 - SAAQ Exam Grader");
                Console.WriteLine("\n 6 - Exit Program");
                Console.WriteLine();

                isnum = Int32.TryParse(Console.ReadLine(), out input);

                if (!isnum | input > 6 | input < 1)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Error: Input can only be an integer from 1 to 6 \n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    switch (input)
                    {
                        case 1:
                            Console.Clear();
                            rainfallOutput = rainfallInput(); //returns rainfall inputs
                            Console.WriteLine("\nThe monthly average rainfall is " +rainfallOutput+ "mm");
                            Console.WriteLine("\nPress enter to return to main menu");
                            Console.ReadLine();
                            Console.Clear();
                            break;

                        case 2:
                            Console.Clear();
                            studentsAndGrades(); // <- void function so no return value
                            break;

                        case 3:
                            Console.Clear();
                            chargeAccountInputOutput();
                            break;

                        case 4:
                            Console.Clear();
                            payrollInputAndArrays();
                            break;

                        case 5:
                            Console.Clear();
                            saaqExamGrader();
                            break;
                        
                    }//end of switch statement

                }//end of else statement
               

            }
            while (input !=6);
        }//end of Main

        //=========================================================================================

        static double rainfallInput()
        {
            Double[] rainfallArray = new Double[12];

            int monthNumber = 0;
            int arrayLocation = 0;
            int numberOfMonths = 12; //to avoid hardcoding
            double minRainfallMonth = 0;
            double maxRainfallMonth = 0;



            string monthName = "January";

            bool isnum;

            double input;
            double sumAccumulator = 0;
            double average;
            double minRainfall = 0; 
            double maxRainfall = 0;

        

            do
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Please enter the rainfall for the month of " + monthName + " in millimeters");
                Console.ForegroundColor = ConsoleColor.White;

                monthNumber += 1;

                do
                {
                    isnum = Double.TryParse(Console.ReadLine(), out input);


                    if(!isnum | input < 0)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Error: Input must be a double-precision number greater than 0");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else //input checks out, else statement invoked
                    {
                        rainfallArray[arrayLocation] = input;

                        if (input < minRainfall | arrayLocation == 0) // arrayLocation == 0 ensures the first value inputted will be assigned as minimum
                        {
                            minRainfall = input;
                            minRainfallMonth = arrayLocation;
                        }
                        
                        if (input > maxRainfall)
                        {
                            maxRainfall = input;
                            maxRainfallMonth = arrayLocation;
                        }
                        
                        arrayLocation++;
                        sumAccumulator += input;

                    }
                } while (!isnum | input < 0); //end of input loop

                switch (monthNumber)
                {
                    case 0:
                        monthName = "January";
                        break;

                    case 1:
                        monthName = "February";
                        break;

                    case 2:
                        monthName = "March";
                        break;

                    case 3:
                        monthName = "April";
                        break;

                    case 4:
                        monthName = "May";
                        break;

                    case 5:
                        monthName = "June";
                        break;

                    case 6:
                        monthName = "July";
                        break;

                    case 7:
                        monthName = "August";
                        break;

                    case 8:
                        monthName = "September";
                        break;

                    case 9:
                        monthName = "October";
                        break;

                    case 10:
                        monthName = "November";
                        break;

                    case 11:
                        monthName = "December";
                        break;
                }//end of switch statement

            } while (monthNumber < numberOfMonths); //end of month name loop

            //once inputs are all entered and validated:

            Console.WriteLine("\nThe total amount of rainfall was " + sumAccumulator + "mm");

            rainfallMinMax(minRainfall, maxRainfall, minRainfallMonth, maxRainfallMonth);

            average = rainfallAverage(sumAccumulator, numberOfMonths);
            
            return average;
        }//end of rainfallInput

        static double rainfallAverage(double dSumAccumulator, int dNumberOfMonths) //calculates average
        {
            double dAverage = dSumAccumulator / dNumberOfMonths;

            return dAverage;
        }

        static void rainfallMinMax(double dMinRainfall, double dMaxRainfall, double dMinRainfallMonth, double dMaxRainfallMonth)
        {
            string minRainfallMonthName = "null";
            string maxRainfallMonthName = "null";

            switch (dMinRainfallMonth)
            {
                case 0:
                    minRainfallMonthName = "January";
                    break;

                case 1:
                    minRainfallMonthName = "February";
                    break;

                case 2:
                    minRainfallMonthName = "March";
                    break;

                case 3:
                    minRainfallMonthName = "April";
                    break;

                case 4:
                    minRainfallMonthName = "May";
                    break;

                case 5:
                    minRainfallMonthName = "June";
                    break;

                case 6:
                    minRainfallMonthName = "July";
                    break;

                case 7:
                    minRainfallMonthName = "August";
                    break;

                case 8:
                    minRainfallMonthName = "September";
                    break;

                case 9:
                    minRainfallMonthName = "October";
                    break;

                case 10:
                    minRainfallMonthName = "November";
                    break;

                case 11:
                    minRainfallMonthName = "December";
                    break;
            }//end of switch statement
            Console.WriteLine("The lowest recorded rainfall was " + dMinRainfall + "mm in " +minRainfallMonthName);

            switch (dMaxRainfallMonth)
            {
                case 0:
                    maxRainfallMonthName = "January";
                    break;

                case 1:
                    maxRainfallMonthName = "February";
                    break;

                case 2:
                    maxRainfallMonthName = "March";
                    break;

                case 3:
                    maxRainfallMonthName = "April";
                    break;

                case 4:
                    maxRainfallMonthName = "May";
                    break;

                case 5:
                    maxRainfallMonthName = "June";
                    break;

                case 6:
                    maxRainfallMonthName = "July";
                    break;

                case 7:
                    maxRainfallMonthName = "August";
                    break;

                case 8:
                    maxRainfallMonthName = "September";
                    break;

                case 9:
                    maxRainfallMonthName = "October";
                    break;

                case 10:
                    maxRainfallMonthName = "November";
                    break;

                case 11:
                    maxRainfallMonthName = "December";
                    break;
            }//end of switch statement
            Console.WriteLine("The highest recorded rainfall was " + dMaxRainfall + "mm in " +maxRainfallMonthName);
        }

        //============================================================================ END OF QUESTION 1 FUNCTIONS

        static void studentsAndGrades() //question 2 - students and grades
        {
            bool isnum;
            int numberOfStudents;
            int numberOfTests;
            int studentCounter = 1;
            int testCounter = 1;
            int averageArrayCounter = 0;

            int studentOutputCounter = 1;
            int sumAverageOutputCounter = 0;

            double testGrade;

            double sumAverageAccumulator = 0;

            const double minGrade = 0;
            const double maxGrade = 100;



            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Please enter the number of students");
            Console.ForegroundColor = ConsoleColor.White;
            do
            {
               isnum = Int32.TryParse(Console.ReadLine(), out numberOfStudents);
               if(!isnum | numberOfStudents < 1)
               {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Error: Number of students can only be a positive integer");
                    Console.ForegroundColor = ConsoleColor.White;
               }

            } while (!isnum | numberOfStudents < 1);

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Please enter the number of tests per student");
            Console.ForegroundColor = ConsoleColor.White;

            do
            {
                isnum = Int32.TryParse(Console.ReadLine(), out numberOfTests);
                if (!isnum | numberOfStudents < 1)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Error: Number of tests can only be a positive integer");
                    Console.ForegroundColor = ConsoleColor.White;
                }

            } while (!isnum | numberOfTests < 1);

            Double[] testSumArray = new Double[numberOfStudents]; //array for test sums
            Double[] studentAverageArray = new Double[numberOfStudents]; //array for averages

            do
            {
                do
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Please enter the grade for student " + studentCounter + " test " + testCounter);
                    Console.ForegroundColor = ConsoleColor.White;

                    
                    do
                    {
                        isnum = Double.TryParse(Console.ReadLine(), out testGrade);
                        if(!isnum | testGrade < minGrade | testGrade > maxGrade)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("Error: Test grade must be a number that is between " + minGrade + " and " + maxGrade); ;
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                                            


                    } while (!isnum | testGrade < minGrade | testGrade > maxGrade); //end of validator

                    studentCounter -= 1;
                    testSumArray[studentCounter] += testGrade;
                    studentCounter += 1;

                    testCounter++;

                } while (testCounter <= numberOfTests);

                studentCounter++;
                testCounter = 1;

            } while (studentCounter <= numberOfStudents); //end of collecting inputs, move to calculating averages and displaying results

            do //calculates averages of each student and places those averages into the second array
            {
                studentAverageArray[averageArrayCounter] = testSumArray[averageArrayCounter] / numberOfTests;
                averageArrayCounter++;

            } while (averageArrayCounter < numberOfStudents);

            Console.WriteLine();

            do //outputs the student averages as well as the sums of their grades
            {           
                Console.WriteLine("Student " + studentOutputCounter + " has an average of " + studentAverageArray[sumAverageOutputCounter] + "% and the sum of the grades is " + testSumArray[sumAverageOutputCounter]);
                studentOutputCounter++;
                sumAverageOutputCounter++;

            } while (studentOutputCounter <= numberOfStudents);

            sumAverageOutputCounter = 0; //resets counter

            do
            {
                sumAverageAccumulator += studentAverageArray[sumAverageOutputCounter];
                sumAverageOutputCounter++;
            } while (sumAverageOutputCounter < numberOfStudents);

            sumAverageAccumulator /= numberOfStudents;

            Console.WriteLine("\nThe average of all the students is " + sumAverageAccumulator + "%");
            Console.WriteLine("\nPress enter to return to main menu");
            Console.ReadLine();
            Console.Clear();
        }//end of students and grades function

        static void chargeAccountInputOutput()
        {
            bool isnum;
            bool isValid;
            Int32 inputNumber;

            do
            {
                Console.WriteLine("Please enter a number from this list of account numbers, or enter 0 to return to main menu\n");
                Console.WriteLine("5658845");
                Console.WriteLine("4520125");
                Console.WriteLine("7895122");
                Console.WriteLine("8777541");
                Console.WriteLine("8451277");
                Console.WriteLine("1302850");
                Console.WriteLine("8080152");
                Console.WriteLine("4562555");
                Console.WriteLine("5552012");
                Console.WriteLine("5050552");
                Console.WriteLine("7825877");
                Console.WriteLine("1250255");
                Console.WriteLine("1005231");
                Console.WriteLine("6545231");
                Console.WriteLine("3852085");
                Console.WriteLine("3852085");
                Console.WriteLine("7881200");
                Console.WriteLine("4581002\n\n\n");

                do
                {
                    isnum = Int32.TryParse(Console.ReadLine(), out inputNumber);
                    if (!isnum | inputNumber < 0)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Error: Input can only be a positive integer");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                } while (!isnum | inputNumber < 0);

                if (inputNumber == 0 )
                {
                    Console.Clear();
                    break;
                }


                isValid = chargeAccountValidator(inputNumber);
                if(isValid)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(inputNumber + " is a valid account number");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(inputNumber + " is not a valid account number");
                    Console.ForegroundColor = ConsoleColor.White;
                }

            } while (inputNumber != 0);
        }//end of charge account input function

        static bool chargeAccountValidator(Int32 dInputNumber)
        {
            int arrayCounter = 0;
            int arrayLength = 18;

            Int32[] accountDatabaseArray = new Int32[arrayLength];
            accountDatabaseArray[0] = 5658845;
            accountDatabaseArray[1] = 4520125;
            accountDatabaseArray[2] = 7895122;
            accountDatabaseArray[3] = 8777541;
            accountDatabaseArray[4] = 8451277;
            accountDatabaseArray[5] = 1302850;
            accountDatabaseArray[6] = 8080152;
            accountDatabaseArray[7] = 4562555;
            accountDatabaseArray[8] = 5552012;
            accountDatabaseArray[9] = 5050552;
            accountDatabaseArray[10] = 7825877;
            accountDatabaseArray[11] = 1250255;
            accountDatabaseArray[12] = 1005231;
            accountDatabaseArray[13] = 6545231;
            accountDatabaseArray[14] = 3852085;
            accountDatabaseArray[15] = 7576651;
            accountDatabaseArray[16] = 7881200;
            accountDatabaseArray[17] = 4581002;

            do
            {
                if (accountDatabaseArray[arrayCounter] == dInputNumber)
                {
                    return true;
                }
                else
                {
                    arrayCounter++;
                }
            } while (arrayCounter < arrayLength);

            return false;

        }//end of charge account validator

        //========================================================END OF QUESTION 3 FUNCTIONS

        static void payrollInputAndArrays()
        {
            bool isnum;
            int hoursWorked;
            double payRate;
            int numberOfEmployees = 7;
            Int32 arrayCounter = 0;

            Int32[] empIdArray = new Int32[7];
                empIdArray[0] = 56588;
                empIdArray[1] = 45201;
                empIdArray[2] = 78951;
                empIdArray[3] = 87775;
                empIdArray[4] = 84512;
                empIdArray[5] = 13028;
                empIdArray[6] = 75804;
            Int32[] hoursArray = new Int32[7];
            Double[] payRateArray = new Double[7];

            do
            {
                Console.WriteLine("Please enter the amount of hours worked for " + empIdArray[arrayCounter]);
                do
                {
                    isnum = Int32.TryParse(Console.ReadLine(), out hoursWorked);
                    if (!isnum | hoursWorked < 0)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Error: Number of hours worked can only be a positive integer");
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                } while (!isnum | hoursWorked < 0);
                hoursArray[arrayCounter] = hoursWorked;

                Console.WriteLine("Please enter the hourly wage of " + empIdArray[arrayCounter]);
                do
                {
                    isnum = Double.TryParse(Console.ReadLine(), out payRate);
                    if (!isnum | payRate < 0)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Error: Hourly wage can only be a positive number");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                } while (!isnum | payRate < 0);
                payRateArray[arrayCounter] = payRate;

                arrayCounter++;

            } while (arrayCounter < numberOfEmployees);

            payrollCalculator(numberOfEmployees, empIdArray, hoursArray, payRateArray);

        }//end of payroll inputs and arrays

        static void payrollCalculator(int dNumberOfEmployees, Int32[] dEmpIdArray, Int32[] dHoursArray, Double[] dPayRateArray) 
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            int arrayCounter = 0;
            double salary;
            do
            {
                salary = dHoursArray[arrayCounter] * dPayRateArray[arrayCounter];
                Console.WriteLine("The salary of " + dEmpIdArray[arrayCounter] + " is " + salary + "$");
                arrayCounter++;
            } while (arrayCounter < dNumberOfEmployees);
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\nPress enter to return to main menu");
            Console.ReadLine();
            Console.Clear();

        }//end of payroll calculator
        //============================================================END OF QUESTION 4 FUNCTIONS

        static void saaqExamGrader()
        {
            int numberOfQuestions = 10;
            int questionCounter = 1;
            int arrayPlaceCounter = 0;
            string answer;

            int correctAnswerCounter = 0;
            int incorrectAnswerCounter = 0;

            String[] studentAnswerArray = new String[numberOfQuestions];
            String[] correctAnswerArray = new String[numberOfQuestions];
            correctAnswerArray[0] = "b" ;
            correctAnswerArray[1] = "d";
            correctAnswerArray[2] = "a";
            correctAnswerArray[3] = "a";
            correctAnswerArray[4] = "c";
            correctAnswerArray[5] = "a";
            correctAnswerArray[6] = "b";
            correctAnswerArray[7] = "a";
            correctAnswerArray[8] = "c";
            correctAnswerArray[9] = "d";

            Console.WriteLine("The correct answers to the test are:");
            Console.WriteLine("1-b 2-d 3-a 4-a 5-c 6-a 7-b 8-a 9-c 10-d");
            Console.WriteLine();
            do
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Enter the student's answer for question " +questionCounter);
                Console.ForegroundColor = ConsoleColor.White;
                do
                {
                    answer = Convert.ToString(Console.ReadLine());
                    if (answer != "a" && answer != "b" && answer != "c" && answer != "d")
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Error: Input can only be a, b, c, d (Case sensitive)");
                        Console.ForegroundColor = ConsoleColor.White;                         
                    }

                } while (answer != "a" && answer != "b" && answer != "c" && answer != "d");
                studentAnswerArray[arrayPlaceCounter] = answer;

                arrayPlaceCounter++;
                questionCounter++;
            } while (arrayPlaceCounter < numberOfQuestions);

            questionCounter = 1;
            arrayPlaceCounter = 0;
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("STUDENT EXAM RESULTS\n");
            Console.ForegroundColor = ConsoleColor.White;

            do
            {
                Console.WriteLine("Question " + questionCounter + ": Student Answer = " + studentAnswerArray[arrayPlaceCounter] + " | Correct Answer = " +correctAnswerArray[arrayPlaceCounter]);
                if (studentAnswerArray[arrayPlaceCounter] == correctAnswerArray[arrayPlaceCounter])
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Result: Correct");
                    Console.ForegroundColor = ConsoleColor.White;
                    correctAnswerCounter++;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Result: Incorrect");
                    Console.ForegroundColor = ConsoleColor.White;
                    incorrectAnswerCounter++;
                }

                questionCounter++;
                arrayPlaceCounter++;

            } while (arrayPlaceCounter < numberOfQuestions);

            Console.WriteLine("\nTotal number of correct answers: " + correctAnswerCounter);
            Console.WriteLine("\nTotal number of incorrect answers: " + incorrectAnswerCounter);
            Console.WriteLine();
            
            if(correctAnswerCounter >=6)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Final Result: PASS");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Final Result: FAIL");
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine("\nPress enter to return to main menu");
            Console.ReadLine();
            Console.Clear();
        }


    }//end of class

}//end of namespace
