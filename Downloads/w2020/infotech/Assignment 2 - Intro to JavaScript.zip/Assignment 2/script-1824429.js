
			// How often should your function be called? Modify the value below.
			var interval = 1000;
		
			// Initialize a counter BELOW
			var counter = 0;
			// Initialize a counter ABOVE

			function timedFunction() {
				// Increment the counter BELOW
				counter++;
				// Increment the counter ABOVE

				// Replace the ***text content*** of the placeholder by the counter by completing the line below
				
				document.getElementById("placeholder").innerHTML=counter;
			}

			setInterval(timedFunction, interval);
