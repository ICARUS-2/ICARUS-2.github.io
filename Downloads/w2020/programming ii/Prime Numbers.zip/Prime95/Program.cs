﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Prime95
{
    class Program
    {
        static void Main(string[] args)
        {
            int arrayRows;
            int arrayColumns;
            int[,] primeArray;
            int rgbCounter = 1;
            int rgbCounterMax = 9;
            int sleepThreading = 0;

            Console.WriteLine("Please enter the number of rows in the array");
            arrayRows = ValInt(1, int.MaxValue, "ERROR, INPUT CAN ONLY BE A 32-BIT POSITIVE INTEGER");

            Console.WriteLine("Please enter the number of columns for the array");
            arrayColumns = ValInt(1, int.MaxValue, "ERROR, INPUT CAN ONLY BE A 32 - BIT POSITIVE INTEGER");

            Console.WriteLine("Would you like to enable sleep threading? 0 = NO, 1 = YES");
            sleepThreading = ValInt(0,1, "ERROR: PLEASE ENTER ONLY 0 OR 1");

            Console.WriteLine("\t\tCalculating, please wait");
            primeArray = FindPrimes(arrayRows, arrayColumns);

            Console.Clear();
            Console.WriteLine("The first {0} prime numbers are", primeArray.GetLength(0) * primeArray.GetLength(1));
            Console.WriteLine();
            for (int r = 0; r < arrayRows; r++)
            {
                for (int c = 0; c < arrayColumns; c++)
                {
                    if (sleepThreading == 1)
                    {
                        Thread.Sleep(1);
                    }
                    RGB(rgbCounter);
                    Console.Write("{0, 5}  ", primeArray[r, c]);
                    rgbCounter++;
                    if (rgbCounter == rgbCounterMax)
                        rgbCounter = 1;
                    
                }
                Console.WriteLine("\n");
            }
            Console.ReadLine();
        }
        //VALIDATE INT====================================================
        static int ValInt(int minValue, int maxValue, string errorMessage)
        {
            bool isInt;
            int userNumPress;
            do
            {
                isInt = int.TryParse(Console.ReadLine(), out userNumPress);
                if (!isInt | userNumPress < minValue | userNumPress > maxValue)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("{0}", errorMessage);
                    Console.ResetColor();
                }
            } while (!isInt | userNumPress < minValue | userNumPress > maxValue);
            return userNumPress;
        }//end of function

        //PRIME NUMBER ARRAY==============================================
        static int[,] FindPrimes(int arrayRows, int arrayColumns)
        {
            int[,] primeArray = new int[arrayRows, arrayColumns];
            int num = 2;
            bool isPrime;


            for(int r = 0; r < arrayRows; r++)
            {
                for (int c = 0; c < arrayColumns; c++)
                {
                    isPrime = CheckIfPrime(num);

                    if(isPrime)
                    {
                        primeArray[r, c] = num;
                    }
                    else
                    {
                        c--;
                    }
                    num++;
                }

            }

            return primeArray;
        }//end of function

        //CHECK IF PRIME
        static bool CheckIfPrime(int num)
        {
            //bool isPrime;
            int factor;
            int firstPrimeNumber = 2;

            if (num==firstPrimeNumber)
            {
                return true;
            }
            
            if (num % 2 == 0) //modulo 2 determines whether it can be prime or not based on if is even or not (no such thing as an even prime number)
            {
                return false;
            }

            for (factor = 2; factor < (num-1 / 2); factor++)
            {
                if (num % factor == 0)
                {
                    return false;
                }
            }

            return true;
        }//end of function

        //RGB
        static void RGB(int rgbCounter)
        {
            switch (rgbCounter)
            {
                case 1:
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case 2:
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    break;
                case 3:
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    break;
                case 4:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                case 5:
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case 6:
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    break;
                case 7:
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case 8:
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    break;
            }
        }

    }//end of class
}//end of namespace
