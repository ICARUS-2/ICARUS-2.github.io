﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace lists_assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> integerList = new List<int>();

            ProcessInputs(integerList);

            DisplayIntValues(integerList);

            ReadLine();
        }//end of function


        static void ProcessInputs(List<int> integerList)
        {
            WriteLine("Program takes integers from the user, and then outputs the unique ones when 'q' or 'Q' is entered");

            string input;
            bool isInt;
            bool doesNotContain;
            int arrInt;
            do
            {
                WriteLine("\n\nType something and press Enter");
                input = ReadLine().ToUpper();

                isInt = int.TryParse(input, out arrInt);

                if (!isInt)
                {
                    ForegroundColor = ConsoleColor.DarkRed;
                    WriteLine("ERROR: INPUT CAN ONLY BE A VALID INTEGER");
                    ResetColor();
                }

                if (isInt && integerList.Contains(Convert.ToInt32(input)))
                {
                    doesNotContain = false;
                }
                else
                {
                    doesNotContain = true;
                }

                if (isInt && doesNotContain)
                {
                    integerList.Add(arrInt);
                }
            } while (input != "Q");
            Clear();
        }//end of function
        
        static void DisplayIntValues(List<int> integerList)
        {

            if (integerList.Count == 0)
            {
                WriteLine("You didn't enter any numbers dumbass");
            }
            else
                WriteLine("The unique numbers entered were");
            {
            /*    for (int i = 0; i < integerList.Count; i++)
                {
                    WriteLine(integerList[i]);
                }
            */

            foreach(int i in integerList)
                {
                    WriteLine(i);
                }
            }
            WriteLine("\n\nPress enter to exit");
        }//end of function
    }//end of class
}//end of namespace
