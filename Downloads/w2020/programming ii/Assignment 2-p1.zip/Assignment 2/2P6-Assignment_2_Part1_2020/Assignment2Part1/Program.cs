﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using static System.Console;
namespace Assignment2Part1
//A2-P1: Program reads a series of sales numbers and division names, places them into arrays, and calculates values such as the average sales for each quarter and each division
{
    class Program
    {
        const int MAX_ROWS = 6; //6 divisions
        const int MAX_COLUMNS = 4; //4 quarters
        const int NUMBER_OF_LINES = 30; //total number of lines within the file
        static void Main(string[] args)
        {
            bool readOK;
            string[] divisions = new string[MAX_ROWS];
            double[,] sales = new double[MAX_ROWS, MAX_COLUMNS];

            readOK = ReadFile(divisions, sales);

            if(readOK)
            {
                //PrintArray(sales); //used for testing. It should be commented before submitting
                string divisionReport = GetDivisionStats(divisions, sales);
                string quarterReport = GetQuarterStats(divisions, sales);
                WriteLine(divisionReport);
                WriteLine(quarterReport);
                if (!SaveReports(divisionReport, quarterReport))
                    WriteLine("ERROR! Problem with saving reports to file");
            }
            else
            {
                ForegroundColor = ConsoleColor.DarkRed;
                WriteLine("ERROR! Problem with reading the file");
                ResetColor();
            }
            ReadLine();
        }//end of function
        
        /*static void PrintArray(double[,] arr)//only used for testing
        {
            foreach (double i in arr)
                WriteLine(i);
        }//end of function*/

        static bool ReadFile(string[] theDivisions, double[,] theSales)
            //Method reads and places the contents of the file into their respective arrays and returns true or false based on whether it was able to read and place all values correctly
        {
            string filePath = "../../sales.txt";
            string lineRead = "";
            double salesNumber;
            bool isNum;
            int iDivisions = 0; //indexes for arrays
            int rSales = 0;
            int cSales = 0;
            int checksumCounter = 0; //checks to see if all lines were read correctly
            StreamReader reader = null;
            try
            {
                if (File.Exists(filePath))
                { 
                    reader = new StreamReader(filePath);
                
                
                    while(lineRead != null)
                    {
                        lineRead = reader.ReadLine();
                        checksumCounter++;
                        isNum = double.TryParse(lineRead, out salesNumber); //this checks if the line is a number to determine which array the number is stored in

                        if (lineRead != null) //needs this after lineRead is assigned at beginning
                        {
                            if (lineRead == "" && checksumCounter <= NUMBER_OF_LINES)
                            {
                                ForegroundColor = ConsoleColor.DarkRed;
                                WriteLine("ERROR: END OF FILE DETECTED BEFORE ALL {0} LINES WERE READ", NUMBER_OF_LINES);
                                ResetColor();
                                reader.Close();
                                return false;
                            }

                            if (isNum)
                            {
                                theSales[rSales, cSales] = salesNumber;

                                cSales++;
                                if (cSales >= theSales.GetLength(1))
                                {
                                    cSales = 0;
                                    rSales++;
                                }
                            }
                            else
                            {
                                theDivisions[iDivisions] = lineRead;
                                iDivisions++;
                            }
                        }//end of if statement

                    }//end of loop
                    reader.Close();
                }//end of if
                else
                {
                    return false;
                }
                return true;
            }//end of try 
            catch (Exception e)
            {
                ForegroundColor = ConsoleColor.DarkRed;
                WriteLine(e.Message);
                ResetColor();
                reader.Close();
                return false;
            }
        }//end of function

        static string GetDivisionStats(string[] theDivisions, double[,] theSales)
            //Method takes the divisions and sales arrays and uses their contents to build a string showing the average sales for each division and the differences between quarters, and returns the string when it is built
        {
            string statusReport = "";
            StringBuilder sb = new StringBuilder(statusReport);
            int iDiv; //index for divisions array
            int rSales = 0; //rows and colums for 2d sales array
            int cSales;
            double diff;
            double totalPerDiv;

            for (iDiv = 0; iDiv < theDivisions.Length; iDiv++)
            {
                totalPerDiv = 0;
                sb.AppendFormat("\nDivision: {0}", theDivisions[iDiv]);
                for (cSales = 0; cSales < theSales.GetLength(1); cSales++)
                {
                    sb.AppendFormat("\n\tQuarter {0}: {1}", cSales + 1, theSales[rSales, cSales]);

                    if (cSales != 0)
                    {
                        diff = theSales[rSales, cSales] - theSales[rSales, cSales - 1];
                        sb.AppendFormat("\n\t\tDiff from Q{0}: {1}", cSales, diff);
                    }
                    totalPerDiv += theSales[rSales, cSales];
                }
                sb.AppendFormat("\nDivision: {0} - Sales: {1}", theDivisions[iDiv], totalPerDiv);                
                sb.Append("\n***********************************");
                rSales++;
            }//end of outer loop

            //to do, use string builder to build the report
            return sb.ToString();
        }//end of function

        static string GetQuarterStats(string[] theDivisions, double[,] theSales)
            //Method takes the divisions and sales arrays and uses them to build a string showing the total and average sales for each quarter and differences between quarters. It returns the string when it is built
        { 
            string quarterReport = "";
            StringBuilder sb = new StringBuilder(quarterReport);

            sb.AppendFormat("\n\n\n===============================================");

            int rSales; //rows and columns index for 2d sales array
            int cSales;
            int iHighestSales = 0; //highest sales index
            double oldTotalSales;
            double totalSales = 0;
            double average;
            double diff;

            for (cSales = 0; cSales < theSales.GetLength(1); cSales++)
            {
                oldTotalSales = totalSales;
                totalSales = 0;
                for (rSales = 0; rSales < theSales.GetLength(0); rSales++) //accumulates total sales
                {
                    totalSales += theSales[rSales, cSales];
                    if (theSales[rSales, cSales] > theSales[iHighestSales, cSales])
                        iHighestSales = rSales;


                }
                average = totalSales / theSales.GetLength(0);
                sb.AppendFormat("\n\nQuarter {0} total sales:\t\t{1}", cSales + 1, totalSales);
                
                if (cSales >= 1)
                {
                    diff = totalSales - oldTotalSales;
                    sb.AppendFormat("\n\t-Diff from Q{0}: {1}", cSales, diff);
                }
                
                sb.AppendFormat("\n\t-Average sale for all divisions this quarter: {0:n2}", average);
                sb.AppendFormat("\n\t-Division with highest sale this quarter: {0} with {1}", theDivisions[iHighestSales], theSales[iHighestSales, cSales]);
                
            }//end of for loop


            //to do, use string builder to build the report
            return sb.ToString();
        }

        static bool SaveReports(string divisionReport, string quarterReport)
            //This method takes the two strings returned through the previous methods and utilizes a streamwriter to write them to the file, and then saves it. Returns true or false based on the file writing and saving correctly
        {
            string filePath = "../../salesReport.txt";
            StreamWriter sw = null; 
            try
            {
                sw = new StreamWriter(filePath);
                sw.WriteLine(divisionReport);
                sw.WriteLine(quarterReport);
            }
            catch (Exception e)
            {
                ForegroundColor = ConsoleColor.DarkRed;
                WriteLine(e.Message);
                ResetColor();
                if(sw !=null)
                sw.Close();
                return false;
            }
            //future notice, close in finally
            sw.Close();
            return true;
        }
    }
}
