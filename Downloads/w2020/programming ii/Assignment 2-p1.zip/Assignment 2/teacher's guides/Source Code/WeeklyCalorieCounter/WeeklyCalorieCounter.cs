﻿/* WeeklyCalorieCounter.cs       Author:  Doyle
 * Demonstrates usage of a two-dimensional array
 * to calculate the average number of calories 
 * intake per day, per meal type and per meal.
 */

using System;
using static System.Console;

namespace WeeklyCalorieCounter
{
    class WeeklyCalorieCounter
    {
        static void Main( )
        {
            int[ , ] calories = {{900,750, 1020},
                                {300, 1000, 2700},
                                {500, 700, 2100},
                                {400, 900, 1780},
                                {600, 1200, 1100},
                                {575, 1150, 1900},
                                {600, 1020, 1700}};

            double[] dailyAverage;
            double[] mealAverage;

            dailyAverage = CalculateAverageByDay(calories);
            mealAverage = CalculateAverageByMeal(calories);

            DisplayDailyAverage(dailyAverage);
            DisplayMealAverage(mealAverage);
            DisplayAverageCaloriesPerMeal(calories);
            ReadKey( );
        }

        public static double[ ] CalculateAverageByDay(int[ , ] calories)
        {
            int MAX_ROW = calories.GetLength(0);
            int MAX_COLUMN = calories.GetLength(1);
            int sum;
            double[] dailyAverage = new double[MAX_ROW];

            for (int r = 0; r < MAX_ROW; r++)
            {
                sum = 0;
                for (int c = 0; c < MAX_COLUMN; c++)
                     sum += calories[r, c];

                dailyAverage[r] = (double)sum / calories.GetLength(1);
            }
            return dailyAverage;
        }

        public static double[ ] CalculateAverageByMeal(int[ , ] calories)
        {
            int sum = 0;
            double[ ] mealAverage = new double[calories.GetLength(1)];

            for (int c = 0; c < calories.GetLength(1); c++)
            {
                for (int r = 0; r < calories.GetLength(0); r++)
                     sum += calories[r, c];

                mealAverage[c] = (double)sum / calories.GetLength(0);
                sum = 0;
            }
            return mealAverage;
        }

        public static void DisplayDailyAverage(double[ ] dailyAverage)
        {
            int dayNumber = 1;
            WriteLine("Calorie Counter");
            WriteLine("Daily Averages");

            foreach (double avgCalorie in dailyAverage)
            {
                WriteLine("Day {0}: {1,6:N0}", dayNumber, avgCalorie);
                dayNumber++;
            }
        }

        public static void DisplayMealAverage(double[ ] mealAverage)
        {
            string[ ] mealTime = { "Breakfast", "Lunch", "Dinner" };
            WriteLine("\n\nCalorie Counter");
            WriteLine("Meal Averages");

            for (int c = 0; c < mealAverage.Length; c++)
            {
                WriteLine("{0,-10}: {1,6}", mealTime[c], mealAverage[c].ToString("N0"));
            }
        }

        public static void DisplayAverageCaloriesPerMeal(int[ , ] calories)
        {
            double sum = 0;
            for (int da = 0; da < calories.GetLength(0); da++)
            {
                for (int ml = 0; ml < calories.GetLength(1); ml++)
                {
                    sum += calories[da, ml];
                }
            }

            WriteLine("\nCaloric Average Per Meal: {0:N0}", sum / calories.Length);

        }
    }
}