﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
Name: Ethan Briffett
ID: 1824429
Section: 1
Program Description: The program takes a series of hard-coded values from a two-dimensional
array calculates various averages, and displays them.
*/
 
   
namespace calories_assignment
{
    class Program
    {
        //MAIN FUNCTION==============================================
        static void Main(string[] args)
        {
            int rgbCounter = 0;
            int[,] calories =
            {
                {900, 750, 1020},
                {300, 1000, 2700},
                {500, 700, 2100},
                {400, 900, 1780},
                {600, 1200, 1100},
                {575, 1150, 1900},
                {600, 1020, 1700},
            };

            double[] dailyAverage;
            double[] mealAverage;

            dailyAverage = CalculateAverageByDay(calories);
            mealAverage = CalculateAverageByMeal(calories);

            DisplayDailyAverage(dailyAverage);
            DisplayMealAverage(mealAverage);
            DisplayAverageCaloriesPerMeal(calories);

            //THIS MAKES THE TOP LINE LIGHT UP PRETTY COLORS
            while (!Console.KeyAvailable)
            {
                Console.SetCursorPosition(0, 0);
                Console.CursorVisible = false;
                switch (rgbCounter)
                {
                    case 0:
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;

                    case 1:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        break;

                    case 2:
                        Console.ForegroundColor = ConsoleColor.Green;
                        break;

                    case 3:
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        break;

                    case 4:
                        Console.ForegroundColor = ConsoleColor.Blue;
                        break;

                    case 5:
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        break;

                    case 6:
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        rgbCounter = 0;
                        break;
                }
                rgbCounter++;
                System.Threading.Thread.Sleep(150);
                Console.WriteLine("CALORIE COUNTER");
            }



        }//end of main function

        //CALCULATE AVERAGE BY DAY=================================
        public static double[] CalculateAverageByDay(int[,] theCalories)
        {
            int ROWSIZE = theCalories.GetLength(0);

            double[] theDailyAverage = new double[ROWSIZE];

            for (int r = 0; r < theCalories.GetLength(0); r++)
            {
                for (int c = 0; c < theCalories.GetLength(1); c++)
                {
                    theDailyAverage[r] += theCalories[r, c];

                }//end of inner loop
                theDailyAverage[r] /= theCalories.GetLength(1);
            }//end of outer loop

            return theDailyAverage;

        }//end of function

        //CALCULATE AVERAGE BY MEAL================================
        public static double[] CalculateAverageByMeal(int[,] theCalories)
        {
            int COLSIZE = theCalories.GetLength(1);
            double[] theMealAverage = new double[COLSIZE];

            for (int c = 0; c < theCalories.GetLength(1); c++)
            {
                for (int r = 0; r < theCalories.GetLength(0); r++)
                {
                    theMealAverage[c] += theCalories[r, c];
                }
                theMealAverage[c] /= theCalories.GetLength(0);
            }

            return theMealAverage;
        }//end of function

        //DISPLAY DAILY AVERAGE====================================
        public static void DisplayDailyAverage(double[] dailyAverage)
        {
            int arrayIndex;
            int dayNumber = 1;


            Console.WriteLine("\n\n\nDAILY AVERAGES");
            for (arrayIndex = 0; arrayIndex < dailyAverage.GetLength(0); arrayIndex++)
            {
                Console.WriteLine("DAY {0}:\t {1,5:N0} ", dayNumber, (int)dailyAverage[arrayIndex]);
                dayNumber++;
            }//end of for loop
        }//end of function

        //DISPLAY MEAL AVERAGE=====================================
        public static void DisplayMealAverage(double[] mealAverage)
        {
            string[] mealTypes = new string[] { "Breakfast", "Lunch", "Dinner" };
            int arrayIndex;

            Console.WriteLine("\n\n\nMEAL AVERAGES");

            for (arrayIndex = 0; arrayIndex < mealAverage.GetLength(0); arrayIndex++)
            {
                Console.WriteLine("{0,-9} : {1,5:n0}", mealTypes[arrayIndex], (int)mealAverage[arrayIndex]);
            }

        }//end of function

        //DISPLAY CALORIE AVERAGE PER MEAL (TOTAL)
        public static void DisplayAverageCaloriesPerMeal(int[,] calories)
        {
            double totalCalAverage = 0;

            for (int r = 0; r < calories.GetLength(0); r++)
            {
                for (int c = 0; c < calories.GetLength(1); c++)
                {
                    totalCalAverage += calories[r, c];
                }//end of inner loop
            }//end of outer loop
            totalCalAverage /= (calories.GetLength(0) * calories.GetLength(1));
            Console.WriteLine("\n\nCALORIE AVERAGE PER MEAL: {0:N0}", (int)totalCalAverage);
        }       
    }//end of class
}//end of namespace