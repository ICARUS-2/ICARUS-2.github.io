﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
    Testers:
    Arthur Mousatov (student in class)
    Phil Aube (student in class)
*/
namespace Prog2_A1  //track repitition of lowest accident numbers q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int userNumPress = 0;
            int exitMenuValue = 5;


            do
            {
                Console.WriteLine("************************************");
                Console.WriteLine("Welcome to \"Assignment 1 - Programming 2\"");
                Console.WriteLine("Created By Ethan Briffett");
                Console.WriteLine("************************************");
                Console.WriteLine("Please choose below:");
                Console.WriteLine("\t1- Pennies for Pay");
                Console.WriteLine("\t2- Safest Living Area");
                Console.WriteLine("\t3- Paint Job Estimator");
                Console.WriteLine("\t4- Have and break.. Play a game :)");
                Console.WriteLine("\t5- Quit");

                userNumPress = ValInt(0, exitMenuValue, "ERROR: INPUT CAN ONLY BE ONE OF THE MENU OPTIONS");

                Console.Clear();
                switch (userNumPress)
                {
                    case 1:
                        Pennies();
                        break;
                    case 2:
                        SafestLivingArea();
                        break;
                    case 3:
                        PaintJobEstimator();
                        break;
                    case 4:
                        Game();
                        break;
                }
            } while (userNumPress != exitMenuValue);
        }//end of function

        #region INPUT VALIDATOR FUNCTIONS
        //VALIDATE INTEGER INPUT WITH MIN AND MAX=================================
        static int ValInt(int minValue, int maxValue, string errorMessage)
        {
            bool isInt;
            int userNumPress;
            do
            {
                isInt = int.TryParse(Console.ReadLine(), out userNumPress);
                if (!isInt | userNumPress < minValue | userNumPress > maxValue)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("{0}", errorMessage);
                    Console.ResetColor();
                }
            } while (!isInt | userNumPress < minValue | userNumPress > maxValue);
            return userNumPress;
        }//end of function

        //VALIDATE INTEGER INPUT WITH MIN=======================================
        static int ValIntMin(int minValue, string errorMessage)
        {
            bool isInt;
            int userNumPress;
            do
            {
                isInt = int.TryParse(Console.ReadLine(), out userNumPress);
                if (!isInt | userNumPress < minValue)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("{0}", errorMessage);
                    Console.ResetColor();
                }
            } while (!isInt | userNumPress < minValue);
            return userNumPress;
        }//end of function

        //VALIDATE DOUBLE INPUT WITH MIN========================================
        static double ValDoubleMin(double minValue, string errorMessage)
        {
            bool isDouble;
            double userNumPress;
            do
            {
                isDouble = double.TryParse(Console.ReadLine(), out userNumPress);
                if (!isDouble | userNumPress < minValue)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("{0}", errorMessage);
                    Console.ResetColor();
                }
            } while (!isDouble | userNumPress < minValue);
            return userNumPress;
        }//end of function
        #endregion

        #region Question 1 - Pennies For Pay
        //QUESTION 1 - PENNIES FOR PAY==========================="This program will take a given number of days and determine how much you would make if you started with one penny and it was doubled each day
        static void Pennies()
        {
            const int convertToPennies = 100;
            int days;
            int forLoopCounter;
            double numberOfPennies = 1; //made this a double to prevent overflow at higher values, causing the program to incorrectly display negatives when overflowing
            double moneyEarned = 1; 
            double totalMoneyEarned = 0.01;

            Console.WriteLine("This program will take a given number of days and determine how much you would make if you started with one penny and it was doubled each day");
            Console.WriteLine("\n\nPlease input a number of days");

            days = ValIntMin(1, "ERROR: DAYS INPUTTED MUST BE A 32-BIT INTEGER EQUAL TO 1 OR HIGHER");

            Console.Clear();
            Console.WriteLine("Day\t\t\t\tEarning that day (pennies)\t\tTotal earnings for that day (dollars)");
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------");

            for (forLoopCounter = 0; forLoopCounter < days; forLoopCounter++)
            {
                Console.WriteLine("{0}\t\t{1, 25}\t\t\t\t\t\t{2}", forLoopCounter + 1, numberOfPennies, totalMoneyEarned.ToString("c"));

                numberOfPennies *= 2;
                moneyEarned += numberOfPennies;
                totalMoneyEarned = moneyEarned / convertToPennies;
            }
            Console.WriteLine("\nPlease press enter to return to main menu");
            Console.ReadLine();
            Console.Clear();
        }//end of function      
        #endregion
        
        #region Question 2 - Safest Living Area
        //QUESTION 2 - SAFEST LIVING AREA========================"Program will take the number of accidents for 5 different regions from the user and then outputs the region with the least accidents along with the number of accidents associated"
        static void SafestLivingArea()
        {
            int arrSize = 5;
            int loopCounter = 0;
            int leastAccidentsIndex;
            bool[] lowestRepititionArray = new bool[arrSize];
            int[] accidentArray = new int[arrSize];
            string[] regionNameArray = new string[arrSize];
            regionNameArray[0] = "north";
            regionNameArray[1] = "south";
            regionNameArray[2] = "east";
            regionNameArray[3] = "west";
            regionNameArray[4] = "central";
            Console.WriteLine("This program will take the number of car accidents from 5 different regions and output the region with the lowest number. Repitition is supported.");
            do
            {
                accidentArray[loopCounter] = GetNumAccidents(regionNameArray[loopCounter]);
                loopCounter++;
            } while (loopCounter < arrSize);

            leastAccidentsIndex = FindLowest(accidentArray, lowestRepititionArray, arrSize);

            Console.Write("The region(s) with the lowest number of accidents is ");
            for(loopCounter = 0; loopCounter < arrSize; loopCounter++)
            {
                if (lowestRepititionArray[loopCounter])
                {
                    Console.Write("{0}, ",regionNameArray[loopCounter]);
                }
            }
            Console.Write("with {0} accidents", accidentArray[leastAccidentsIndex]);
            Console.WriteLine("\nPress enter to return to main menu");
            Console.ReadLine();
            Console.Clear();
        }//end of function

        static int GetNumAccidents(string region)
        {
            int minValue = 0;
            int numberOfAccidents;
            Console.WriteLine("Please enter the number of accidents for the {0} region", region);
            numberOfAccidents = ValIntMin(minValue, "ERROR: NUMBER OF ACCIDENTS CAN ONLY BE A 32-BIT INTEGER");

            return numberOfAccidents;
        }//end of function

        static int FindLowest(int[] accidentArray, bool[] lowestRepititionArray, int arrSize)
        {
            int arrayIndexCounter = 1;
            int lowestAccidentIndex = 0;

            do
            {
                if (accidentArray[arrayIndexCounter] < accidentArray[lowestAccidentIndex])
                {
                    lowestAccidentIndex = arrayIndexCounter;
                }
                arrayIndexCounter++;
            } while (arrayIndexCounter < arrSize);

            for (arrayIndexCounter = 0; arrayIndexCounter < arrSize; arrayIndexCounter++)
            {
                if (accidentArray[arrayIndexCounter] == accidentArray[lowestAccidentIndex]) 
                {
                    lowestRepititionArray[arrayIndexCounter] = true;
                }
            }
            return lowestAccidentIndex;
        }//end of function
        #endregion

        #region Question 3 - Paint Job Estimator
        //QUESTION 3 - PAINT JOB ESTIMATOR======================="Program gets the cost/gallon of paint and the number of rooms that will be painted and outputs the cost of labour and the total cost for the job
        static void PaintJobEstimator()
        {
            int numberOfRooms;
            //int squareFeetPerRoom;
            const double SPACE_PER_GALLON = 115;
            const double MIN_PAINT_COST = 10;
            const double LABOUR_COST_PER_HOUR = 18;
            double gallonsRequired;
            double costPerGallon;
            double paintCost;
            double labourHours;
            double labourCost;
            double totalSquareFeet;
            double totalCost;
            string paintCostErrorMessage = "ERROR: COST OF PAINT MUST BE $" + MIN_PAINT_COST + " OR HIGHER"; //this variable is created here in order to avoid hard coding it in the error message later

            Console.WriteLine("This program will get the cost per gallon of paint, as well as the number of rooms and the size of those rooms to determine the cost of painting them");
            Console.Write("\n\nPlease enter the number of rooms to be painted: ");
            numberOfRooms = ValIntMin(1, "ERROR: INPUT CAN ONLY BE A 32-BIT POSITIVE INTEGER");
            Console.Write("\nPlease enter the cost per gallon of paint: ");
            costPerGallon = ValDoubleMin(MIN_PAINT_COST, paintCostErrorMessage);
            totalSquareFeet = GetSquareFeet(numberOfRooms);
            gallonsRequired = Math.Ceiling((totalSquareFeet / SPACE_PER_GALLON));
            paintCost = gallonsRequired * costPerGallon;
            labourHours = totalSquareFeet / SPACE_PER_GALLON;
            labourCost = labourHours * LABOUR_COST_PER_HOUR;
            totalCost = paintCost + labourCost;
            Console.WriteLine("\n\n\n");

            Console.WriteLine("ESTIMATED CHARGES");
            Console.WriteLine("----------------------");
            Console.Write("Total area:\t\t\t {0:n2}", totalSquareFeet);// Console.Write(totalSquareFeet.ToString("n2"));
            Console.Write("\nGallons of paint:\t\t {0}", gallonsRequired); //Console.Write(gallonsRequired.ToString("n2"));
            Console.Write("\nPrice per gallon\t\t {0:c}", costPerGallon); //Console.Write(costPerGallon.ToString("c"));
            Console.Write("\nPaint cost:\t\t\t {0:c}", paintCost); //Console.Write(paintCost.ToString("c"));
            Console.Write("\nLabour hours required:\t\t {0:n2}", labourHours); //Console.Write(labourHours.ToString("n2"));
            Console.Write("\nLabour cost @ {0:c} /hr:\t {1:c}", LABOUR_COST_PER_HOUR, labourCost); //Console.Write(LABOUR_COST_PER_HOUR.ToString("c")); Console.Write("/hr\t\t"); Console.Write(labourCost.ToString("c"));
            Console.Write("\nTotal charges:\t\t\t {0:c}", totalCost); //Console.Write(totalCost.ToString("c"));
            Console.Write("\n\nPress enter to return to main menu");
            Console.ReadLine();
            Console.Clear();
        }//end of function

        static double GetSquareFeet(int numberOfRooms)
        {
            int loopCounter;
            int currentRoomNumber = 1;
            double squareFeet;
            double totalSquareFeet = 0;

            for (loopCounter = 0; loopCounter < numberOfRooms; loopCounter++)
            {
                Console.Write("\nPlease enter the square footage of room {0}: ", currentRoomNumber);
                squareFeet = ValDoubleMin(1, "ERROR: PLEASE ENTER A NUMBER EQUAL TO 1 OR HIGHER");
                totalSquareFeet += squareFeet;
                currentRoomNumber++;
            }
            return totalSquareFeet;
        }//end of function
        #endregion

        #region Question 4 - Rock Paper Scissors
        //QUESTION 4 - ROCK PAPER SCISSORS GAME=================="Program allows you to play a game of Rock Paper Scissors with the computer"
        static void Game()
        {
            Random random = new Random();
            int computerChoice;
            int playerChoice;
            const int randomMax = 4;
            const int minChoice = 1;
            const int maxChoice = 3;
            string outcome;
            bool forceLoop;

            Console.WriteLine("ROCK PAPER SCISSORS");
            Console.WriteLine("\nCHOOSE AN OPTION TO PLAY");
            Console.WriteLine("1 - ROCK");
            Console.WriteLine("2 - PAPER");
            Console.WriteLine("3 - SCISSORS");
            do
            {
                forceLoop = false;
                computerChoice = random.Next(1, randomMax);
                playerChoice = ValInt(minChoice, maxChoice, "ERROR: PLEASE TYPE ONLY ONE OF THE NUMBERED OPTIONS");
                outcome = CheckOutcome(playerChoice, computerChoice);


                switch(computerChoice) //this switch statement outputs the computer choice
                {
                    case (int)RPSValues.Rock:
                        Console.WriteLine("Opponent chose ROCK");
                        break;
                    case (int)RPSValues.Paper:
                        Console.WriteLine("Opponent chose PAPER");
                        break;
                    case (int)RPSValues.Scissors:
                        Console.WriteLine("Opponent chose SCISSORS");
                        break;
                }
                Console.WriteLine();
                switch(outcome) //this switch statement outputs the outcome
                {
                    case "PLAYER_WIN":
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("YOU WON");
                        break;
                    case "COMPUTER_WIN":
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("YOU LOST");
                        break;
                    case "DRAW":
                        Console.ForegroundColor = ConsoleColor.DarkBlue;
                        Console.WriteLine("DRAW, PLAY AGAIN");
                        forceLoop = true;
                        break;
                }//end of switch statement
                Console.ResetColor();
            } while (forceLoop);

            Console.WriteLine("\nPress enter to return to main menu");
            Console.ReadLine();
            Console.Clear();
        }//end of function
        
        enum RPSValues //rock paper scissors values
        {
            //values for each option
            Rock = 1,
            Paper = 2,
            Scissors = 3,
            //values for outcomes
            RockPaperOutcome = 3,
            RockScissorsOutcome = 4,
            PaperScissorsOutcome = 5,
        }//end of enum

        static string CheckOutcome(int playerChoice, int computerChoice)
        {
            int outcomeValue;

            if (playerChoice == computerChoice)
                return "DRAW";            
            
            outcomeValue = playerChoice + computerChoice;

            if (((outcomeValue == (int)RPSValues.RockPaperOutcome) && (playerChoice == (int)RPSValues.Paper))   ||   ((outcomeValue == (int)RPSValues.RockScissorsOutcome) && (playerChoice == (int)RPSValues.Rock)) || ((outcomeValue == (int)RPSValues.PaperScissorsOutcome) && (playerChoice == (int)RPSValues.Scissors)))
            {
                return "PLAYER_WIN";
            }

            return "COMPUTER_WIN";
        }//end of function
        #endregion
         
    }//end of class
}//end of namespace
