# TNNF FINAL PROJECT TEAM CONTRACT

This is an informal contract to ensure that all team members have a common understanding of what is expected in terms of work standards, communication, division or work, and conflict resolution.

## Team Members
-   Member A: Phil Aube
-   Member B: Ethan Briffett
-   Member C: Tarik Bikhandafne

## Strengths & Weaknesses
Within the context of this project, what are the strengths and weaknesses that each member brings to the team?

-   Phil: UI and front-end design are definitely my strong suits. I am definitely a bit weaker when it comes to new things, but with time I can get used to anything.
-   Ethan: I tend to pick up new topics quite quickly. Backend and database interaction tend to be my strongest aspects, whereas my weakness tends to be with UI design.
-   Tarik: I’m quick to learn new things, but I have some deficiencies in front-end design. Quick to come up with creative solutions.

## Definition of “good enough” for this project

What would the team collectively consider “good enough” of an achievement for the project? 

A clean, intuitive, user-friendly and professional-looking UI which meets ALL of its requirements. It should be easily navigable for non-technical people, and optimally, it should be able to scale well with future changes.

## Division of work

How will each member contribute to the project?

-   Phil: Plant Subsystem
-   Ethan: Security Subsystem
-   Tarik: Geo-location Subsystem

In terms of the mobile application, we have no concrete plans as of yet, but we plan to be working on our individual subsystems’ front and back ends primarily. Ethan may focus more on databases, Phil may focus more on UI/UX design, and Tarik will focus on any other miscellaneous tasks that may be required, such as software and hardware testing and managing the user stories.

## Frequency of communication

How often will the team be in touch and what tools will be used to communicate?

Communication will be performed on an ad-hoc basis (via Discord for our private meetings or Teams chat for public/teacher communication), and responses are expected within a 24-hour window between team members. If some deliverables are expected soon, meetings can be held each sprint whenever they are needed, to discuss any progress, blockers or any other concerns.

## Response delays

What is a reasonable delay to reply to messages? Is it the same for weekdays and weekends?

We will try to be able to adequately respond to all messages within 24 hours of receiving them. Typically, we respond to each other as soon as a notification is received.

## Receiving feedback

Each member must provide a sample sentence for how they would like to receive constructive feedback from their peers.

-   Phil: "We feel like you could be doing better in terms of contributions to our team. Are you having trouble with something, or is there anything you think you need help with?"
-   Ethan: "So I have noticed that {0} and {1} could have been done a little bit better. You may want to consider making {2} and {3} changes in order to be more productive in the future. Can we be of assistance at all?"
-   Tarik: "I have noticed that there has been a deficiency in your work that does not meet our standards, may you tell us what is the nature of your blockage? Please take these suggestions into consideration."

## In case of conflict

If a team member fails to communicate as described in this contract or does not respond to constructive feedback, what measures should the other teammate take?

In the case of a teammate not pulling their own weight, the plan is to maintain constant communication with them, providing constructive criticism that would better set them up for success. If nothing works, as an absolute last resort, the plan would be to communicate with teachers regarding any concerns that we have about the person. Chances are, with what we have planned, any problems would be nipped in the bud through direct communication.