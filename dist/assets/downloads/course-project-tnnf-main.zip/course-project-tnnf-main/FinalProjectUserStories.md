﻿FINAL PROJECT USER STORIES Phil A / Ethan B / Tarik B

**FARM TECHNICIAN**

**EPIC #1: As the farm technician, I want to know the environmental conditions inside the containers in near real-time so that I can make necessary adjustments.**

1. As a farm technician, I want to see the past temperature readings so that I can keep track of any abnormalities, and take action if necessary.
   1. Temperature data is sent to Azure from the device.
1. As a farm technician, I want to be able to see a historical graph of the temperature data so that I can tell when the lights were turned on.
   1. Shows graph of Azure historical data when temperature element is pressed.
1. As a farm technician, I want to see the current temperature reading so that I can know what the temperature is at any given moment.
   1. Temperature data is sent to Azure from the device
   1. Temperature is read from Azure and updates in real time on the GUI.
1. As a farm technician, I want to see past humidity readings so that I can keep track of any abnormalities, and take action if necessary.
   1. Humidity data is sent to Azure from the device.
   1. Shows a graph of collected historical data when humidity element is pressed.
1. As a farm technician, I want to see the current humidity reading so that I can know what the humidity is at any given moment.
   1. Humidity data is sent to Azure from the device.
   1. Humidity is read from Azure and updates in real time in the GUI.
1. As a farm technician, I want to see the past relative water levels so that I can take appropriate action if necessary.
   1. Relative water level data is sent to Azure from the device.
   1. Shows a graph of collected historical water level data when pressed.
1. As a farm technician, I want to see the current relative water levels so that I can know what the relative water levels are at any given moment.
   1. Relative water level data is sent to Azure from the device.
   1. Relative water level is read from Azure and updates in real time in the GUI.
1. As a farm technician, I want to see the past soil moisture level readings so that I can keep track of any abnormalities, and take action if necessary.
   1. Soil moisture level data is sent to Azure from the device.
   1. Shows a graph of collected historical soil moisture level data when pressed.
1. As a farm technician, I want to see the current soil moisture level reading so that I can know what the soil moisture levels are at any given moment.
   1. Soil moisture level data is sent to Azure from the device.
   1. Soil moisture level is read from Azure and updates in real time in the GUI.

**EPIC #2: As the farm technician, I need to be able to control the environmental conditions inside the containers to make sure that plants are healthy.**

1. As a farm technician, I want to be able to turn the fan on and off manually so that I can control the temperature as I see fit.
   1. Fan state data is sent to Azure.
   1. Fan state is read from Azure and is displayed in the GUI on a switch.
   1. Fan state can be changed via the same GUI switch element.
2. As a farm technician, I want to be able to turn the LED on and off manually so that I can control the lighting inside the containers as I see fit.
   1. LED state data is sent to Azure.
   1. LED state is read from Azure and is displayed in the GUI on a switch.
   1. LED state can be changed via the same GUI switch element.
3. As a farm technician, I want to be able to set a temperature at which the fans should automatically turn on and off so that I don’t always have to set it manually.
   1. Fan temperature threshold is read from Azure.
   1. Fan temperature threshold is displayed in GUI.
   1. Fan temperature threshold can be changed from the GUI.
   1. Any changes to the threshold should be reflected on the device.

**EPIC #3: As a farm technician, I want to log in to the application so that I can access the features endemic to my account from the application.**

1. As a farm technician, I want to be able to access the plant subsystem from the application, So I can better attend to the plants.
   1. Users with farm technician credentials would be able to access temperature and humidity data from the application.
   1. Users with farm technician credentials would be able to access water level data from the application.
   1. Users with farm technician credentials would be able to access moisture level data from the application.
   1. Users with farm technician credentials would be able to access fan state data from the application.
   1. Users with farm technician credentials would be able to control fan state from the application.
   1. Users with farm technician credentials would be able to access light state data from the application.
   1. Users with farm technician credentials would be able to control light state from the application.
2. As a farm technician, I want to be able to access the geo-location subsystem, So I can be aware of imminent positional risks to the plants.
   1. Users with farm technician credentials would be able to access pitch, roll and banking angles data from the application.
   2. Users with farm technician credentials would be able to access vibration level data from the application.
   2. Users with farm technician credentials would be able to access buzzer state data from the application.
3. As a farm technician, I want to be able to access the security subsystem, So I can be aware of imminent security risks to the plants.
   1. Users with farm technician credentials would be able to access noise level data from the application.
   1. Users with farm technician credentials would be able to access luminosity level data from the application.
   1. Users with farm technician credentials would be able to access motion sensor state data from the application.

**FLEET MANAGER**

**EPIC #1: As the fleet manager, I want to know the location and placement of the container farms so that I can track company assets.**

1. As a fleet manager, I want to see the GPS coordinates of the containers so I can know where the containers are at all times.
   1. Coordinates data sent to Azure.
   1. Coordinates data received from Azure and are displayed in the GUI.
1. As a fleet manager, I want to see the GPS coordinates represented by a map element so that I can easily determine the location of the container.
   1. Have a map view in the GUI that takes in GPS coordinates and displays them.
   1. Map view uses a Map GUI Api.
1. As a fleet manager, I want to know the pitch angle so that I can know if there is a positional threat to the containers.
   1. Data sent to Azure.
   1. Data received from Azure.
   1. Send notification to the user's phone if a container is not level.
4. As a fleet manager, I want to know the roll angle so that I can know if there is a positional threat to the containers.
   1. Data sent to Azure.
   1. Data received from Azure.
   1. Send notification to the user's phone if a container is not level.
5. As a fleet manager I want to know the level of vibration happening around and inside the containers so I can be made aware of any danger to the containers or plants.
   1. Data sent to Azure.
   1. Data received from Azure.
   1. Send notification to the user's phone if a container is not stable.
6. As a fleet manager I want to keep track of variations of pitch data so I can make better assessments on long term stability/risk.
   1. Pitch data represented in the app can be displayed with a graph.
6. As a fleet manager I want to keep track of variations of row data so I can make better assessments on long term stability/risk.
   1. Row data represented in the app can be displayed with a graph.
6. As a fleet manager I want to keep track of variations of vibration data so I can make better assessments on long term stability/risk.
   1. Vibration data represented in the app can be displayed with a graph.
6. As a fleet manager I want to keep track of variations of Buzzer state data so I can make better assessments on long term stability/risk.
   1. Buzzer state data represented in the app can be displayed with a graph.
6. As a fleet manager I want a buzzer to be used as an alarm for container misplacement, so that it can be used as a signal to communicate a geo-location issue.
   1. If the angles go over/under acceptable thresholds, trigger an alarm.
   1. If the vibration levels go over/under acceptable thresholds, trigger an alarm.
6. As a fleet manager, I want to be able to be able to control the alarm so that I can manually activate or deactivate the alarm in case of a technical issue or poor management of thresholds.
   1. The user interface should have a button with two possible states: Activate alarm and deactivate alarm.
6. As a fleet manager I want to set a “home position” for the containers so that containers do not get stolen or lost as easily.
   1. If the GPS shows that the container’s position is outside a radius of the “home position” it triggers an alert and sets off the buzzer alarm.

**EPIC #2: As the fleet manager, I want to be informed of security issues inside the container farms so that I can mobilize an appropriate response.**

1. As a fleet manager, I want to be notified of any unexpected movement inside the containers so that I can take action on any potential intruders.
   1. Send and receive motion detection data from Azure.
   1. Send a notification to the user’s phone upon detection of movement.
1. As a fleet manager, I want to be able to see the luminosity data from inside the containers so I can see if the lights were turned on or not.
   1. The interface should display a real-time luminosity sensor value.

3. As a fleet manager, I want to be able to see a historical graph of the luminosity data so that I can tell when the lights were turned on.
   1. Clicking on the light level menu item should take me to a page where I can see a historical graph for the light level.
3. As a fleet manager, I want to be able to see the data from the motion sensor so that I know if anyone is breaking into the facility.
   1. The interface should always be displaying a real-time motion sensor value.
3. As a fleet manager, I want to be able to see the past data from the motion sensor so that I can know when people were entering and leaving the room.
   1. Clicking on the motion sensor menu item should take me to a page where I can see historical data for the device.
3. As a fleet manager, I want to be able to see if the door is open or not so that I can see when people are exiting and entering.
   1. The interface should have an item that displays whether it is open or not.
3. As a fleet manager, I want to be able to control the door so that I can lock it when nobody is working.
   1. The interface should have a switch on it that allows me to toggle whether the door is locked or unlocked.
3. As a fleet manager, I want to be able to see the historical data for the door state so that I know when people came and went.
   1. Clicking on the door menu should take me to a page where I can see all of the lock/unlock actions for the door.
1. As a fleet manager, I want to be able to be able to control the alarm so that I can alert people about a security issue manually in the event of a security breach that wasn’t detected automatically.
   1. The interface should have a button with two possible states: Activate alarm and deactivate alarm.
   1. This should be completely independent of the arm state.
1. As a fleet manager, I want the alarm to go off if the motion sensor/noise sensor triggers when armed so that people can be notified of any unauthorized entry.
   1. The interface should have a switch to change the arm state to on or off.
   1. The interface should display a notification if the alarm gets triggered.
   1. The alarm gets triggered when the buzzer is on + the motion sensor gets triggered.
1. As a fleet manager, I want to be able to schedule times for the alarm to arm/disarm automatically so that I do not have to do it manually.
   1. The interface should have a toggle switch menu option for scheduling arm/disarm times.
   1. When the switch is toggled on, there should be two time pickers, one for arm time, the other for disarm time.
   1. When the switch is toggled on, a second switch should appear for optional notifications when it becomes armed or disarmed automatically.
1. As a fleet manager, I want to be able to schedule times for the door to automatically lock/unlock so that I do not have to do it manually.
   1. The interface should have a toggle switch menu option for scheduling lock/unlock times.
   1. When the switch is toggled on, there should be two time pickers, one for lock time, the other for unlock time.
   1. When the switch is toggled on, a second switch should appear for optional notifications when it becomes locked or unlocked automatically.

**EPIC #3: As a Fleet Manager, I want to log in to the application so that I can access the features endemic to my account from the application.**

1. As a fleet manager, I want to be able to access the plant subsystem, So I can be aware of the state of the plants within a container.
   1. Users with fleet manager credentials would be able to access temperature and humidity data from the application.
   1. Users with fleet manager credentials would be able to access water level data from the application.
   1. Users with fleet manager credentials would be able to access moisture level data from the application.
   1. Users with fleet manager credentials would be able to access fan state data from the application.
   1. Users with fleet manager credentials would be able to access light state data from the application.
5. As a fleet manager, I want to be able to access the geo-location subsystem, So I can be aware of all positional risks to a container.
   1. Users with fleet manager credentials would be able to access GPS data from the application.
   1. Users with fleet manager credentials would be able to access pitch, roll and banking angles data from the application.
   1. Users with fleet manager credentials would be able to access vibration level data from the application.
   1. Users with fleet manager credentials would be able to access buzzer state data from the application.
   1. Users with fleet manager credentials would be able to control buzzer state from the application.
6. As a fleet manager, I want to be able to access the security subsystem, So I can be aware of any security risks to a container.
   1. Users with fleet manager credentials would be able to access noise level data from the application.
   1. Users with fleet manager credentials would be able to access luminosity level data from the application.
   1. Users with fleet manager credentials would be able to access motion sensor state data from the application.
   1. Users with fleet manager credentials would be able to access door lock state data from the application.
   5. Users with fleet manager credentials would be able to control door lock state from the application.
   5. Users with fleet manager credentials would be able to access buzzer state data from the application.
   5. Users with fleet manager credentials would be able to control buzzer state from the application.
   5. Users with fleet manager credentials would be able to access door state data from the application.
