﻿FINAL PROJECT DESIGN DOCUMENT Phil A / Ethan B / Tarik B

**Functional Overview**: The application’s main page will stem from a tabbed page with 3 items, one for each subsystem. Each of the 3 tab pages will contain the necessary controls for the subsystems, as well as the buttons to navigate to the historical data pages for each component.

**Design Overview:** The user will be able to select from their list of containers which will take them to the tabbed page. Within each tab, there will be different menu items for each sensor. Clicking any of these will take the user to the page for that sensor’s historical data, whether it be state history or a graph of values.

**Screen Analysis/Design:**

All Containers: A list view containing clickable entries, each of which leads to the tabbed page for that container.

Tabbed page: A page containing three tabs, one for each subsystem.

My Plants: A page containing sensor data and controls for the Plant subsystem. Clicking any of the control options will bring the user to the historical data for that component.

- Historical data - water level: Contains a line graph showing the water level within the container from the sensor.
- Historical data - Humidity: Contains a line graph showing the humidity from the AHT20 sensor.
- Historical data - Temperature: Contains a line graph showing the temperature from the AHT20 sensor.
- Historical data - Moisture: Contains a line graph showing the moisture level from the sensor.
- Historical data - Fan state: Contains a list of entries showing the times that the fan was toggled on or off.

My Container: A page containing sensor data and controls for the Geolocation subsystem. Clicking any of the control options will bring the user to the historical data for that component.

- Historical data - buzzer state: Contains a list of entries showing the times that the Buzzer was turned on or off.
- Historical data - vibration: Contains a line graph showing the vibration level from the vibration sensor.
- Historical data - pitch angle: Contains a line graph showing the angle position from the sensor.
- Historical data - moisture: Contains a line graph showing the moisture level from the sensor.

Security: A page containing sensor data and controls for the Plant subsystem. Clicking any of the control options will bring the user to the historical data for that component.

- Historical data - noise level: Contains a line graph showing the noise level within the container.
- Historical data - light level: Contains a line graph showing the light level from the luminosity sensor.
- Historical data - Door lock state: Contains a list of entries showing when the door lock was turned on or off.
- Historical data - Buzzer state: Contains a list of entries showing when the alarm was triggered, enabled, or disabled.

![](Navgraph.png)

**Prioritization of features**

- **Plant subsystem:** Must develop:
  - As a farm technician, I want to see the current and past temperature readings so that I can keep track of any abnormalities, and take action if necessary.
  - As a farm technician, I want to see the current past humidity readings so that I can keep track of any abnormalities, and take action if necessary.

-As a farm technician, I want to see the current and past relative water levels so that I can take appropriate action if necessary.

-As a farm technician, I want to see the current and past soil moisture level readings so that I can keep track of any abnormalities, and take action if necessary.

- As a farm technician, I want to be able to turn the fan on and off manually so that I can control the temperature as I see fit.

Would like to develop:

- As a farm technician, I want to be able to set a temperature at which the fans should automatically turn on and off so that I don’t always have to set it manually.
- **Geolocation subsystem:** Must develop:
  - As a fleet manager, I want to see a map location so that I can know exactly where my container is at all times.
  - As a fleet manager, I want to know the pitch, roll and banking angles so that I can know if there is a positional threat to the container.
  - As a fleet manager I want to know the level of vibration happening around and inside the container so I can be made aware of any danger to the container or plants.
  - As a fleet manager I want a buzzer to be used as an alarm for container misplacement, so that it can be used as a signal to communicate a geo-location issue.

Would like to develop:

- As a fleet manager I want to set a “home position” for the container so that containers do not get stolen or lost as easily.
- **Security subsystem:** Must develop:
  - As a fleet manager, I want to be notified of any unexpected movement inside the container so that I can take action on any potential intruders.
  - As a fleet manager, I want to be able to see the luminosity data from inside the container to see if the lights were turned on or not.
  - As a fleet manager, I want to be able to see the data from the motion sensor so that I know if anyone is breaking into the facility.
  - As a fleet manager, I want to be able to control the door so that I can lock it when nobody is working.
  - As a fleet manager, I want to be able to be able to control the alarm so that I can alert people about a security issue manually in the event of a security breach that wasn’t detected automatically
  - As a fleet manager, I want the alarm to go off if the motion sensor/noise sensor triggers when armed so that people can be notified of any unauthorized entry.

Could develop if time permits:

- As a fleet manager, I want to be able to schedule times for the alarm to arm/disarm automatically so that I do not have to do it manually.
- As a fleet manager, I want to be able to schedule times for the door to automatically lock/unlock so that I do not have to do it manually.

**Proposed implementation schedule**

Sprint 2:

Have the core features of the UI developed:

- List page
- Tabbed page.
- Each of the 3 pages stemming from it.
- Placeholder pages for the historical data.

Sprint 3:

Configure the telemetry data:

- Be able to send and receive telemetry data from all of the sensors
- Begin structuring the direct methods in the backend

Sprint 4:

Connect the user interface to the hub

- Be able to control the sensors and have them be updated with the sensors’ current state.
- Configure routing and storage for historical data, implement visualization for this with graphs and charts.

Sprint 5:

- Finish anything UI/storage/routing related that was not completed in the previous sprint.
- Work on the “Would like to develop” and “Could develop if time permits” features

**Questions:**

Plant technician has LED listed in sensors but not hardware requirements. Did you forget to mention that the farmer needs to control lighting?

Will the buzzer be a separate component for security and geolocation?

(Security) For the alarm, can we have one switch to arm/disarm it, and a button with two states to trigger it manually?

How do you want us to separate the GUI for each stakeholder? Is our current approach acceptable?

Are we going to need a login screen?
