﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.ComponentModel;

namespace TNNFContainers.Models.Subsystems
{
    /// <summary>
    /// Contains the properties for the container's Plant subsystem
    /// </summary>
    public class PlantSusbsystemModel : INotifyPropertyChanged
    {
        /// <summary>
        /// Default Constructor, sets all properties to null.
        /// </summary>
        public PlantSusbsystemModel()
        {
            Temperature = null;
            Humidity = null;
            WaterLevel = null;
            SoilMoisture = null;
            IsFanSpinning = null;
            IsLightOn = null;
        }
        /// <summary>
        /// The temperature inside the container
        /// </summary>
        public double? Temperature { get; set; }

        /// <summary>
        /// The humidity level inside the container
        /// </summary>
        public double? Humidity { get; set; }

        /// <summary>
        /// The water level inside the container
        /// </summary>
        public double? WaterLevel { get; set; }

        /// <summary>
        /// The moisture level inside the container
        /// </summary>
        public double? SoilMoisture { get; set; }

        /// <summary>
        /// Whether the fan is spinning or not
        /// </summary>
        public bool? IsFanSpinning { get; set; }

        /// <summary>
        /// Whether the lights are on or not.
        /// </summary>
        public bool? IsLightOn { get; set; }

        /// <summary>
        /// Needed for Fody auto-inject
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
