﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using System.ComponentModel;
using System.Windows.Input;
using TNNFContainers.Helpers;
using Xamarin.Forms;
using Xamarin.CommunityToolkit.Extensions;

namespace TNNFContainers.ViewModels
{
    /// <summary>
    /// Contains the data for server configuration
    /// </summary>
    public class ConnectionStringsViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// The connection string to the Iot Hub
        /// </summary>
        public string ConnectionString { get; set; }

        /// <summary>
        /// The connection string for the built-in endpoint
        /// </summary>
        public string EndpointConnectionString { get; set; }

        /// <summary>
        /// Handles saving the data
        /// </summary>
        public ICommand SaveCommand { get; set; }

        /// <summary>
        /// Clears the hub connection string
        /// </summary>
        public ICommand ClearConnectionStringCommand { get; set; }

        /// <summary>
        /// Clears the endpoint connection string
        /// </summary>
        public ICommand ClearEndpointConnectionStringCommand { get; set; }

        /// <summary>
        /// Configures Save command
        /// </summary>
        public ConnectionStringsViewModel()
        {
            SaveCommand = new Command<ContentPage>(SaveCommandFunction);
            ClearConnectionStringCommand = new Command(ClearConnectionStringFunction);
            ClearEndpointConnectionStringCommand = new Command(ClearEndpointConnectionStringFunction);
        }

        /// <summary>
        /// Saves the new connection string data in the helper and the file
        /// </summary>
        private async void SaveCommandFunction(ContentPage page)
        {
            //Sets the connection strings the app uses.
            IotDeviceDataHelper.CONNECTION_STRING = ConnectionString;
            IotDeviceDataHelper.ENDPOINT_CONNECTION_STRING = EndpointConnectionString;

            //Just in case...
            App.MainViewModel.ContainerRepository.Containers.Clear();

            //Can only update the containers if we are connected to the internet.
            if (IotDeviceDataHelper.CheckConnection())
                App.MainViewModel.ContainerRepository.Containers = await IotDeviceDataHelper.GetAllContainers();

            //Leave the page once the settings are saved.
            App.MainViewModel.Navigation.PopAsync();

            try
            {
                //Persists the saved connection strings in the config file.
                IotDeviceDataHelper.SaveConnectionStrings();

                //Notifies the UI that the calculated server name properties should be updated to reflect the saved changes.
                App.MainViewModel.NotifyForCalculatedProperties();

                //If we got this far, notify the user.
                page.DisplayToastAsync("Changes saved successfully.");
            }
            catch(Exception e)
            {
                //Notify the user if something broke.
                page.DisplayToastAsync("An error occured while saving the changes.");
            }
        }

        /// <summary>
        /// Fired when the user presses Clear on the connection string field.
        /// </summary>
        private void ClearConnectionStringFunction()
        {
            ConnectionString = "";
        }

        /// <summary>
        /// Fired when the user presses Clear on the endpoint connection string field.
        /// </summary>
        private void ClearEndpointConnectionStringFunction()
        {
            EndpointConnectionString = "";
        }

        /// <summary>
        /// Used for Fody auto-inject
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
