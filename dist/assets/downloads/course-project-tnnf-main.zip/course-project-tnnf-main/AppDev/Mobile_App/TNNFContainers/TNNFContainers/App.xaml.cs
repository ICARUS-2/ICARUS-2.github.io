﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using TNNFContainers.Helpers;
using TNNFContainers.Repos;
using TNNFContainers.ViewModels;
using Xamarin.Forms;

namespace TNNFContainers
{
    public partial class App : Application
    {
        public static AppViewModel MainViewModel { get; set; }

        public App()
        {
            InitializeComponent();

            MainViewModel = new AppViewModel();

            MainViewModel.ContainerRepository = new ContainerRepository();

            MainViewModel.HistoricalDataRepository = new HistoricalDataRepository();

            MainPage = new NavigationPage(new LoginPage());
        }

        protected override async void OnStart()
        {
            //Retrieves the connection strings 
            IotDeviceDataHelper.GetAddresses();
            
            //Cannot retrieve containers if not connected to the internet
            if (!IotDeviceDataHelper.CheckConnection())
                return;
            try
            {
                //Retrieves all of the containers for a given server
                MainViewModel.ContainerRepository.Containers = await IotDeviceDataHelper.GetAllContainers();
            }
            catch (Exception e)
            {
                //Network error
                return;
            }
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
