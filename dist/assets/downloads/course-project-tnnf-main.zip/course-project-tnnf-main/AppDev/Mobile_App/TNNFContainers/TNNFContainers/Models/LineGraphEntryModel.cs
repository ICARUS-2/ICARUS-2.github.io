﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;

namespace TNNFContainers.Models
{
    /// <summary>
    /// Represents one entry in a line graph chart
    /// </summary>
    public class LineGraphEntryModel
    {
        /// <summary>
        /// The Y axis value
        /// </summary>
        public double Value { get; set; }

        /// <summary>
        /// The date the value was recorded (x-axis value)
        /// </summary>
        public DateTime TimeStamp { get; set; }
    }
}
