﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.Windows.Input;
using TNNFContainers.Views;
using Xamarin.Forms;

namespace TNNFContainers.ViewModels
{
    /// <summary>
    /// Serves as the viewmodel for a dummy login screen that does nothing.
    /// </summary>
    public class LoginViewModel
    {
        /// <summary>
        /// The login function that simply opens a new containers collection page
        /// </summary>
        public ICommand LoginTechnician { get; set; }

        /// <summary>
        /// The logout function that is unused in the test version
        /// </summary>
        public ICommand LoginManager { get; set; }

        /// <summary>
        /// Default constructor initializes the Login ICommand
        /// </summary>
        public LoginViewModel()
        {
            LoginTechnician = new Command(LoginAsTech);
            LoginManager = new Command(LoginAsManager);
        }

        /// <summary>
        /// Limits the UI to only what a Technician should see.
        /// </summary>
        private void LoginAsTech()
        {
            App.MainViewModel.IsTechnician = true;
            App.MainViewModel.Navigation.PushAsync(new ContainersCollectionPage());
        }

        /// <summary>
        /// Limits the UI to only what a Fleet Manager should see.
        /// </summary>
        private void LoginAsManager()
        {
            App.MainViewModel.IsManager = true;
            App.MainViewModel.Navigation.PushAsync(new ContainersCollectionPage());
        }

    }
}
