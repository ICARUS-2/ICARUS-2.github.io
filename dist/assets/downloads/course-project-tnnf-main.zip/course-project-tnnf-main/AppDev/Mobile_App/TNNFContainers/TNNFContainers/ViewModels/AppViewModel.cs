﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using TNNFContainers.Helpers;
using TNNFContainers.Interfaces;
using TNNFContainers.Models;
using TNNFContainers.Views;
using TNNFContainers.Views.Historical;
using Xamarin.Forms;

namespace TNNFContainers.ViewModels
{
    /// <summary>
    /// Contains global data for the application
    /// </summary>
    public class AppViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// The nav controller for the application
        /// </summary>
        public INavigation Navigation { get; set; }

        /// <summary>
        /// Used to keep track of all containers
        /// </summary>
        public IContainerRepository ContainerRepository { get; set; }

        /// <summary>
        /// Used to retrieve historical data for the containers' components
        /// </summary>
        public IHistoricalDataRepository HistoricalDataRepository { get; set; }

        /// <summary>
        /// Handles the container CollectionView selection changing
        /// </summary>
        public ICommand SelectionChangedCommand { get; set; }
        
        /// <summary>
        /// Handles the clicking of any of the menu items that retrieve line chart data
        /// </summary>
        public ICommand HistoricalGraphCommand { get; set; }

        /// <summary>
        /// Handles the clicking of any of the menu items that retrieve state table data
        /// </summary>
        public ICommand HistoricalStatesCommand { get; set; }

        /// <summary>
        /// Handles refreshing the current container.
        /// </summary>
        public ICommand RefreshCommand { get; set; }

        /// <summary>
        /// Handles navigating to configure page
        /// </summary>
        public ICommand NavConfigureServerCommand { get; set; }
        
        /// <summary>
        /// Handles navigation to the edit container page.
        /// </summary>
        public ICommand NavigateToEdit { get; set; }

        /// <summary>
        /// Handles saving the modifications to the container
        /// </summary>
        public ICommand SaveContainerEdits { get; set; }

        public ICommand RefreshListCommand { get; set; }

        /// <summary>
        /// Refers to the selected container item in the CollectionView
        /// </summary>
        public ContainerModel SelectedContainer { get; set; }

        /// <summary>
        /// The container that we are currently examining
        /// </summary>
        public ContainerModel CurrentContainer { get; set; }

        /// <summary>
        /// Retrieves the name of the current server (IoT Hub)
        /// </summary>
        public string DisplayServerName
        {
            get
            {
                try
                {
                    return IotDeviceDataHelper.CONNECTION_STRING.Split('.')[0].Replace("HostName=", "");
                }
                catch(Exception ex)
                {
                    return "Invalid server";
                }
            }
        }

        /// <summary>
        /// Retrieves container data in the form "Server1 - Container1"
        /// </summary>
        public string DisplayMyContainerData
        {
            get
            {
                return DisplayServerName + " - " + CurrentContainer.Name;
            }
        }

        /// <summary>
        /// Default constructor initializes the ICommands
        /// </summary>
        public AppViewModel()
        {
            SelectionChangedCommand = new Command<CollectionView>(SelectionChangedFunction);
            HistoricalGraphCommand = new Command<LineChartType>(HistoricalGraphFunction);
            HistoricalStatesCommand = new Command<StateTableType>(HistoricalStatesFunction);
            RefreshCommand = new Command<string>(RefreshContainer);
            NavConfigureServerCommand = new Command(NavConfigureServerFunction);
            NavigateToEdit = new Command<ContainerModel>(NavigateToEditContainer);
            SaveContainerEdits = new Command<string>(SaveEdits);
            RefreshListCommand = new Command(RefreshAllContainers);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Triggered if the selected container is changed
        /// </summary>
        /// <param name="view">The collectionView the event was fired from</param>
        private void SelectionChangedFunction(CollectionView view)
        {
            //Prevents the page from opening more than once.
            if (Navigation.NavigationStack.Last().GetType() == typeof(MainTabPage))
                return;

            //Prevents the event listener from firing a second time.
            if (view.SelectedItem == null)
                return;

            //The current container should be the one the user selected.
            //Note that this is separate from SelectedContainer, which is only used for the UI.
            CurrentContainer = (ContainerModel)view.SelectedItem;

            //Navigates to the telemetry page with 3 tabs.
            Navigation.PushAsync(new MainTabPage());

            //Prevents the bug where the same item cannot be selected twice in a row.
            view.SelectedItem = null;
        }

        /// <summary>
        /// Creates a new line graph historical data page
        /// </summary>
        /// <param name="type">The component type to display data for</param>
        private void HistoricalGraphFunction(LineChartType type)
        {
            Navigation.PushAsync(new LineGraphPage(type));
        }

        /// <summary>
        /// Creates a new state table historical data page
        /// </summary>
        /// <param name="type">The component type to display data for</param>
        private void HistoricalStatesFunction(StateTableType type)
        {
            Navigation.PushAsync(new StateTablePage(type));
        }

        /// <summary>
        /// If the app is currently refreshing the Plant subsystem from the RefreshView
        /// </summary>
        public bool IsRefreshingPlant { get; set; }

        /// <summary>
        /// If the app is currently refreshing the Geolocation subsystem from the RefreshView
        /// </summary>
        public bool IsRefreshingGeo { get; set; }

        /// <summary>
        /// If the app is currently refreshing the Security subsystem from the RefreshView
        /// </summary>
        public bool IsRefreshingSec { get; set; }

        public bool IsRefreshingContainers { get; set; }

        /// <summary>
        /// Refreshes container with new data pulled from the server.
        /// </summary>
        /// <param name="sysName">The name of the subsystem</param>
        private async void RefreshContainer(string sysName)
        {
            //Cannot populate data if it cannot connect to the server to obtain it.
            if (!IotDeviceDataHelper.CheckConnection())
                return;

            //Flags the current subsystem as currently refreshing.
            ToggleSubSystemRefresh(sysName);

            //Will store the list of containers from the current server
            List<ContainerModel> cms = new List<ContainerModel>();
            try
            {
                cms = await IotDeviceDataHelper.GetAllContainers();
            }
            catch (Exception e)
            {
                //Can be triggered in the event of a network error, such as the server being down.
                return;
            }

            //If the container exists, then populate its data to be displayed.
            if (cms.Exists(c => c.Name == CurrentContainer.Name))
            {

                ContainerModel cm = cms.Find(c => c.Name == CurrentContainer.Name);

                CurrentContainer.Plant.Humidity = cm.Plant.Humidity;
                CurrentContainer.Plant.IsFanSpinning = cm.Plant.IsFanSpinning;
                CurrentContainer.Plant.IsLightOn = cm.Plant.IsLightOn;
                CurrentContainer.Plant.SoilMoisture = cm.Plant.SoilMoisture;
                CurrentContainer.Plant.Temperature = cm.Plant.Temperature;
                CurrentContainer.Plant.WaterLevel = cm.Plant.WaterLevel;

                CurrentContainer.Geolocation.IsAlarmTriggered = cm.Geolocation.IsAlarmTriggered;
                CurrentContainer.Geolocation.Latitude = cm.Geolocation.Latitude;
                CurrentContainer.Geolocation.Longitude = cm.Geolocation.Longitude;
                CurrentContainer.Geolocation.PitchAngle = cm.Geolocation.PitchAngle;
                CurrentContainer.Geolocation.RollAngle = cm.Geolocation.RollAngle;
                CurrentContainer.Geolocation.VibrationLevel = cm.Geolocation.VibrationLevel;

                CurrentContainer.Security.IsAlarmTriggered = cm.Security.IsAlarmTriggered;
                CurrentContainer.Security.IsDoorLocked = cm.Security.IsDoorLocked;
                CurrentContainer.Security.IsDoorOpen = cm.Security.IsDoorOpen;
                CurrentContainer.Security.IsMotionSensorTriggered = cm.Security.IsMotionSensorTriggered;
                CurrentContainer.Security.LightLevel = cm.Security.LightLevel;
                CurrentContainer.Security.NoiseLevel = cm.Security.NoiseLevel;
            }

            //Once the data is finished loading, the refresh cycle is finished.
            ToggleSubSystemRefresh(sysName);
        }

        private async void RefreshAllContainers()
        {
            IsRefreshingContainers = true;
            List<ContainerModel> cms = null;

            try
            {
                cms = await IotDeviceDataHelper.GetAllContainers();
            }
            catch (Exception e)
            {
                IsRefreshingContainers = false;
                return;
            }
            if (cms != null)
            {
                ContainerRepository.Containers = cms;
            }
            IsRefreshingContainers = false;
        }

        /// <summary>
        /// Determines which refresh flag should be toggled and toggles it.
        /// </summary>
        /// <param name="sysName">The name of the subsystem</param>
        private void ToggleSubSystemRefresh(string sysName)
        {
            switch (sysName.ToLower())
            {
                case IotDeviceDataHelper.PLANT_NAME:
                    IsRefreshingPlant = !IsRefreshingPlant;
                    break;
                case IotDeviceDataHelper.GEO_NAME:
                    IsRefreshingGeo = !IsRefreshingGeo;
                    break;
                case IotDeviceDataHelper.SEC_NAME:
                    IsRefreshingSec = !IsRefreshingSec;
                    break;
            }
        }

        /// <summary>
        /// Navigates to the ConfigureServer view
        /// </summary>
        private void NavConfigureServerFunction()
        {
            Navigation.PushAsync(new ConfigureServer());
        }

        /// <summary>
        /// Should be manually invoked when a property that is part of 
        /// a calculated one is changed so that the calculated one updates accordingly.
        /// </summary>
        public void NotifyForCalculatedProperties()
        {
            //The server name.
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DisplayServerName)));

            //The extended container data.
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DisplayMyContainerData)));
        }

        /// <summary>
        /// Navigates to new page where container values can be changed.
        /// </summary>
        private void NavigateToEditContainer(ContainerModel cm)
        {
            CurrentContainer = cm;
            Navigation.PushAsync(new EditContainerPage());
        }

        /// <summary>
        /// Validates and updates container metadata twin in server.
        /// </summary>
        /// <param name="newInterval">The telemetry interval as a string</param>
        private void SaveEdits(string newInterval)
        {
            //Cannot set an empty value.
            if (string.IsNullOrEmpty(newInterval))
            {
                App.Current.MainPage.DisplayAlert("Error", "Please input a value for each.", "OK");
                return;
            }

            //Result of the try/parse
            int parseResult = 0;

            //Cannot set it if it is not a valid integer
            if (!int.TryParse(newInterval, out parseResult))
            {
                App.Current.MainPage.DisplayAlert("Error", "Interval must be an int representing seconds.", "OK");
                return;
            }

            //Cannot set a negative number as an interval, silly!
            if (!(parseResult >= 0))
            {
                App.Current.MainPage.DisplayAlert("Error", "Interval must be at least 0.", "OK");
                return;
            }

            //If we got this far, the data is valid and can be patched to the twin to be read in the Python backend.
            IotDeviceDataHelper.UpdateTwin("containerData", "telemetryInterval", newInterval);

            //Should also remain consistent with the data displayed in the app.
            CurrentContainer.TelemetryInterval = parseResult;
            
            //No need to keep the page open if the settings are saved.
            Navigation.PopAsync();
        }

        /// <summary>
        /// Represents if the current user is a technician.
        /// Is used to limit the visible fields to only those needed by a Technician.
        /// </summary>
        public bool IsTechnician { get; set; } = false;

        /// <summary>
        /// Represents if the current user is a Fleet Manager.
        /// Is used to limit the visible fields to only those needed by a Fleet Manager.
        /// </summary>
        public bool IsManager { get; set; } = false;
    }
}
