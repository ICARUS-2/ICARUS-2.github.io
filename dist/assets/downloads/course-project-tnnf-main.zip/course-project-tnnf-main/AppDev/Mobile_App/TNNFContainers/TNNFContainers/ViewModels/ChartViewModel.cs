﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.ComponentModel;
using UltimateXF.Widget.Charts.Models.Component;

namespace TNNFContainers.ViewModels
{
    /// <summary>
    /// Contains viewmodel data for the historical data pages
    /// </summary>
    public class ChartViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// Sets IsFinishedLoading to False, sets ChartDescription to "Historical Data"
        /// </summary>
        public ChartViewModel()
        {
            IsFinishedLoading = false;
            ChartDescription = new ChartDescription() { Text="Historical Data"};
        }

        /// <summary>
        /// The description at the bottom of the chart
        /// </summary>
        public ChartDescription ChartDescription { get; set; }

        /// <summary>
        /// Whether the chart is still loading
        /// </summary>
        public bool IsFinishedLoading { get; set; }

        /// <summary>
        /// Used for binding to the loading icon
        /// </summary>
        public bool IsFinishedLoadingInverse { get { return !IsFinishedLoading; } }

        /// <summary>
        /// Used for Fody auto-inject
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
