﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.Text;

namespace TNNFContainers.Helpers
{
    /// <summary>
    /// Static class providing methods to help with text formatting
    /// </summary>
    public static class TextHelper
    {
        //https://stackoverflow.com/questions/272633/add-spaces-before-capital-letters
        /// <summary>
        /// Adds spaces between capital letters in a string
        /// </summary>
        /// <param name="text">The string to be formatted</param>
        /// <param name="preserveAcronyms">True to preserve acronyms, false if not</param>
        /// <returns>The string with spaces between capitals</returns>
        public static string AddSpacesBetweenCapitals(string text, bool preserveAcronyms)
        {
            if (string.IsNullOrWhiteSpace(text))
                return string.Empty;
            StringBuilder newText = new StringBuilder(text.Length * 2);
            newText.Append(text[0]);
            for (int i = 1; i < text.Length; i++)
            {
                if (char.IsUpper(text[i]))
                    if ((text[i - 1] != ' ' && !char.IsUpper(text[i - 1])) ||
                        (preserveAcronyms && char.IsUpper(text[i - 1]) &&
                         i < text.Length - 1 && !char.IsUpper(text[i + 1])))
                        newText.Append(' ');
                newText.Append(text[i]);
            }
            return newText.ToString();
        }
    }
}
