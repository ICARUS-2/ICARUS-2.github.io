﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.Collections.Generic;
using System.ComponentModel;
using TNNFContainers.Interfaces;
using TNNFContainers.Models;
using TNNFContainers.Models.Subsystems;

namespace TNNFContainers.Repos
{
    public class ContainerRepository : IContainerRepository, INotifyPropertyChanged
    {
        private List<ContainerModel> _containers;

        /// <summary>
        /// Default constructor initializes two dummy containers with hard-coded values
        /// </summary>
        public ContainerRepository()
        {
            _containers = new List<ContainerModel>()
            {
                new ContainerModel("TestContainer1")
                {
                    Geolocation = new GeolocationSubsystemModel()
                    {
                        IsAlarmTriggered = true, Latitude = 1,
                        Longitude = 1,
                        PitchAngle = 111,
                        RollAngle = 111,
                        VibrationLevel = 111
                    },

                    Plant = new PlantSusbsystemModel()
                    {
                        IsFanSpinning = true,
                        Humidity = 1,
                        SoilMoisture = 1,
                        Temperature = 1,
                        WaterLevel = 1
                    },

                    Security = new SecuritySubsystemModel()
                    {
                        IsAlarmTriggered = true,
                        IsDoorLocked = true,
                        IsDoorOpen = false,
                        IsMotionSensorTriggered = true,
                        LightLevel = 11,
                        NoiseLevel = 11
                    }
                },

                new ContainerModel("TestContainer2")
                {
                    Geolocation = new GeolocationSubsystemModel()
                    {
                        IsAlarmTriggered = false,
                        Latitude = 2,
                        Longitude = 2,
                        PitchAngle = 222,
                        RollAngle = 222,
                        VibrationLevel = 222
                    },

                    Plant = new PlantSusbsystemModel()
                    {
                        IsFanSpinning = false,
                        Humidity = 2,
                        SoilMoisture = 2,
                        Temperature = 2,
                        WaterLevel = 2
                    },

                    Security = new SecuritySubsystemModel()
                    {
                        IsAlarmTriggered = false,
                        IsDoorLocked = false,
                        IsDoorOpen = true,
                        IsMotionSensorTriggered = false,
                        LightLevel = 22,
                        NoiseLevel = 22
                    }
                },
            };


        }

        /// <summary>
        /// The list of dummy containers with hard-coded values
        /// </summary>
        public List<ContainerModel> Containers { get => _containers; set => _containers = value; }

        /// <summary>
        /// Used for Fody auto-inject
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
