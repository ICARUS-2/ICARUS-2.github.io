﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.Collections.Generic;
using TNNFContainers.Models;

namespace TNNFContainers.Interfaces
{
    /// <summary>
    /// Interface containing the necessary methods and properties to interact with a group of containers
    /// </summary>
    public interface IContainerRepository
    {
        /// <summary>
        /// The list of containers to be manipulated
        /// </summary>
        List<ContainerModel> Containers { get; set; }
    }
}
