﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using TNNFContainers.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();

            App.MainViewModel.Navigation = Navigation;

            BindingContext = new LoginViewModel();
        }

        protected override void OnAppearing()
        {
            App.MainViewModel.IsTechnician = false;
            App.MainViewModel.IsManager = false;
            base.OnAppearing();
        }
    }
}