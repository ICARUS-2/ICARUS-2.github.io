﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using TNNFContainers.Helpers;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views.GeoLocation
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class GeolocationMain : ContentPage
    {
        // To distinguish between code-behind event handler calls vs user events.
        private bool alarmToggledFromCode = false;

        public GeolocationMain()
        {
            InitializeComponent();

            BindingContext = App.MainViewModel;

            //Sets the actuator switch.
            if (App.MainViewModel.CurrentContainer.Geolocation.IsAlarmTriggered != null)
                if ((bool)App.MainViewModel.CurrentContainer.Geolocation.IsAlarmTriggered)
                {
                    alarmToggledFromCode = true;
                    alarmSwitch.IsToggled = true; // Calls event handler.
                    alarmToggledFromCode = false;
                }

            //Initializes the link to the Google Map.
            SetMapsURL(null, null);

            //Sets the URL to the current coordinates if they exist.
            IotDeviceDataHelper.MapsCoordinatesUpdated += SetMapsURL;
        }

        /// <summary>
        /// Fires if the Geolocation alarm is triggered.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Alarm_Toggled(object sender, ToggledEventArgs e)
        {
            //Must check so that the event listener won't fire twice.
            if (!alarmToggledFromCode)
            {
                string value = String.Empty;

                if (e.Value) value = "On";
                else value = "Off";

                //Patches the new value to the backend.
                IotDeviceDataHelper.UpdateTwin("geolocation", "alarm", value);
            }
        }

        /// <summary>
        /// Configures the Google maps URL
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SetMapsURL(object sender, EventArgs e)
        {
            const string baseURL = "https://www.google.com/maps/search/?";

            if (App.MainViewModel.CurrentContainer.Geolocation.Latitude == null || App.MainViewModel.CurrentContainer.Geolocation.Longitude == null) mapsLink.Url = baseURL;
            else mapsLink.Url = $"{baseURL}api=1&query={App.MainViewModel.CurrentContainer.Geolocation.Latitude},{App.MainViewModel.CurrentContainer.Geolocation.Longitude}";
        }
    }
}