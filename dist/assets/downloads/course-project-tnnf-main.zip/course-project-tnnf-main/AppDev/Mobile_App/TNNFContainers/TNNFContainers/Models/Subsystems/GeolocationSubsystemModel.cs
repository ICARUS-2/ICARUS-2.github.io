﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.ComponentModel;

namespace TNNFContainers.Models.Subsystems
{
    /// <summary>
    /// Contains the properties for the container's Geolocation subsystem
    /// </summary>
    public class GeolocationSubsystemModel : INotifyPropertyChanged
    {
        /// <summary>
        /// Sets all of the properties to null
        /// </summary>
        public GeolocationSubsystemModel()
        {
            Latitude = null;
            Longitude = null;
            VibrationLevel = null;
            PitchAngle = null;
            RollAngle = null;
            IsAlarmTriggered = null;
        }
        /// <summary>
        /// GPS sensor latitude
        /// </summary>
        public double? Latitude { get; set; }

        /// <summary>
        /// GPS sensor longitude
        /// </summary>
        public double? Longitude { get; set; }

        /// <summary>
        /// Vibration level of the container
        /// </summary>
        public double? VibrationLevel { get; set; }

        /// <summary>
        /// The container's pitch angle
        /// </summary>
        public double? PitchAngle { get; set; }

        /// <summary>
        /// The container's roll angle
        /// </summary>
        public double? RollAngle { get; set; }

        /// <summary>
        /// Whether the alarm is triggered or not
        /// </summary>
        public bool? IsAlarmTriggered { get; set; }

        /// <summary>
        /// Needed for Fody auto-inject
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
