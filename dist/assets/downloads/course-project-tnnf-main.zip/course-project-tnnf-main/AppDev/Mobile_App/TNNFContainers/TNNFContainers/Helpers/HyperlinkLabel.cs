﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TNNFContainers.Helpers
{
    /// <summary>
    /// A label that links to a given URL in the browser
    /// </summary>
    public class HyperlinkLabel : Label
    {
        /// <summary>
        /// The URL binding
        /// </summary>
        public static readonly BindableProperty UrlProperty = BindableProperty.Create(nameof(Url), typeof(string), typeof(HyperlinkLabel), null);

        /// <summary>
        /// The URL to open in the browser
        /// </summary>
        public string Url
        {
            get { return (string)GetValue(UrlProperty); }
            set { SetValue(UrlProperty, value); }
        }

        /// <summary>
        /// Sets the color to blue, text decoration to underline, and sets the command to open the browser
        /// </summary>
        public HyperlinkLabel()
        {
            //Ensures that the link will appear as underlined in the app.
            TextDecorations = TextDecorations.Underline;

            //The hyperlink will appear as blue.
            TextColor = Color.Blue;

            //Allows the URL to be opened in the browser.
            GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () => await Launcher.OpenAsync(Url))
            });
        }
    }
}
