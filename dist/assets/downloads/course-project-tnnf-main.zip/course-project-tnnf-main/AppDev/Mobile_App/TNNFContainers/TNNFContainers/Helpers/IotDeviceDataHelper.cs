﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using Microsoft.Azure.Devices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TNNFContainers.Models;
using TNNFContainers.Models.Subsystems;
using Xamarin.Essentials;

namespace TNNFContainers.Helpers
{
    /// <summary>
    /// Provides the necessary functions to interact with the IoT hub
    /// </summary>
    public static class IotDeviceDataHelper
    {
        /// <summary>
        /// The directory to store the config file
        /// </summary>
        private static string dir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        
        /// <summary>
        /// The full path of the config file
        /// </summary>
        private static string path = Path.Combine(dir, "addresses.env");

        /// <summary>
        /// Connection string for the IoT Hub
        /// </summary>
        public static string CONNECTION_STRING = "HostName=ICARUS-2-IOTHUB.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=oIFtQP/rc3PpHmXZK1XCVnrcwDAj4UN7pOckMa1lP2A=";
        
        /// <summary>
        /// Connection string for the Built-in endpoint
        /// </summary>
        public static string ENDPOINT_CONNECTION_STRING = "Endpoint=sb://ihsuprodytres019dednamespace.servicebus.windows.net/;SharedAccessKeyName=iothubowner;SharedAccessKey=oIFtQP/rc3PpHmXZK1XCVnrcwDAj4UN7pOckMa1lP2A=;EntityPath=iothub-ehub-icarus-2-i-18103849-bcf062ae31";

        /// <summary>
        /// Refers to the Plant subsystem
        /// </summary>
        public const string PLANT_NAME = "plant";

        /// <summary>
        /// Refers to the GeoLocation subsystem
        /// </summary>
        public const string GEO_NAME = "geolocation";

        /// <summary>
        /// Refers to the Security subsystem
        /// </summary>
        public const string SEC_NAME = "security";

        private const string ONSTATE = "on";
        private const string OFFSTATE = "off";
      
        /// <summary>
        /// Retrieves the connection strings from the config file and sets them in the class
        /// </summary>
        public static void GetAddresses()
        {
            try
            {
                //Keys for the strings in the config file
                string con = nameof(CONNECTION_STRING);
                string endpoint = nameof(ENDPOINT_CONNECTION_STRING);

                //If the file does not exist, we must create it
                if (!File.Exists(path))
                {
                    //Formats the text file as such
                    /*
                     * CONNECTION_STRING=<VALUE>
                     * ENDPOINT_CONNECTION_STRING=<VALUE>
                     */
                    string text = $"{con}={CONNECTION_STRING}\n{endpoint}={ENDPOINT_CONNECTION_STRING}";

                    //Save it in the file.
                    File.WriteAllText(path, text);
                    return;
                }

                //If the config file does exist, parse it.
                foreach (var line in File.ReadAllLines(path))
                {
                    //Retrieves the two connection strings in an array
                    var parts = line.Split(new char[] { '=' }, 2, StringSplitOptions.RemoveEmptyEntries);

                    //Parse the hub connection string and set it.
                    if (parts.Contains(con))
                        CONNECTION_STRING = parts.Last().Trim();

                    //Parse the endpoint connection string and set it.
                    if (parts.Contains(endpoint))
                        ENDPOINT_CONNECTION_STRING = parts.Last().Trim();
                }
            }
            catch(Exception ex)
            {
                //File read error occurred, use defaults.
            }
        }
        
        /// <summary>
        /// Updates the Google Maps hyperlink URL
        /// </summary>
        public static event EventHandler MapsCoordinatesUpdated;

        /// <summary>
        /// Takes the current connection strings and saves them in the config file
        /// </summary>
        public static void SaveConnectionStrings()
        {
            //Keys for the strings in the config file
            string con = nameof(CONNECTION_STRING);
            string endpoint = nameof(ENDPOINT_CONNECTION_STRING);

            //To avoid setting an empty connection string
            if (string.IsNullOrWhiteSpace(CONNECTION_STRING))
                CONNECTION_STRING = "-";

            //To avoid setting an empty endpoint string
            if (string.IsNullOrWhiteSpace(ENDPOINT_CONNECTION_STRING))
                ENDPOINT_CONNECTION_STRING = "-";

            //Formats the text file as such
            /*
             * CONNECTION_STRING=<VALUE>
             * ENDPOINT_CONNECTION_STRING=<VALUE>
             */
            string text = $"{con}={CONNECTION_STRING}\n{endpoint}={ENDPOINT_CONNECTION_STRING}";

            //Save the data
            File.WriteAllText(path, text);
        }

        /// <summary>
        /// Gets all containers from server.
        /// </summary>
        /// <param name="cms">The list to populate</param>
        /// <returns>The list of containers</returns>
        public async static Task<List<ContainerModel>> GetAllContainers(List<ContainerModel> cms = null)
        {
            //Cannot retrieve the containers if it can't connect to the server
            if (!CheckConnection())
                return null;

            //Will be used to store the query made to the server
            IQuery query;

            //Will be used to store the JSON data returned from the server
            IEnumerable<string> result = new List<String>();

            //Server might be invalid or have connection issues
            try
            {
                //Ensures proper disposal
                using (RegistryManager registryManager = RegistryManager.CreateFromConnectionString(CONNECTION_STRING))
                {
                    //Sets up query to select every possible device on the hub
                    query = registryManager.CreateQuery("SELECT * FROM devices");

                    //Stores the result as an Enumerable
                    result = await query.GetNextAsJsonAsync();
                }
            }
            catch (Exception e)
            {
                if (!e.Message.Contains("Throttling"))
                {
                    App.Current.MainPage.DisplayAlert("Error", "Can not connect to the Iot Hub.", "OK");
                }
                //Connection string might have been invalid, or server may be down.
            }

            //To avoid throwing null ref exceptions
            if (cms == null)
                cms = new List<ContainerModel>();

            //For each device that was found on the server, deserialize it
            foreach (string item in result)
            {
                //The device twin is stored here
                JObject i = JsonConvert.DeserializeObject<JObject>(item);

                //Represents the Device ID
                var name = i.GetValue("deviceId").ToString();

                //The reported properties from the device twin
                var reported = i["properties"]["reported"];

                //The desired properties from the device twin
                var desired = i["properties"]["desired"];

                //Will be used to store the telemetry interval
                int parseResult = 0;

                //If the twin is valid (contains all of the necessary subsystems), then populate the data for viewing in the app
                if (reported["plant"] != null && reported["geolocation"] != null && reported["security"] != null)
                {
                    //trycatch in the event of an unexpected json error
                    try
                    {
                        //The container model that will be shown in the app
                        ContainerModel cm = PopulateData(name, reported);

                        //containerData contains the telemetry interval and will contain any future additional data
                        if (desired["containerData"] != null)
                            if (desired["containerData"]["telemetryInterval"] != null)
                                if (int.TryParse(desired["containerData"]["telemetryInterval"].ToString(), out parseResult))
                                    cm.TelemetryInterval = parseResult; 

                        //If we got this far, the data is valid to display and should be added.
                        cms.Add(cm);
                    }
                    catch (Exception e)
                    {
                        //failure while populating container data, skip container and continue populating the rest.
                    }
                }
            }

            return cms;
        }

        /// <summary>
        /// Deserializes and populates all the data for the app's container objects.
        /// </summary>
        /// <param name="name">The device name</param>
        /// <param name="data">The token containing the data to populate</param>
        /// <param name="cm">The ContainerModel that will be populated</param>
        /// <returns>The populated ContainerModel</returns>
        private static ContainerModel PopulateData(string name, JToken data, ContainerModel cm = null)
        {
            //The JSON data for each individual subsystem.
            var plant = data[PLANT_NAME];
            var geo = data[GEO_NAME];
            var sec = data[SEC_NAME];

            //Result of try parsing. Reused for each value deserialized.
            double parseResult = 0;

            //Prepares the object for population
            if (cm == null)
            {
                cm = new ContainerModel(name);

                cm.Plant = new PlantSusbsystemModel();

                cm.Geolocation = new GeolocationSubsystemModel();

                cm.Security = new SecuritySubsystemModel();
            }

            //Checks the values and populates them in the container's Plant subsystem object if they are valid.
            if (double.TryParse(plant["humidity"].ToString(), out parseResult))
                cm.Plant.Humidity = parseResult;
            if (double.TryParse(plant["temperature"].ToString(), out parseResult))
                cm.Plant.Temperature = parseResult;
            if (double.TryParse(plant["waterLevel"].ToString(), out parseResult))
                cm.Plant.WaterLevel = parseResult;
            if (double.TryParse(plant["soilMoisture"].ToString(), out parseResult))
                cm.Plant.SoilMoisture = parseResult;
            if (plant["fan"].ToString().ToLower() == ONSTATE)
                cm.Plant.IsFanSpinning = true;
            else if (plant["fan"].ToString().ToLower() == OFFSTATE)
                cm.Plant.IsFanSpinning = false;
            if (plant["light"].ToString().ToLower() == ONSTATE)
                cm.Plant.IsLightOn = true;
            else if (plant["light"].ToString().ToLower() == OFFSTATE)
                cm.Plant.IsLightOn = false;

            //Checks the values and populates them in the container's GeoLocation subsystem object if they are valid.
            if (double.TryParse(geo["rollAngle"].ToString(), out parseResult))
                cm.Geolocation.RollAngle = parseResult;
            if (double.TryParse(geo["pitchAngle"].ToString(), out parseResult))
                cm.Geolocation.PitchAngle = parseResult;
            if (double.TryParse(geo["vibration"].ToString(), out parseResult))
                cm.Geolocation.VibrationLevel = parseResult;
            if (double.TryParse(geo["latitude"].ToString(), out parseResult))
                cm.Geolocation.Latitude = parseResult;
            if (double.TryParse(geo["longitude"].ToString(), out parseResult))
                cm.Geolocation.Longitude = parseResult;
            if (geo["alarm"].ToString().ToLower() == ONSTATE)
                cm.Geolocation.IsAlarmTriggered = true;
            else if (geo["alarm"].ToString().ToLower() == OFFSTATE)
                cm.Geolocation.IsAlarmTriggered = false;

            //Checks the values and populates them in the container's Security subsystem object if they are valid.
            if (double.TryParse(sec["noiseSensor"].ToString(), out parseResult))
                cm.Security.NoiseLevel = parseResult; 
            if (double.TryParse(sec["motionSensor"].ToString(), out parseResult))
                cm.Security.IsMotionSensorTriggered = parseResult != 1;
            if (double.TryParse(sec["lightSensor"].ToString(), out parseResult))
                cm.Security.LightLevel = parseResult;
            if (sec["doorSensor"].ToString().ToLower() == "open")
                cm.Security.IsDoorOpen = true;
            else if (sec["doorSensor"].ToString().ToLower() == "closed")
                cm.Security.IsDoorOpen = false;
            if (sec["doorLock"].ToString().ToLower() == "locked")
                cm.Security.IsDoorLocked = true;
            else if (sec["doorLock"].ToString().ToLower() == "unlocked")
                cm.Security.IsDoorLocked = false;
            if (sec["alarm"].ToString().ToLower() == ONSTATE)
                cm.Security.IsAlarmTriggered = true;
            else if (sec["alarm"].ToString().ToLower() == OFFSTATE)
                cm.Security.IsAlarmTriggered = false;

            // To update the hyperlink URL.
            MapsCoordinatesUpdated?.Invoke(null, EventArgs.Empty);

            //The now-populated container is returned.
            return cm;
        }

        /// <summary>
        /// Checks the connection of the network.
        /// </summary>
        /// <returns>True if device is connected to the Internet, false if not</returns>
        public static bool CheckConnection()
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                return true;

            App.Current.MainPage.DisplayAlert("No Internet available.", "Be sure to be connected to wifi.", "OK");
            return false;
        }

        /// <summary>
        /// Takes the subsystem, property to update, and the updated value and patches it to the device twin
        /// </summary>
        /// <param name="subsystem">The subsystem to update in the device twin</param>
        /// <param name="property">The property that is being updated</param>
        /// <param name="value">The new value for that property</param>
        /// <returns>Task (for awaiting)</returns>
        public static async Task UpdateTwin(string subsystem, string property, string value)
        {
            try
            {
                //Ensures proper disposal
                using (RegistryManager registryManager = RegistryManager.CreateFromConnectionString(CONNECTION_STRING))
                {
                    //The twin for the current device
                    var twin = await registryManager.GetTwinAsync(App.MainViewModel.CurrentContainer.Name);

                    //Builds the patch as a formatted JSON string
                    var patch = $"{{ properties: {{ desired: {{ {subsystem}: {{ {property}: '{value}' }} }} }} }}";

                    //Transmits it to the device twin stored on the server
                    await registryManager.UpdateTwinAsync(twin.DeviceId, patch, twin.ETag);
                }
            }
            catch(Exception ex)
            {
                //Something broke
                App.Current.MainPage.DisplayAlert("Error", "An issue was observed when trying to update the device twin.", "OK");
                return;
            }
        }
    }
}
