﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using TNNFContainers.Helpers;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views.Security
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SecurityMain : ContentPage
    {
        // To distinguish between code-behind event handler calls vs user events.
        private bool alarmToggledFromCode = false;
        private bool lockToggledFromCode = false;

        public SecurityMain()
        {
            InitializeComponent();

            BindingContext = App.MainViewModel;

            //Sets the actuator switch states. Null check so that no exception will be thrown.
            if (App.MainViewModel.CurrentContainer.Security.IsAlarmTriggered != null)
                if ((bool)App.MainViewModel.CurrentContainer.Security.IsAlarmTriggered)
                {
                    alarmToggledFromCode = true;
                    alarmSwitch.IsToggled = true; // Calls event handler.
                    alarmToggledFromCode = false;
                }

            if (App.MainViewModel.CurrentContainer.Security.IsDoorLocked != null)
                if ((bool)App.MainViewModel.CurrentContainer.Security.IsDoorLocked)
                {
                    lockToggledFromCode = true;
                    lockSwitch.IsToggled = true; // Calls event handler.
                    lockToggledFromCode = false;
                }
        }

        private void Alarm_Toggled(object sender, ToggledEventArgs e)
        {
            //Prevents the event from being called twice.
            if (!alarmToggledFromCode)
            {
                string value = String.Empty;

                if (e.Value) value = "On";
                else value = "Off";

                //Patch the updated actuator value to the backend.
                IotDeviceDataHelper.UpdateTwin("security", "alarm", value);
            }
        }

        private void Lock_Toggled(object sender, ToggledEventArgs e)
        {
            //Prevents the event from being called twice.
            if (!lockToggledFromCode)
            {
                string value = String.Empty;

                //Changes the icon based on the state
                if (e.Value)
                {
                    value = "Locked";
                    img_DoorLock.Source = "locked.png";
                }
                else
                {
                    value = "Unlocked";
                    img_DoorLock.Source = "unlocked.png";
                }

                //Patch the updated actuator value to the backend.
                IotDeviceDataHelper.UpdateTwin("security", "doorLock", value);
            }
        }
    }
}