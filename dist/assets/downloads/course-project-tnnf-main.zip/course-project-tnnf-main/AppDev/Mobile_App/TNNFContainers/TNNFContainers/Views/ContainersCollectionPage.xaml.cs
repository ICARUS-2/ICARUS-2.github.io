﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ContainersCollectionPage : ContentPage
    {
        public ContainersCollectionPage()
        {
            InitializeComponent();

            BindingContext = App.MainViewModel;
        }
    }
}