﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;

namespace TNNFContainers.Models
{
    /// <summary>
    /// Represents one entry in a state table
    /// </summary>
    public class StateChangedModel
    {
        /// <summary>
        /// The state at the given timestamp
        /// </summary>
        public State CurrentState { get; set; }

        /// <summary>
        /// The date and time the value was recorded
        /// </summary>
        public DateTime TimeStamp { get; set; }

        /// <summary>
        /// The possible states for the components
        /// </summary>
        public enum State
        {
            Unlocked,
            Locked,
            Enabled,
            Disabled,
            Idle,
            Triggered,
            Open,
            Closed
        }
    }
}


