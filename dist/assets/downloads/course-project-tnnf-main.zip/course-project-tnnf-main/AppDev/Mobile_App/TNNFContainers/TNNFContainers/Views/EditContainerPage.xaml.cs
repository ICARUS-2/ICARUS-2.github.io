﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditContainerPage : ContentPage
    {
        public EditContainerPage()
        {
            InitializeComponent();

            BindingContext = App.MainViewModel;
        }
    }
}