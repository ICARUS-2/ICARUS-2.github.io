﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using TNNFContainers.Helpers;
using TNNFContainers.Interfaces;
using TNNFContainers.ViewModels;
using UltimateXF.Widget.Charts.Models.LineChart;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views.Historical
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LineGraphPage : ContentPage
    {
        public ChartViewModel ViewModel { get; set; }

        public LineGraphPage(LineChartType type)
        {
            InitializeComponent();
            ViewModel = new ChartViewModel();
            BindingContext = ViewModel;
            Title = "Historical Graph - " + TextHelper.AddSpacesBetweenCapitals(type.ToString(), true);
            SetChart(type);
        }

        private async void SetChart(LineChartType type)
        {
            LineChartData data = await App.MainViewModel.HistoricalDataRepository.GetLineChartAsync(type, App.MainViewModel.CurrentContainer.Name);

            xfChart.ChartData = data;

            ViewModel.IsFinishedLoading = true;
        }
    }
}