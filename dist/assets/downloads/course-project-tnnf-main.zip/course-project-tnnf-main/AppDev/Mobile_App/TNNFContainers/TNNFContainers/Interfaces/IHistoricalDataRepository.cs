﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.Collections.Generic;
using System.Threading.Tasks;
using TNNFContainers.Models;
using UltimateXF.Widget.Charts.Models.LineChart;

namespace TNNFContainers.Interfaces
{
    /// <summary>
    /// Interface containing the methods necessary to provide line chart data as well as state table entries
    /// </summary>
    public interface IHistoricalDataRepository
    {
        /// <summary>
        /// Constructs a line chart based on the passed device type and device name
        /// </summary>
        /// <param name="type">The type of data to make the chart for</param>
        /// <param name="deviceName">The name of the device the data will be read from</param>
        /// <returns>A line chart with the data of the passed type from the device with the passed name</returns>
        Task<LineChartData> GetLineChartAsync(LineChartType type, string deviceName);

        /// <summary>
        /// Constructs a list of state table entries based on the passed device and name.
        /// </summary>
        /// <param name="type">The type of data to make the list for</param>
        /// <param name="deviceName">The name of the device the data will be read from</param>
        /// <returns>A collection with the data of the passed type from the device with the passed name</returns>
        Task<IEnumerable<StateChangedModel>> GetStateTableEntriesAsync(StateTableType type, string deviceName);
    }

    /// <summary>
    /// The different types of line charts that can be created
    /// </summary>
    public enum LineChartType
    {
        //GeoLocation
        Angles,
        Vibration,

        //Plant
        WaterLevel,
        SoilMoisture,
        Humidity,
        Temperature,

        //Security
        NoiseLevel,
        LightLevel,
        
    }

    /// <summary>
    /// The different types of state tables that can be created
    /// </summary>
    public enum StateTableType
    {
        //Geolocation
        GeolocationAlarm,
        
        //Plant
        Fan,
        Light,

        //Security
        MotionSensor,
        DoorLock,
        Door,
        SecurityAlarm,
    }

}
