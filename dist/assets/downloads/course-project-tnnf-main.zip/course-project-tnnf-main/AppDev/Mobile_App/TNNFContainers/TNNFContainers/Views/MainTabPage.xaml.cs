﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainTabPage : TabbedPage
    {
        public MainTabPage()
        {
            InitializeComponent();

            BindingContext = App.MainViewModel;

            //To default to the My Container (GeoLocation) page.
            CurrentPage = Children[1];
        }
    }
}