﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using System.ComponentModel;
using TNNFContainers.Models.Subsystems;

namespace TNNFContainers.Models
{
    /// <summary>
    /// Contains data about a given container farm
    /// </summary>
    public class ContainerModel : INotifyPropertyChanged
    {
        /// <summary>
        /// The device name
        /// </summary>
        public String Name { get; set; }

        /// <summary>
        /// Takes a name and sets it
        /// </summary>
        /// <param name="name">The name of the container</param>
        public ContainerModel(string name = "Container")
        {
            Name = name;
            TelemetryInterval = 10;
        }

        /// <summary>
        /// The container's geolocation subsystem
        /// </summary>
        public GeolocationSubsystemModel Geolocation{ get; set; }
        
        /// <summary>
        /// The container's Plant subsystem
        /// </summary>
        public PlantSusbsystemModel Plant { get; set; }

        /// <summary>
        /// The container's Security subsystem
        /// </summary>
        public SecuritySubsystemModel Security { get; set; }

        private int _telemetryInterval;

        /// <summary>
        /// The interval for fetching new telemetry in seconds
        /// </summary>
        public int TelemetryInterval 
        { 
            get { return _telemetryInterval; } 
            set 
            {
                _telemetryInterval = value; 
            }
        }

        /// <summary>
        /// Used for Fody auto-inject
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
