﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.ComponentModel;

namespace TNNFContainers.Models.Subsystems
{
    /// <summary>
    /// Contains the properties for the container's Security subsystem
    /// </summary>
    public class SecuritySubsystemModel : INotifyPropertyChanged
    {
        /// <summary>
        /// The noise level inside the container
        /// </summary>
        public double? NoiseLevel { get; set; }

        /// <summary>
        /// The light level inside the container
        /// </summary>
        public double? LightLevel { get; set; }

        /// <summary>
        /// Whether the container's motion sensor was triggered or not
        /// </summary>
        public bool? IsMotionSensorTriggered { get; set; }

        /// <summary>
        /// Whether the container's door is locked or not
        /// </summary>
        public bool? IsDoorLocked { get; set; }

        /// <summary>
        /// Whether the container's door is open or not
        /// </summary>
        public bool? IsDoorOpen { get; set; }

        /// <summary>
        /// Whether the container's alarm is going off or not
        /// </summary>
        public bool? IsAlarmTriggered { get; set; }

        /// <summary>
        /// Needed for Fody auto-inject
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
