﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using TNNFContainers.Helpers;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views.Plant
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PlantMain : ContentPage
    {
        // To distinguish between code-behind event handler calls vs user events.
        private bool lightToggledFromCode = false;
        private bool fanToggledFromCode = false;

        public PlantMain()
        {
            InitializeComponent();

            BindingContext = App.MainViewModel;
            
            //Sets the actuator switches. Must do a null check so that an exception will not be thrown
            if (App.MainViewModel.CurrentContainer.Plant.IsLightOn != null)
                if ((bool)App.MainViewModel.CurrentContainer.Plant.IsLightOn)
                {
                    lightToggledFromCode = true;
                    lightSwitch.IsToggled = true; // Calls event handler
                    lightToggledFromCode = false;
                }

            if (App.MainViewModel.CurrentContainer.Plant.IsFanSpinning != null)
                if ((bool)App.MainViewModel.CurrentContainer.Plant.IsFanSpinning)
                {
                    fanToggledFromCode = true;
                    fanSwitch.IsToggled = true; // Calls event handler
                    fanToggledFromCode = false;
                }
        }

        /// <summary>
        /// Fired when the fan is switched on or off
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Fan_Toggled(object sender, ToggledEventArgs e)
        {
            //Prevents the event from being called twice.
            if (!fanToggledFromCode)
            {
                string value = String.Empty;

                if (e.Value) value = "ON";
                else value = "OFF";

                //Patch the updated actuator value to the backend.
                IotDeviceDataHelper.UpdateTwin("plant", "fan", value);
            }
        }

        /// <summary>
        /// Fired when the lights is switched on or off
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Light_Toggled(object sender, ToggledEventArgs e)
        {
            //Prevents the event from being called twice.
            if (!lightToggledFromCode)
            {
                string value = String.Empty;

                if (e.Value) value = "ON";
                else value = "OFF";

                //Patch the updated actuator value to the backend.
                IotDeviceDataHelper.UpdateTwin("plant", "light", value);
            }
        }
    }
}