﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using TNNFContainers.Helpers;
using TNNFContainers.Interfaces;
using TNNFContainers.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views.Historical
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class StateTablePage : ContentPage
    {
        public ChartViewModel ViewModel { get; set; }
        public StateTablePage(StateTableType type)
        {
            InitializeComponent();
            ViewModel = new ChartViewModel();
            BindingContext = ViewModel;
            Title = "State History - " + TextHelper.AddSpacesBetweenCapitals(type.ToString(), true);
            SetTable(type);
        }

        private async void SetTable(StateTableType type)
        {
            lv_Historical.ItemsSource = await App.MainViewModel.HistoricalDataRepository.GetStateTableEntriesAsync(type, App.MainViewModel.CurrentContainer.Name);
            ViewModel.IsFinishedLoading = true;
        }
    }
}