﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System.Windows.Input;

namespace TNNFContainers.Interfaces
{
    /// <summary>
    /// Interface containing the necessary commands for logging in and out of an application
    /// </summary>
    public interface ILoginViewModel
    {
        /// <summary>
        /// Used to log in to the application
        /// </summary>
        ICommand Login { get; set; }

        /// <summary>
        /// Used to log out of the application
        /// </summary>
        ICommand Logout { get; set; }
    }
}
