﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using Newtonsoft.Json.Linq;
using System;

namespace TNNFContainers.Models
{
    /// <summary>
    /// Serves as a datapoint on a line graph or a state table (historical data)
    /// </summary>
    public class HistoricalDataModel
    {
        /// <summary>
        /// Takes the data and the timestamp and sets them
        /// </summary>
        /// <param name="data">The data that was recorded</param>
        /// <param name="dt">The timestamp that data was recorded</param>
        public HistoricalDataModel(JObject data, DateTime dt)
        {
            Data = data;
            TimeStamp = dt;
        }

        /// <summary>
        /// The recorded data
        /// </summary>
        public JObject Data { get; set; }

        /// <summary>
        /// The timestamp for when the data was recorded
        /// </summary>
        public DateTime TimeStamp { get; set; }
    }
}
