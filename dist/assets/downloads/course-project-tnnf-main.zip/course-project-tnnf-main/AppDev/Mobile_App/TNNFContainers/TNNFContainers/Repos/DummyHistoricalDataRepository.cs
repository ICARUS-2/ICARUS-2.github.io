﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TNNFContainers.Interfaces;
using TNNFContainers.Models;
using UltimateXF.Widget.Charts.Models;
using UltimateXF.Widget.Charts.Models.LineChart;
using Xamarin.Forms;

namespace TNNFContainers.Repos
{
    /// <summary>
    /// An instance of IHistoricalDataRepository intended for dummy sample historical data
    /// </summary>
    public class DummyHistoricalDataRepository : IHistoricalDataRepository
    {
        /// <summary>
        /// Takes a chart type and device name and constructs a hard-coded dummy chart.
        /// </summary>
        /// <param name="type">The type of data to retrieve. This parameter is unused</param>
        /// <param name="deviceName">The name of the device the data is coming from. This parameter is unused since the sample data is hardcoded</param>
        /// <returns>The line chart</returns>
        public async Task<LineChartData> GetLineChartAsync(LineChartType type, string deviceName)
        {
            //https://parallelcodes.com/xamarin-forms-create-linecharts-ultimatexf/
            var entries2 = new List<EntryChart>();

            //Generates 7 random chart entries
            var random = new Random();
            for (int i = 0; i < 7; i++)
            {
                entries2.Add(item: new EntryChart(i, random.Next(1000, 50000)));
            }

            //Builds the dataset
            var dataset = new LineDataSetXF(entries2, "Product Summary 2")
            {
                Colors = new List<Color>{ Color.Green },
                CircleHoleColor = Color.Blue,
                CircleColors = new List<Color>{ Color.Blue },
                CircleRadius = 1,
                DrawValues = false,

            };

            //Returns the completed chart
            return new LineChartData(new List<ILineDataSetXF>() { dataset });
        }

        /// <summary>
        /// Takes a table type and device name and constructs a hard-coded list of dummy entries.
        /// </summary>
        /// <param name="type">The type of data to retrieve. This parameter is unused since the sample data is hardcoded</param>
        /// <param name="deviceName">The name of the device the data is coming from. This parameter is unused since the sample data is hardcoded</param>
        /// <returns>The hardcoded list of state entries</returns>
        public async Task<IEnumerable<StateChangedModel>> GetStateTableEntriesAsync(StateTableType type, string deviceName)
        {
            return new List<StateChangedModel>()
            {
                new StateChangedModel() {CurrentState=StateChangedModel.State.Enabled, TimeStamp = DateTime.MinValue},
                new StateChangedModel() {CurrentState=StateChangedModel.State.Disabled, TimeStamp = DateTime.Now},
                new StateChangedModel() {CurrentState=StateChangedModel.State.Enabled, TimeStamp = DateTime.MaxValue}
            };
        }
    }
}
