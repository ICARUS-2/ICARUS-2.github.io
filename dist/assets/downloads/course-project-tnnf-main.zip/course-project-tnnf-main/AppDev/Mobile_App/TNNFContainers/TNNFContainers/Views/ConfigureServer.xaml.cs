﻿using TNNFContainers.Helpers;
using TNNFContainers.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TNNFContainers.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ConfigureServer : ContentPage
    {
        /// <summary>
        /// For binding
        /// </summary>
        public ConnectionStringsViewModel ViewModel { get; set; }

        /// <summary>
        /// Binds a new instance of ConnectionStringsViewModel with the current connection string
        /// </summary>
        public ConfigureServer()
        {
            InitializeComponent();

            //Binds to the current connection strings.
            ViewModel = new ConnectionStringsViewModel() { ConnectionString = IotDeviceDataHelper.CONNECTION_STRING, EndpointConnectionString = IotDeviceDataHelper.ENDPOINT_CONNECTION_STRING };

            BindingContext = ViewModel;
        }
    }
}