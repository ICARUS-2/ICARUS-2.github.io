﻿///Team: System.TeamNameNotFoundException (TNNF) - 3
///Semester: Winter 2022
///Course: Application Development III/Connected Objects
using Azure.Messaging.EventHubs.Consumer;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TNNFContainers.Helpers;
using TNNFContainers.Interfaces;
using TNNFContainers.Models;
using UltimateXF.Widget.Charts.Models;
using UltimateXF.Widget.Charts.Models.LineChart;
using Xamarin.Forms;

namespace TNNFContainers.Repos
{
    /// <summary>
    /// Used to retrieve historical data for container devices
    /// </summary>
    public class HistoricalDataRepository : IHistoricalDataRepository
    {
        /// <summary>
        /// Gets a line chart for a device's component
        /// </summary>
        /// <param name="type">The component type</param>
        /// <param name="deviceName">The device name</param>
        /// <returns>The line chart entries for the device component</returns>
        public async Task<LineChartData> GetLineChartAsync(LineChartType type, string deviceName)
        {
            //Retrieves all events from the hub cache.
            List<HistoricalDataModel> availableEvents = await GetEventsAsync(deviceName);
            
            //Will be used to store the chart data.
            List<EntryChart> entries = new List<EntryChart>();

            //Only need to bother with this if there are actually events to parse.
            if (availableEvents.Count != 0)
            {
                try
                {
                    switch (type)
                    {
                        case LineChartType.Angles:
                            {
                                //Will store only the valid entries that will be used in the chart
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();

                                //Checks every possible event
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    //Cannot be valid if the subsystem does not exist.
                                    if (e.Data[IotDeviceDataHelper.GEO_NAME] != null)
                                    {
                                        //Retrieves the JSON data
                                        var pitchAngle = e.Data[IotDeviceDataHelper.GEO_NAME]["pitchAngle"];
                                        var rollAngle = e.Data[IotDeviceDataHelper.GEO_NAME]["rollAngle"];

                                        //Can only be valid if the value exists.
                                        if (pitchAngle != null)
                                        {
                                            //Attempts to convert them to the correct data type.
                                            try
                                            {
                                                pitchAngle.Value<float>();
                                                rollAngle.Value<float>();

                                                //If we got this far, the data is valid, so add it to the chart data.
                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                //Need a second one for roll angle
                                List<EntryChart> entries2 = new List<EntryChart>();

                                //Creates the chart data
                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.GEO_NAME]["pitchAngle"].Value<float>()));
                                    entries2.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.GEO_NAME]["rollAngle"].Value<float>()));
                                }

                                //Library throws an index out of bounds exception if it has zero entries, add a dummy entry to prevent this.
                                if (entries.Count == 0)
                                    entries.Add(new EntryChart(0, 0));

                                if (entries2.Count == 0)
                                    entries.Add(new EntryChart(0, 0));

                                //Line dataset containing only the pitch angle data.
                                var pitchData = new LineDataSetXF(entries, "Pitch Angle")
                                {
                                    Colors = new List<Color> { Color.Blue },
                                    CircleHoleColor = Color.Blue,
                                    CircleColors = new List<Color> { Color.Blue },
                                    CircleRadius = 1,
                                    DrawValues = false,
                                    LineWidth = 1
                                };

                                //Line dataset containing only the roll angle data.
                                var rollData = new LineDataSetXF(entries2, "Roll Angle")
                                {
                                    Colors = new List<Color> { Color.Red },
                                    CircleHoleColor = Color.Red,
                                    CircleColors = new List<Color> { Color.Red },
                                    CircleRadius = 1,
                                    DrawValues = false,
                                    LineWidth = 1
                                };

                                //The completed line chart is returned.
                                return new LineChartData(new List<ILineDataSetXF>() { pitchData, rollData });
                            }

                        case LineChartType.Humidity:
                            {
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    if (e.Data[IotDeviceDataHelper.PLANT_NAME] != null)
                                    {
                                        var humidityToken = e.Data[IotDeviceDataHelper.PLANT_NAME]["humidity"];

                                        if (humidityToken != null)
                                        {
                                            try
                                            {
                                                humidityToken.Value<float>();

                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.PLANT_NAME]["humidity"].Value<float>()));
                                }
                            }
                            break;

                        case LineChartType.LightLevel:
                            {
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                    {
                                        var lightToken = e.Data[IotDeviceDataHelper.SEC_NAME]["lightSensor"];

                                        if (lightToken != null)
                                        {
                                            try
                                            {
                                                lightToken.Value<float>();

                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.SEC_NAME]["lightSensor"].Value<float>()));
                                }
                            }
                            break;

                        case LineChartType.NoiseLevel:
                            {
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                    {
                                        var vibrationToken = e.Data[IotDeviceDataHelper.SEC_NAME]["noiseSensor"];

                                        if (vibrationToken != null)
                                        {
                                            try
                                            {
                                                vibrationToken.Value<float>();

                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.SEC_NAME]["noiseSensor"].Value<float>()));
                                }
                            }
                            break;

                        case LineChartType.SoilMoisture:
                            {
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                    {
                                        var vibrationToken = e.Data[IotDeviceDataHelper.PLANT_NAME]["soilMoisture"];

                                        if (vibrationToken != null)
                                        {
                                            try
                                            {
                                                vibrationToken.Value<float>();

                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.PLANT_NAME]["soilMoisture"].Value<float>()));
                                }
                            }
                            break;

                        case LineChartType.Temperature:
                            {
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    if (e.Data[IotDeviceDataHelper.PLANT_NAME] != null)
                                    {
                                        var humidityToken = e.Data[IotDeviceDataHelper.PLANT_NAME]["temperature"];

                                        if (humidityToken != null)
                                        {
                                            try
                                            {
                                                humidityToken.Value<float>();

                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.PLANT_NAME]["temperature"].Value<float>()));
                                }
                            }
                            break;

                        case LineChartType.Vibration:
                            {
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    if (e.Data[IotDeviceDataHelper.GEO_NAME] != null)
                                    {
                                        var vibrationToken = e.Data[IotDeviceDataHelper.GEO_NAME]["vibration"];

                                        if (vibrationToken != null)
                                        {
                                            try
                                            {
                                                vibrationToken.Value<float>();

                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.GEO_NAME]["vibration"].Value<float>()));
                                }
                            }
                            break;

                        case LineChartType.WaterLevel:
                            {
                                List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                                foreach (HistoricalDataModel e in availableEvents)
                                {
                                    if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                    {
                                        var vibrationToken = e.Data[IotDeviceDataHelper.PLANT_NAME]["waterLevel"];

                                        if (vibrationToken != null)
                                        {
                                            try
                                            {
                                                vibrationToken.Value<float>();

                                                validEntries.Add(e);
                                            }
                                            catch (Exception ex)
                                            {
                                                //Not a valid value
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    var e = validEntries[i];

                                    entries.Add(new EntryChart(i, e.Data[IotDeviceDataHelper.PLANT_NAME]["waterLevel"].Value<float>()));
                                }
                            }
                            break;
                    }
                }

                catch (Exception ex)
                {

                }
            }

            //Prevents the Java.IndexOutOfBoundsException from trying to read from a blank dataset with UltimateXF
            if (entries.Count == 0)
                entries.Add(new EntryChart(0,0));

            var dataset = new LineDataSetXF(entries, Helpers.TextHelper.AddSpacesBetweenCapitals(type.ToString(), true))
            {
                Colors = new List<Color> { Color.Blue },
                CircleHoleColor = Color.Blue,
                CircleColors = new List<Color> { Color.Blue },
                CircleRadius = 1,
                DrawValues = false,
                LineWidth = 1
            };

            return new LineChartData(new List<ILineDataSetXF>() { dataset});
        }

        /// <summary>
        /// Gets the state changes for the passed device
        /// </summary>
        /// <param name="type">The component type to retrieve data for</param>
        /// <param name="deviceName">The name of the device</param>
        /// <returns>The list of state table entries for that device/component</returns>
        public async Task<IEnumerable<StateChangedModel>> GetStateTableEntriesAsync(StateTableType type, string deviceName)
        {
            List<HistoricalDataModel> availableEvents = await GetEventsAsync(deviceName);
            List<StateChangedModel> entries = new List<StateChangedModel>();

            try
            {
                switch(type)
                {
                    case StateTableType.GeolocationAlarm:
                        {
                            List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                            foreach (HistoricalDataModel e in availableEvents)
                            {
                                if (e.Data[IotDeviceDataHelper.GEO_NAME] != null)
                                {
                                    var alarmToken = e.Data[IotDeviceDataHelper.GEO_NAME]["alarm"];

                                    if (alarmToken != null)
                                    {
                                        string val = alarmToken.Value<string>().ToLower();

                                        if (val == "on" || val == "off")
                                            validEntries.Add(e);
                                    }
                                }
                            }
                            if (validEntries.Count > 0)
                            {
                                HistoricalDataModel previous = validEntries[0];

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    HistoricalDataModel current = validEntries[i];

                                    string currentAlarmState = current.Data[IotDeviceDataHelper.GEO_NAME]["alarm"].Value<string>().ToLower();
                                    string previousAlarmState = previous.Data[IotDeviceDataHelper.GEO_NAME]["alarm"].Value<string>().ToLower();

                                    if (currentAlarmState != previousAlarmState)
                                    {
                                        StateChangedModel.State state;

                                        if (currentAlarmState == "off")
                                            state = StateChangedModel.State.Disabled;
                                        else
                                            state = StateChangedModel.State.Enabled;

                                        entries.Add(new StateChangedModel() { CurrentState = state, TimeStamp = current.TimeStamp });
                                    }

                                    previous = current;
                                }
                            }
                        }
                        break;

                    case StateTableType.SecurityAlarm:
                        {
                            List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                            foreach (HistoricalDataModel e in availableEvents)
                            {
                                if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                {
                                    var alarmToken = e.Data[IotDeviceDataHelper.SEC_NAME]["alarm"];

                                    if (alarmToken != null)
                                    {
                                        string val = alarmToken.Value<string>().ToLower();

                                        if (val == "on" || val == "off")
                                            validEntries.Add(e);
                                    }
                                }
                            }
                            if (validEntries.Count > 0)
                            {
                                HistoricalDataModel previous = validEntries[0];

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    HistoricalDataModel current = validEntries[i];

                                    string currentAlarmState = current.Data[IotDeviceDataHelper.SEC_NAME]["alarm"].Value<string>().ToLower();
                                    string previousAlarmState = previous.Data[IotDeviceDataHelper.SEC_NAME]["alarm"].Value<string>().ToLower();

                                    if (currentAlarmState != previousAlarmState)
                                    {
                                        StateChangedModel.State state;

                                        if (currentAlarmState == "off")
                                            state = StateChangedModel.State.Disabled;
                                        else
                                            state = StateChangedModel.State.Enabled;

                                        entries.Add(new StateChangedModel() { CurrentState = state, TimeStamp = current.TimeStamp });
                                    }

                                    previous = current;
                                }
                            }
                        }
                        break;

                    case StateTableType.Fan:
                        {
                            List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                            foreach (HistoricalDataModel e in availableEvents)
                            {
                                if (e.Data[IotDeviceDataHelper.PLANT_NAME] != null)
                                {
                                    var fanToken = e.Data[IotDeviceDataHelper.PLANT_NAME]["fan"];

                                    if (fanToken != null)
                                    {
                                        string val = fanToken.Value<string>().ToLower();

                                        if (val == "on" || val == "off")
                                            validEntries.Add(e);
                                    }
                                }
                            }
                            if (validEntries.Count > 0)
                            {
                                HistoricalDataModel previous = validEntries[0];

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    HistoricalDataModel current = validEntries[i];

                                    string currentFanState = current.Data[IotDeviceDataHelper.PLANT_NAME]["fan"].Value<string>().ToLower();
                                    string previousFanState = previous.Data[IotDeviceDataHelper.PLANT_NAME]["fan"].Value<string>().ToLower();

                                    if (currentFanState != previousFanState)
                                    {
                                        StateChangedModel.State state;

                                        if (currentFanState == "off")
                                            state = StateChangedModel.State.Disabled;
                                        else
                                            state = StateChangedModel.State.Enabled;

                                        entries.Add(new StateChangedModel() { CurrentState = state, TimeStamp = current.TimeStamp });
                                    }

                                    previous = current;
                                }
                            }
                        }
                        break;

                    case StateTableType.Light:
                        {
                            List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                            foreach (HistoricalDataModel e in availableEvents)
                            {
                                if (e.Data[IotDeviceDataHelper.PLANT_NAME] != null)
                                {
                                    var lightToken = e.Data[IotDeviceDataHelper.PLANT_NAME]["light"];

                                    if (lightToken != null)
                                    {
                                        string val = lightToken.Value<string>().ToLower();

                                        if (val == "on" || val == "off")
                                            validEntries.Add(e);
                                    }
                                }
                            }
                            if (validEntries.Count > 0)
                            {
                                HistoricalDataModel previous = validEntries[0];

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    HistoricalDataModel current = validEntries[i];

                                    string currentAlarmState = current.Data[IotDeviceDataHelper.PLANT_NAME]["light"].Value<string>().ToLower();
                                    string previousAlarmState = previous.Data[IotDeviceDataHelper.PLANT_NAME]["light"].Value<string>().ToLower();

                                    if (currentAlarmState != previousAlarmState)
                                    {
                                        StateChangedModel.State state;

                                        if (currentAlarmState == "off")
                                            state = StateChangedModel.State.Disabled;
                                        else
                                            state = StateChangedModel.State.Enabled;

                                        entries.Add(new StateChangedModel() { CurrentState = state, TimeStamp = current.TimeStamp });
                                    }

                                    previous = current;
                                }
                            }
                        }
                        break;

                    case StateTableType.MotionSensor:
                        {
                            List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                            foreach (HistoricalDataModel e in availableEvents)
                            {
                                if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                {
                                    var lightToken = e.Data[IotDeviceDataHelper.SEC_NAME]["motionSensor"];

                                    if (lightToken != null)
                                    {
                                        string val = lightToken.Value<string>().ToLower();

                                        if (val == "1" || val == "0")
                                            validEntries.Add(e);
                                    }
                                }
                            }
                            if (validEntries.Count > 0)
                            {
                                HistoricalDataModel previous = validEntries[0];

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    HistoricalDataModel current = validEntries[i];

                                    string currentSensorState = current.Data[IotDeviceDataHelper.SEC_NAME]["motionSensor"].Value<string>().ToLower();
                                    string previousSensorState = previous.Data[IotDeviceDataHelper.SEC_NAME]["motionSensor"].Value<string>().ToLower();

                                    if (currentSensorState != previousSensorState)
                                    {
                                        StateChangedModel.State state;

                                        if (currentSensorState == "0")
                                            state = StateChangedModel.State.Triggered;
                                        else
                                            state = StateChangedModel.State.Idle;

                                        entries.Add(new StateChangedModel() { CurrentState = state, TimeStamp = current.TimeStamp });
                                    }

                                    previous = current;
                                }
                            }
                        }
                        break;

                    case StateTableType.DoorLock:
                        {
                            List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                            foreach (HistoricalDataModel e in availableEvents)
                            {
                                if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                {
                                    var doorToken = e.Data[IotDeviceDataHelper.SEC_NAME]["doorLock"];

                                    if (doorToken != null)
                                    {
                                        string val = doorToken.Value<string>().ToLower();

                                        if (val == "unlocked" || val == "locked")
                                            validEntries.Add(e);
                                    }
                                }
                            }
                            if (validEntries.Count > 0)
                            {
                                HistoricalDataModel previous = validEntries[0];

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    HistoricalDataModel current = validEntries[i];

                                    string currentSensorState = current.Data[IotDeviceDataHelper.SEC_NAME]["doorLock"].Value<string>().ToLower();
                                    string previousSensorState = previous.Data[IotDeviceDataHelper.SEC_NAME]["doorLock"].Value<string>().ToLower();

                                    if (currentSensorState != previousSensorState)
                                    {
                                        StateChangedModel.State state;

                                        if (currentSensorState == "locked")
                                            state = StateChangedModel.State.Locked;
                                        else
                                            state = StateChangedModel.State.Unlocked;

                                        entries.Add(new StateChangedModel() { CurrentState = state, TimeStamp = current.TimeStamp });
                                    }

                                    previous = current;
                                }
                            }
                        }
                        break;

                    case StateTableType.Door:
                        {
                            List<HistoricalDataModel> validEntries = new List<HistoricalDataModel>();
                            foreach (HistoricalDataModel e in availableEvents)
                            {
                                if (e.Data[IotDeviceDataHelper.SEC_NAME] != null)
                                {
                                    var doorToken = e.Data[IotDeviceDataHelper.SEC_NAME]["doorSensor"];

                                    if (doorToken != null)
                                    {
                                        string val = doorToken.Value<string>().ToLower();

                                        if (val == "closed" || val == "open")
                                            validEntries.Add(e);
                                    }
                                }
                            }
                            if (validEntries.Count > 0)
                            {
                                HistoricalDataModel previous = validEntries[0];

                                for (int i = 0; i < validEntries.Count; i++)
                                {
                                    HistoricalDataModel current = validEntries[i];

                                    string currentSensorState = current.Data[IotDeviceDataHelper.SEC_NAME]["doorSensor"].Value<string>().ToLower();
                                    string previousSensorState = previous.Data[IotDeviceDataHelper.SEC_NAME]["doorSensor"].Value<string>().ToLower();

                                    if (currentSensorState != previousSensorState)
                                    {
                                        StateChangedModel.State state;

                                        if (currentSensorState == "closed")
                                            state = StateChangedModel.State.Closed;
                                        else
                                            state = StateChangedModel.State.Open;

                                        entries.Add(new StateChangedModel() { CurrentState = state, TimeStamp = current.TimeStamp });
                                    }

                                    previous = current;
                                }
                            }
                        }
                        break;

                }
            }
            catch(Exception ex)
            {
                //An error occured while deserializing.
            }

            return entries;
        }

        /// <summary>
        /// Retrieves cached events for a certain device
        /// </summary>
        /// <param name="deviceName">The ID of the device</param>
        /// <returns>The 24h retained events</returns>
        private async Task<List<HistoricalDataModel>> GetEventsAsync(string deviceName)
        {   
            //Will store all available cached events from the IoT hub
            List<PartitionEvent> availableEvents = new List<PartitionEvent>();

            //Cannot do anything if there is no connection.
            if (!IotDeviceDataHelper.CheckConnection())
                return new List<HistoricalDataModel>();

            //Attempts to read cached events.
            try
            {
                //Client that will be used for reading.
                await using EventHubConsumerClient _consumerClient = new EventHubConsumerClient(EventHubConsumerClient.DefaultConsumerGroupName, IotDeviceDataHelper.ENDPOINT_CONNECTION_STRING);

                //Reads every event in the async collection. If no events are found after 3 seconds, break.
                await foreach (PartitionEvent partitionEvent in _consumerClient.ReadEventsAsync(
                    startReadingAtEarliestEvent: true, //Ensures all events are read
                    readOptions: new ReadEventOptions() { MaximumWaitTime=new TimeSpan(hours: 0, minutes: 0, seconds: 3)})) //Ensures it does not go on forever trying to read blank events.
                {
                    //Indicates the latest event has been found, stop listening for events.
                    if (partitionEvent.Data == null)
                        break;

                    //If it is valid, add it.
                    availableEvents.Add(partitionEvent);
                }
            }
            catch (TaskCanceledException e)
            {
                //Means task was cancelled by the passed (or default) CancellationToken
            }
            catch(Exception e)
            {
                //Return a blank list if any error occurred
                return new List<HistoricalDataModel>();
            }

            //Filters the data so that only the entries for this device are retrieved.
            return availableEvents.Select(e => new HistoricalDataModel(
                JsonConvert.DeserializeObject<JObject>(e.Data.EventBody.ToString()), e.Data.EnqueuedTime.UtcDateTime.ToLocalTime())).Where(e => 
                {
                    //The name of the device that sent this telemetry
                    var deviceId = e.Data["device"];

                    //Can't display data if the device is unknown
                    if (deviceId == null)
                        return false;

                    //Should only display values for the current device. Mixing devices would show misleading data.
                    return deviceId.Value<string>()==deviceName;

                }).ToList();
        }
    }
}
