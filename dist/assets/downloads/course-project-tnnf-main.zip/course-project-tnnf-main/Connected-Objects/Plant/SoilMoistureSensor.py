from sys import argv
from grove.adc import ADC
from time import *

class SoilMoistureSensor:
    def __init__(self):
        self.PIN_NUMBER = 4
        self.adc = ADC()

    def getSoilMoisturePercent(self):
        # Based on the 12 bit resolution
        MAX_VALUE = 4096
        raw_value = self.adc.read_raw(self.PIN_NUMBER)
        return format(100 -(raw_value * 100) / MAX_VALUE, '.2f')

    def printValue(self):
        print("SOIL MOISTURE: " + str(self.getSoilMoisturePercent()) + "%")
    
    def loop(self, interval):
        output = "Reading soil moisture with an interval of {} second(s)...\n"

        print(output.format(str(interval)))

        while True:
            try:
                self.printValue()
                sleep(interval)
            except KeyboardInterrupt:
                print("\nExiting...")
                exit()

def main():
    sensor = SoilMoistureSensor()

    interval = 1

    if len(argv) > 1:
        try:
            interval = int(argv[1])
            if interval <= 0:
                interval = 1
        except:
            print("ERROR: Interval must be an integer.")

    sensor.loop(interval)

if __name__ == '__main__':
    main()