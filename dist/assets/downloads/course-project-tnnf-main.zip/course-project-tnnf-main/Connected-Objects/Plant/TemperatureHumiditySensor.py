from sys import argv
from grove.grove_temperature_humidity_aht20 import GroveTemperatureHumidityAHT20 as AHT20
from argparse import *
from time import *

class TempHumSensor:
    def __init__(self):
        self.BUS_NUMBER = 4
        self.sensor = AHT20(bus=self.BUS_NUMBER)

    def getTemperature(self):
        newTemp, newHum = self.sensor.read()
        return format(newTemp, '.2f')

    def getHumidity(self):
        newTemp, newHum = self.sensor.read()
        return format(newHum, '.2f')

    def printValues(self):
        print("CURRENT TEMPERATURE: " + str(self.getTemperature()))
        print("CURRENT HUMIDITY: " + str(self.getHumidity()))
        print()

    def loop(self, interval):
        output = "Reading temperature and humidity with an interval of {} second(s)...\n"

        print(output.format(str(interval)))

        while True:
            try:
                self.printValues()
                sleep(interval)
            except KeyboardInterrupt:
                print("\nExiting...")
                exit()

def main():
    sensor = TempHumSensor()

    interval = 1

    if len(argv) > 1:
        try:
            interval = int(argv[1])
            if interval <= 0:
                interval = 1
        except:
            print("ERROR: Interval must be an integer.")

    sensor.loop(interval)

if __name__ == '__main__':
    main()