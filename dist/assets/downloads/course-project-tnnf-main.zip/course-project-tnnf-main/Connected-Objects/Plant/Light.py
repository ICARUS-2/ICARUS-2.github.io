from sys import argv
import time
import RPi.GPIO as GPIO

#=========================================LIGHT

class Light:
    def __init__(self):
        self.LED= RgbLed()
        self.state = False
        self.LED.setColorRGBs([0,0],[0,0],[0,0])
        # Current limitation of the Light class:
        # In order to keep track of the LED state,
        # The class resets the LED state to OFF upon instantiation.

    def activate(self):
        self.state = True
        self.LED.setColorRGBs([255,255],[255,255],[255,255])

    def deactivate(self):
        self.state = False
        self.LED.setColorRGBs([0,0],[0,0],[0,0])

    def isOn(self):
        return self.state

    def toggleState(self):
        if self.isOn():
            self.deactivate()
        else:
            self.activate()

    def printState(self):
        if self.isOn():
            print("Light state: ON")
        else:
            print("Light state: OFF")

    def loop(self):
        print("Press Enter to toggle the light state.")

        while True:
            try:
                input()
                self.toggleState()
                if self.isOn():
                    print("Light has been switched to ON")
                else:
                    print("Light has been switched to OFF")
            except KeyboardInterrupt:
                print("\nExiting...")
                exit()

#=========================================RGB LED

# A modified version of the rgb_led class from here:
# https://github.com/DexterInd/GrovePi/blob/master/Software/Python/grove_chainable_rgb_led/direct_serial_lib/chainable_rgb_direct.py

class RgbLed:	
	def __init__(self):
		GPIO.setwarnings(False)
		self.num_led= 2 # Given by teacher
		             
		GPIO.setmode(GPIO.BCM)  
		self.clk_pin= 16 # RX pin BCM
		self.data_pin= 17 # TX pin BCM 
		self.tv_nsec= 100
		GPIO.setup(self.clk_pin, GPIO.OUT)
		GPIO.setup(self.data_pin, GPIO.OUT)

	def sendByte(self,b):
		# print b
		for loop in range(8):
			GPIO.output(self.clk_pin,0)
			time.sleep(self.tv_nsec/1000000.0)
						
			if (b & 0x80) != 0:
				GPIO.output(self.data_pin,1)
			else:
				GPIO.output(self.data_pin,0)
			
			GPIO.output(self.clk_pin,1)
			time.sleep(self.tv_nsec/1000000.0)
			
			b <<= 1
			
	def sendColor(self,r, g, b):
		prefix = 0b11000000
		if (b & 0x80) == 0:
			prefix |= 0b00100000
		if (b & 0x40) == 0:	
			prefix |= 0b00010000
		if (g & 0x80) == 0:	
			prefix |= 0b00001000
		if (g & 0x40) == 0:	
			prefix |= 0b00000100
		if (r & 0x80) == 0:	
			prefix |= 0b00000010
		if (r & 0x40) == 0:	
			prefix |= 0b00000001
	
		self.sendByte(prefix)
		self.sendByte(b)
		self.sendByte(g)
		self.sendByte(r)
		
	def setColorRGBs(self,r,g,b):
		for i in range(4):
				self.sendByte(0)
		for i in range(self.num_led):
			self.sendColor(r[i], g[i], b[i])
		for i in range(4):
				self.sendByte(0)

#=========================================ENTRY POINT

def main():
    light = Light()
    
    if len(argv) > 1:
        if argv[1] == "light":
            light.printState()

    light.loop()

if __name__ == '__main__':
    main()