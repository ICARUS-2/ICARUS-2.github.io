from argparse import *
from grove.grove_temperature_humidity_aht20 import GroveTemperatureHumidityAHT20 as AHT20
from gpiozero import LED
from grove.adc import ADC
from os import getenv
from dotenv import load_dotenv
from azure.iot.device import IoTHubModuleClient, Message
from time import sleep
import RPi.GPIO as GPIO

#=========================================PLANT SUBSYSTEM

class PlantSubsystem:
    def __init__(self):
        load_dotenv()
        self.TempHumSensor = TempHumSensor()
        self.Fan = Fan()
        self.WaterLevelSensor = WaterLevelSensor()
        self.SoilMoistureSensor = SoilMoistureSensor()
        self.Light = Light()

    def getTelemetry(self):
        try:
            temperature = self.TempHumSensor.getTemperature()
            humidity = self.TempHumSensor.getHumidity()
        except:
            temperature = None
            humidity = None
        try:
            fanState = self.Fan.isOn()
        except:
            fanState = None
        try:
            waterLevel = self.WaterLevelSensor.getWaterLevelPercent()
        except:
            waterLevel = None
        try:
            soilMoisture = self.SoilMoistureSensor.getSoilMoisturePercent()
        except:
            soilMoisture = None
        try:
            lightState = self.Light.isOn()
        except: 
            lightState = None

        if fanState == True:
            fanState = "On"
        else:
            fanState = "Off"

        if lightState == True:
            lightState = "On"
        else:
            lightState = "Off"

        json = '{{"temperature": "{temperature}", "humidity": "{humidity}", "fan": "{fanState}", "waterLevel": "{waterLevel}", "soilMoisture": "{soilMoisture}", "light": "{lightState}"}}'.format(temperature=temperature, humidity=humidity, fanState=fanState, waterLevel=waterLevel, soilMoisture=soilMoisture, lightState=lightState)
        #payload = json.format(temperature, humidity, fanState, waterLevel, soilMoisture, lightState)

        return json


#=========================================FAN

class Fan:
    def __init__(self):
        self.PIN_NUMBER = 5
        self.fan = LED(self.PIN_NUMBER, initial_value=None)

    def activate(self):
        self.fan.on()

    def deactivate(self):
        self.fan.off()

    def isOn(self):
        return self.fan.is_active

    def toggleState(self):
        if self.fan.is_active:
            self.fan.off()
        else:
            self.fan.on()
    
    def printState(self):
        if self.fan.is_active:
            print("Fan state: On")
        else:
            print("Fan state: Off")

#=========================================TEMPERATURE & HUMIDITY

class TempHumSensor:
    def __init__(self):
        self.BUS_NUMBER = 4
        self.sensor = AHT20(bus=self.BUS_NUMBER)

    def getTemperature(self):
        newTemp, newHum = self.sensor.read()
        return format(newTemp, '.2f')

    def getHumidity(self):
        newTemp, newHum = self.sensor.read()
        return format(newHum, '.2f')

    def printValues(self):
        print("CURRENT TEMPERATURE: " + str(self.getTemperature()))
        print("CURRENT HUMIDITY: " + str(self.getHumidity()))
        print()

#=========================================SOIL MOISTURE

class SoilMoistureSensor:
    def __init__(self):
        self.PIN_NUMBER = 4
        self.adc = ADC()

    def getSoilMoisturePercent(self):
        # Based on the 12 bit resolution
        MAX_VALUE = 4096
        raw_value = self.adc.read_raw(self.PIN_NUMBER)
        return format(100 -(raw_value * 100) / MAX_VALUE, '.2f')

    def printValue(self):
        print("SOIL MOISTURE: " + str(self.getSoilMoisturePercent()) + "%")

#=========================================WATER LEVEL

class WaterLevelSensor:
    def __init__(self):
        self.PIN_NUMBER = 2
        self.adc = ADC()

    def getWaterLevelPercent(self):
        # Based on the 12 bit resolution
        MAX_VALUE = 4096
        raw_value = self.adc.read_raw(self.PIN_NUMBER)
        return format((raw_value * 100) / MAX_VALUE, '.2f')
    
    def printValue(self):
        print("WATER LEVEL: " + str(self.getWaterLevelPercent()) + "%")

#=========================================LIGHT

class Light:
    def __init__(self):
        self.LED= RgbLed()
        self.state = False
        self.LED.setColorRGBs([0,0],[0,0],[0,0])
        # Current limitation of the Light class:
        # In order to keep track of the LED state,
        # The class resets the LED state to OFF upon instantiation.

    def activate(self):
        self.state = True
        self.LED.setColorRGBs([255,255],[255,255],[255,255])

    def deactivate(self):
        self.state = False
        self.LED.setColorRGBs([0,0],[0,0],[0,0])

    def isOn(self):
        return self.state

    def toggleState(self):
        if self.isOn():
            self.deactivate()
        else:
            self.activate()

    def printState(self):
        if self.isOn():
            print("Light state: On")
        else:
            print("Light state: Off")

    def loop(self):
        print("Press Enter to toggle the light state.")

        while True:
            try:
                input()
                self.toggleState()
                if self.isOn():
                    print("Light has been switched to On")
                else:
                    print("Light has been switched to Off")
            except KeyboardInterrupt:
                print("\nExiting...")
                exit()

#=========================================RGB LED

# A modified version of the rgb_led class from here:
# https://github.com/DexterInd/GrovePi/blob/master/Software/Python/grove_chainable_rgb_led/direct_serial_lib/chainable_rgb_direct.py

class RgbLed:	
	def __init__(self):
		GPIO.setwarnings(False)
		self.num_led= 2 # Given by teacher
		             
		GPIO.setmode(GPIO.BCM)  
		self.clk_pin= 16 # RX pin BCM
		self.data_pin= 17 # TX pin BCM 
		self.tv_nsec= 100
		GPIO.setup(self.clk_pin, GPIO.OUT)
		GPIO.setup(self.data_pin, GPIO.OUT)

	def sendByte(self,b):
		# print b
		for loop in range(8):
			GPIO.output(self.clk_pin,0)
			sleep(self.tv_nsec/1000000.0)
						
			if (b & 0x80) != 0:
				GPIO.output(self.data_pin,1)
			else:
				GPIO.output(self.data_pin,0)
			
			GPIO.output(self.clk_pin,1)
			sleep(self.tv_nsec/1000000.0)
			
			b <<= 1
			
	def sendColor(self,r, g, b):
		prefix = 0b11000000
		if (b & 0x80) == 0:
			prefix |= 0b00100000
		if (b & 0x40) == 0:	
			prefix |= 0b00010000
		if (g & 0x80) == 0:	
			prefix |= 0b00001000
		if (g & 0x40) == 0:	
			prefix |= 0b00000100
		if (r & 0x80) == 0:	
			prefix |= 0b00000010
		if (r & 0x40) == 0:	
			prefix |= 0b00000001
	
		self.sendByte(prefix)
		self.sendByte(b)
		self.sendByte(g)
		self.sendByte(r)
		
	def setColorRGBs(self,r,g,b):
		for i in range(4):
				self.sendByte(0)
		for i in range(self.num_led):
			self.sendColor(r[i], g[i], b[i])
		for i in range(4):
				self.sendByte(0)

#=========================================ENTRY POINT

def main():
    subsystem = PlantSubsystem()

    parser = ArgumentParser()
    parser.add_argument("--temp_humi", help="To measure temperature and humidity.", action="store_true")
    parser.add_argument("--fan", help="To read fan state (on/off).", action="store_true")
    parser.add_argument("--set_fan", help="To control fan state (on/off).")
    parser.add_argument("--water", help="To measure relative water levels.", action="store_true")
    parser.add_argument("--moisture", help="To measure soil moisture levels.", action="store_true")
    parser.add_argument("--light", help="To read light state (on/off).", action="store_true")
    parser.add_argument("--set_light", help="To control light state (on/off).")

    args = parser.parse_args()

    if args.temp_humi:
        subsystem.TempHumSensor.printValues()

    if args.fan:
        # This will always print OFF.
        # Due to fan state not persisted in command line.
        # For example, not the case inside Fan.main()
        subsystem.Fan.printState()

    if args.set_fan:
        if args.set_fan == "on":
            subsystem.Fan.activate()
        if args.set_fan == "off":
            subsystem.Fan.deactivate()
            # The fan starts immediately after the command.
            # This delay is just enough time for the fan to halt.
            sleep(1)

    if args.water:
        subsystem.WaterLevelSensor.printValue()

    if args.moisture:
        subsystem.SoilMoistureSensor.printValue()

    if args.light:
        # Due to design limitations,
        # This will always print OFF.
        # Same reason as fan class + 1 more reason.
        # See Light class for details.
        subsystem.Light.printState()

    if args.set_light:
        if args.set_light == "on":
            subsystem.Light.activate()
        if args.set_light == "off":
            subsystem.Light.deactivate()

if __name__ == '__main__':
    main()