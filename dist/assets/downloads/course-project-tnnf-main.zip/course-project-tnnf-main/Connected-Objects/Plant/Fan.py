from sys import argv
from gpiozero import LED

class Fan:
    def __init__(self):
        self.PIN_NUMBER = 5
        self.fan = LED(self.PIN_NUMBER, initial_value=None)

    def activate(self):
        self.fan.on()

    def deactivate(self):
        self.fan.off()

    def isOn(self):
        return self.fan.is_active

    def toggleState(self):
        if self.fan.is_active:
            self.fan.off()
        else:
            self.fan.on()

    def printState(self):
        if self.fan.is_active:
            print("Fan state: ON")
        else:
            print("Fan state: OFF")

    def loop(self):
        print("Press Enter to toggle the fan state.")

        while True:
            try:
                input()
                self.toggleState()
                if self.fan.is_active:
                    print("Fan has been switched to ON")
                else:
                    print("Fan has been switched to OFF")
            except KeyboardInterrupt:
                print("\nExiting...")
                exit()

def main():
    fan = Fan()
    
    if len(argv) > 1:
        if argv[1] == "fan":
            fan.printState()

    fan.loop()

if __name__ == '__main__':
    main()