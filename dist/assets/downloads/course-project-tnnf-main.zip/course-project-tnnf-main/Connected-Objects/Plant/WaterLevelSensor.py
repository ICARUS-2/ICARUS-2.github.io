from sys import argv
from grove.adc import ADC
from time import *

class WaterLevelSensor:
    def __init__(self):
        self.PIN_NUMBER = 2
        self.adc = ADC()

    def getWaterLevelPercent(self):
        # Based on the 12 bit resolution
        MAX_VALUE = 4096
        raw_value = self.adc.read_raw(self.PIN_NUMBER)
        return format((raw_value * 100) / MAX_VALUE, '.2f')

    def printValue(self):
        print("WATER LEVEL: " + str(self.getWaterLevelPercent()) + "%")
    
    def loop(self, interval):
        output = "Reading water level with an interval of {} second(s)...\n"

        print(output.format(str(interval)))

        while True:
            try:
                self.printValue()
                sleep(interval)
            except KeyboardInterrupt:
                print("\nExiting...")
                exit()

def main():
    sensor = WaterLevelSensor()

    interval = 1

    if len(argv) > 1:
        try:
            interval = int(argv[1])
            if interval <= 0:
                interval = 1
        except:
            print("ERROR: Interval must be an integer.")

    sensor.loop(interval)

if __name__ == '__main__':
    main()