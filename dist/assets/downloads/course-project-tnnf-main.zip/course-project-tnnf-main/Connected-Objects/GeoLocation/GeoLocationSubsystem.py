import math
import time
import serial
import pynmea2
from dotenv import dotenv_values
import seeed_python_reterminal.core as rt;
import seeed_python_reterminal.acceleration as accel
from azure.iot.device import Message, IoTHubModuleClient

import argparse

class GeoLocationSubSystem:
    def __init__(self) -> None:
        self.secrets = dotenv_values()
        self.Alarm = GeoLocationAlarm()
        self.AngleSensor = GeoLocationAngleSensor()
        self.VibrationSensor = GeoLocationVibrationSensor()
        self.GPSSensor = GeoLocationGPSSensor()

    def getTelemetry(self):
        try:
            alarmState = self.Alarm.getValue()
        except:
            alarmState = None

        try:
            self.AngleSensor.UpdateAxis()
            rollAngle = self.AngleSensor.getRoll()
            pitchAngle = self.AngleSensor.getPitch()
            vibrationLevel = self.VibrationSensor.getVibrationLevel()
        except:
            rollAngle = None
            pitchAngle = None
            vibrationLevel = None

        gpsdata = self.GPSSensor.readGPSData()
        latitude = gpsdata['Latitude']
        longitude = gpsdata['Longitude']

        formattedText = f'{{ "alarm" : "{alarmState}", "rollAngle" : "{rollAngle}", "pitchAngle" : "{pitchAngle}", "vibration": "{vibrationLevel}", "latitude" : "{latitude}", "longitude": "{longitude}"}}'

        return formattedText

def main():
    geo = GeoLocationSubSystem()

    parser = argparse.ArgumentParser()

    parser.add_argument("--gps", help="To collect GPS location.", action="store_true")
    parser.add_argument("--angles", help="To read pitch and roll and banking angles.", action="store_true")
    parser.add_argument("--vibration", help="To read vibration levels.", action="store_true")
    parser.add_argument("--buzzer", help="To read buzzer state", action="store_true")
    parser.add_argument("--set_buzzer", help="To control buzzer state (on/off)")
    args = parser.parse_args()

    if args.gps:
        geo.GPSSensor.readGPSData(True)

    if args.angles:
        geo.AngleSensor.printAllMeasurements()

    if args.vibration:
        geo.VibrationSensor.getVibrationLevel(True)

    if args.buzzer:
        print("Buzzer state: " + geo.Alarm.getValue())
    
    if args.set_buzzer:
        if args.set_buzzer == "on":
            geo.Alarm.on()
        elif args.set_buzzer == "off":
            geo.Alarm.off()

# -------------------------------------- Alarm
class GeoLocationAlarm:
    def __init__(self):
        self.state = False
        rt.buzzer = False
        # Current limitation of the buzzer:
        # In order to distinguish between Security and GeoLocation alarm,
        # A logical state is read instead of the voltage.

    def on(self):
        self.state = True
        rt.buzzer = True

    def off(self):
        self.state = False
        rt.buzzer = False

    def pulse(self, delay = 1):
        rt.buzzer = True
        time.sleep(delay)
        rt.buzzer = False

    def getValue(self):
        if (self.state):
            return "On"
        return "Off"

# -------------------------------------- GPS
# Basically based on Mauricio's code
class GeoLocationGPSSensor:
    # Readies serial port
    serial = serial.Serial('/dev/ttyAMA0', 9600, timeout=1)
    serial.reset_input_buffer()
    serial.flush()

    # Helpful constants for parsing gps data from UART
    ENCODE_TYPE = 'utf-8'
    TARGET_SENTENCE_TYPE = 'GGA'
    LATDIR_COMPENSATION_FLAG = 'S'
    LONDIR_COMPENSATION_FLAG = 'W'

    def parseGPSData(self, line, verbose = False):
        msg = pynmea2.parse(line)

        # If data is of expected type:
        if msg.sentence_type == self.TARGET_SENTENCE_TYPE:
            # Gets and sets lon and lat based off of line data
            lat = pynmea2.dm_to_sd(msg.lat)
            lon = pynmea2.dm_to_sd(msg.lon)

            # Condintions for compensating for gps directions that are not expected.
            if msg.lat_dir == self.LATDIR_COMPENSATION_FLAG:
                lat = lat * -1

            if msg.lon_dir == self.LONDIR_COMPENSATION_FLAG:
                lon = lon * -1
                
            if verbose:
                print(f'Latitude: {lat}, Longitude: {lon}')
            #  lat, lon#, msg.num_sats
            return {"Latitude": lat, "Longitude": lon}

    # Reads and returns the gps data
    def readGPSData(self, verbose = False):
        while True:
            try:
                line = self.serial.readline().decode(self.ENCODE_TYPE)
                if line == '':
                    return {"Latitude": None, "Longitude": None}
                while len(line) > 0:
                    values = self.parseGPSData(line, verbose)
                    if values != None:
                        return values
                    line = self.serial.readline().decode(self.ENCODE_TYPE)
            # Failing to read is expected, but will try again until data is read or doesn't exist.
            except UnicodeDecodeError:
                print("Error in decoding gps coordinate data.")
                self.serial.readline()
            except pynmea2.ParseError:
                print("Error with parsing gps data from string.")
                self.serial.readline()

# -------------------------------------- Angles
class GeoLocationAngleSensor:

    accelerometer = rt.get_acceleration_device()

    X_AXIS = 'X'
    Y_AXIS = 'Y'
    Z_AXIS = 'Z'

    latest_accel = None

    def __init__(self):
        self.latest_accel = self.UpdateAxis()

    # Required Mauricio's help to improve the latency/effeciency
    def UpdateAxis(self):
        AllAxis = {
            GeoLocationAngleSensor.X_AXIS: None,
            GeoLocationAngleSensor.Y_AXIS: None,
            GeoLocationAngleSensor.Z_AXIS: None,
        }
        for event in self.accelerometer.read_loop():
            accelEvent = accel.AccelerationEvent(event)

            if accelEvent.name:
                AllAxis[accelEvent.name.name] = accelEvent.value
                
            if AllAxis[GeoLocationAngleSensor.X_AXIS] and AllAxis[GeoLocationAngleSensor.Y_AXIS] and AllAxis[GeoLocationAngleSensor.Z_AXIS] :
                self.latest_accel = AllAxis
                break
        return AllAxis

    # Based on code made by mauricio
    def calculateAngles(self, axisName):
        accelData = self.latest_accel
        bufferAxis = self.latest_accel[axisName]
        xBuffer = accelData[self.X_AXIS]
        yBuffer = accelData[self.Y_AXIS]
        zBuffer = accelData[self.Z_AXIS]
        return math.degrees(math.asin(bufferAxis / (math.sqrt((xBuffer * xBuffer) + (yBuffer * yBuffer) + (zBuffer * zBuffer)))))

    # Modified pitch calculation based on:  
    # https://mwrona.com/posts/accel-roll-pitch/
    def getRoll(self):
        return self.calculateAngles(self.X_AXIS)

    # Pitch calculation based on:
    # https://mwrona.com/posts/accel-roll-pitch/
    def getPitch(self):
        return self.calculateAngles(self.Y_AXIS)

    def printAllMeasurements(self):
        axis = self.latest_accel
        print('X-Axis: ' + str(axis[self.X_AXIS]))
        print('Y-Axis: ' + str(axis[self.Y_AXIS]))
        print('Z-Axis: ' + str(axis[self.Z_AXIS]))
        print('Roll: ' + str(self.getRoll()))
        print('Pitch: ' + str(self.getPitch()))

# -------------------------------------- Vibration
class GeoLocationVibrationSensor:
    sensor = GeoLocationAngleSensor()

    X_AXIS = 'X'
    Y_AXIS = 'Y'
    Z_AXIS = 'Z'

    def getVibrationLevel(self, verbose = False):
        previousVibeLevel = self.sensor.latest_accel
        previousVibeLevel = previousVibeLevel[self.X_AXIS] + previousVibeLevel[self.Y_AXIS] + previousVibeLevel[self.Y_AXIS]
        time.sleep(0.1)
        currentVibeLevel = self.sensor.UpdateAxis()
        currentVibeLevel = currentVibeLevel[self.X_AXIS] + currentVibeLevel[self.Y_AXIS] + currentVibeLevel[self.Y_AXIS]
        if verbose:
            print("Vibration Level:" + abs(previousVibeLevel - currentVibeLevel))
        return abs(previousVibeLevel - currentVibeLevel)

if (__name__ == "__main__"):
    main()