from gpiozero import Button
from gpiozero import Servo
from grove.grove_loudness_sensor import GroveLoudnessSensor
from grove.grove_mini_pir_motion_sensor import GroveMiniPIRMotionSensor
from gpiozero.pins.pigpio import PiGPIOFactory
import seeed_python_reterminal.core as rt
import time
import argparse

class SecuritySubsystem:
    def __init__(self) -> None:
        self.Alarm = SecurityAlarm()
        self.DoorLock = SecurityDoorLock()
        self.DoorSensor = SecurityDoorSensor()
        self.NoiseSensor = SecurityNoiseSensor()
        self.MotionSensor = SecurityMotionSensor()
        self.LightSensor = SecurityLightSensor()


    def getTelemetry(self):
        try:
            alarmState = self.Alarm.getValue()
        except:
            alarmState = None

        try:
            doorLockState = self.DoorLock.getState()
        except:
            doorLockState = None

        try:
            doorSensorState = self.DoorSensor.getState()
        except:
            doorSensorState = None

        try:
            noiseSensorValue = self.NoiseSensor.getValue()
        except:
            noiseSensorValue = None

        try:
            motionSensorState = self.MotionSensor.getValue()
        except:
            motionSensorState = None

        try:
            lightLevel = self.LightSensor.getLightLevel()
        except:
            lightLevel = None

        formattedText = '{{ "alarm" : "{alarmState}", "doorLock" : "{doorLockState}", "doorSensor" : "{doorSensorState}", "noiseSensor": "{noiseSensorValue}", "motionSensor" : "{motionSensorState}", "lightSensor": "{lightLevel}"}}'.format(alarmState = alarmState, doorLockState = doorLockState, doorSensorState = doorSensorState, noiseSensorValue = noiseSensorValue, motionSensorState = motionSensorState, lightLevel = lightLevel)

        return formattedText

def main():

    sec = SecuritySubsystem()

    parser = argparse.ArgumentParser()
    parser.add_argument("--noise", help="To read noise levels.", action="store_true")
    parser.add_argument("--lumi", help="To read luminosity levels", action="store_true")
    parser.add_argument("--motion", help="To read motion sensor state", action="store_true")
    parser.add_argument("--lock", help ="To read door lock state", action="store_true")
    parser.add_argument("--set_lock", help="To control door lock state (open/closed)" )
    parser.add_argument("--buzzer", help="To read buzzer state", action="store_true")
    parser.add_argument("--set_buzzer", help="To control buzzer state (on/off)")
    parser.add_argument("--door", help="To read door state", action="store_true")

    args = parser.parse_args()

    if (args.noise):
        print("Reading noise: " + str(sec.NoiseSensor.getValue()))

    if (args.lumi):
        print("Reading luminosity: " + str(sec.LightSensor.getLightLevel()))

    if (args.motion):
        print("Reading motion: " + str(sec.MotionSensor.getValue()))

    if (args.lock):
        print("Lock state: " + sec.DoorLock.getState())

    if (args.set_lock):
        if (args.set_lock == "open"):
            sec.DoorLock.unlock()
        elif (args.set_lock == "closed"):
            print("CLOSING")
            sec.DoorLock.lock()

    if (args.buzzer):
        print("Buzzer state: " +sec.Alarm.getValue() )
    
    if (args.set_buzzer):
        if (args.set_buzzer == "on"):
            sec.Alarm.on()
        elif (args.set_buzzer == "off"):
            sec.Alarm.off()

    if (args.door):
        print("Door state: " + sec.DoorSensor.getState())
        
#=========================================SECURITY ALARM

class SecurityAlarm:
    def __init__(self):
        self.state = False
        rt.buzzer = False
        # Current limitation of the buzzer:
        # In order to distinguish between Security and GeoLocation alarm,
        # A logical state is read instead of the voltage.

    def on(self):
        self.state = True
        rt.buzzer = True

    def off(self):
        self.state = False
        rt.buzzer = False

    def pulse(self, delay = 1):
        rt.buzzer = True
        time.sleep(delay)
        rt.buzzer = False

    def getValue(self):
        if (self.state):
            return "On"
        return "Off"

#=========================================DOOR LOCK

class SecurityDoorLock:
    LOCK_VAL = -1
    UNLOCK_VAL = 1

    LOCKED = "Locked"
    UNLOCKED = "Unlocked"
    INVALID_STATE = "Invalid state"
    
    def __init__(self, lock=True):
        self.__factory__ = PiGPIOFactory('127.0.0.1')
        self.__servo__ = Servo(12, min_pulse_width=0.5/1000, max_pulse_width=2.5/1000, pin_factory=self.__factory__)

        if (lock):
            self.lock()
        else:    
            self.unlock()

    def unlock(self):
        self.__servo__.max()

    def lock(self):
        self.__servo__.min()

    def getState(self):
        if self.__servo__.value == 1:
            return SecurityDoorLock.UNLOCKED
        elif self.__servo__.value == -1:
            return SecurityDoorLock.LOCKED
        else:
            return SecurityDoorLock.INVALID_STATE

#=========================================DOOR SENSOR
class SecurityDoorSensor:
    DEFAULT_PIN = 24

    def __init__(self, pin = DEFAULT_PIN):
        self.__button__ = Button(pin)

    def getState(self):
        if (self.__button__.is_pressed):
            return "closed"
        return "open"

#=========================================LIGHT SENSOR
class SecurityLightSensor:
    def getLightLevel(self):
        return rt.illuminance

#=========================================MOTION SENSOR
class SecurityMotionSensor(object):
    DEFAULT_PIN = 22

    @staticmethod
    def __default_callback__():
        print("MOTION SENSOR ACTIVATED")


    def __init__(self, pin=DEFAULT_PIN):
        self.__sensor__ = GroveMiniPIRMotionSensor(pin)
        self.__sensor__.on_detect = SecurityMotionSensor.__default_callback__

    def set_callback(self, function):
        self.__sensor__.on_detect = function

    def getValue(self):
        return self.__sensor__.read()

#=========================================NOISE SENSOR
class SecurityNoiseSensor:
    DEFAULT_PIN = 0

    def __init__(self, pin = DEFAULT_PIN):
        self.__sensor__ = GroveLoudnessSensor(pin)

    def getValue(self):
        try:
            return str(self.__sensor__.value / 10)
        except:
            return "0"

if __name__ == "__main__":
    main()
