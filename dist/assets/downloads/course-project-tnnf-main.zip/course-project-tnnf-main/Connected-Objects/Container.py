from Security.SecuritySubsystem import SecuritySubsystem
from GeoLocation.GeoLocationSubsystem import GeoLocationSubSystem
from Plant.PlantSubsystem import PlantSubsystem
from azure.iot.device import Message, IoTHubModuleClient
from time import sleep 
import os
import json
from dotenv import load_dotenv

class Container:
    def __init__(self):
        load_dotenv()
        Container.Interval = 10

        self.Security = SecuritySubsystem()
        self.GeoLocation = GeoLocationSubSystem()
        self.Plant = PlantSubsystem()
        self.__deviceConnectionString__ = os.getenv("IOTHUB_DEVICE_CONNECTION_STRING")
        self.DeviceId = self.getDeviceIdFromConnectionString()

        self.__module_client__ = IoTHubModuleClient.create_from_connection_string(self.__deviceConnectionString__)
        # Set handlers on the client
        def twin_patch_handler(twin_patch):
            print("Twin patch received:")
            print(twin_patch)

            newObj = {}

            for key in twin_patch:
                if (key == "containerData"):
                    Container.Interval = int(twin_patch[key]["telemetryInterval"])

                # PLANT SUBSYSTEM ACTUATORS
                if key == "plant":
                    plantObject = twin_patch["plant"]

                    if "fan" in plantObject:
                        fanState = plantObject["fan"]
                        if fanState == "ON":
                            try:
                                self.Plant.Fan.activate()
                            except:
                                print("Fan disconnected, could not activate.")
                        elif fanState == "OFF":
                            try:
                                self.Plant.Fan.deactivate()
                            except:
                                print("Fan disconnected, could not deactivate.")

                    if "light" in plantObject:
                        lightState = plantObject["light"]
                        if lightState == "ON":
                            try:
                                self.Plant.Light.activate()
                            except:
                                print("Light disconnected, could not activate.")
                        elif lightState == "OFF":
                            try:
                                self.Plant.Light.deactivate()
                            except:
                                print("Light disconnected, could not deactivate.")

                # GEOLOCATION SUBSYSTEM ACTUATORS
                if key == "geolocation":
                    geolocationObject = twin_patch["geolocation"]

                    if "alarm" in geolocationObject:
                        alarmState = geolocationObject["alarm"]
                        if alarmState == "On":
                            try:
                                if self.Security.Alarm.getValue() == "Off":
                                    self.GeoLocation.Alarm.on()
                                elif self.Security.Alarm.getValue() == "On":
                                    self.GeoLocation.Alarm.state = True
                            except:
                                print("Buzzer disconnected, could not activate.")
                        elif alarmState == "Off":
                            try:
                                if self.Security.Alarm.getValue() == "Off":
                                    self.GeoLocation.Alarm.off()
                                elif self.Security.Alarm.getValue() == "On":
                                    self.GeoLocation.Alarm.state = False
                            except:
                                print("Buzzer disconnected, could not deactivate.")

                # SECURITY SUBSYSTEM ACTUATORS
                if key == "security":
                    securityObject = twin_patch["security"]

                    if "alarm" in securityObject:
                        alarmState = securityObject["alarm"]
                        if alarmState == "On":
                            try:
                                if self.GeoLocation.Alarm.getValue() == "Off":
                                    self.Security.Alarm.on()
                                elif self.GeoLocation.Alarm.getValue() == "On":
                                    self.Security.Alarm.state = True
                            except:
                                print("Buzzer disconnected, could not activate.")
                        elif alarmState == "Off":
                            try:
                                if self.GeoLocation.Alarm.getValue() == "Off":
                                    self.Security.Alarm.off()
                                elif self.GeoLocation.Alarm.getValue() == "On":
                                    self.Security.Alarm.state = False
                            except:
                                print("Buzzer disconnected, could not deactivate.")

                    if "doorLock" in securityObject:
                        lockState = securityObject["doorLock"]
                        if lockState == "Locked":
                            try:
                                self.Security.DoorLock.lock()
                            except:
                                print("Lock disconnected, could not lock.")
                        elif lockState == "Unlocked":
                            try:
                                self.Security.DoorLock.unlock()
                            except:
                                print("Lock disconnected, could not unlock.")
                
                if not key.startswith('$'):
                    newObj[key] = twin_patch[key]

                self.__module_client__.patch_twin_reported_properties(newObj)

        self.__module_client__.on_twin_desired_properties_patch_received = twin_patch_handler

    def sendTelemetry(self):
        plantTelem = self.Plant.getTelemetry()
        geoTelem = self.GeoLocation.getTelemetry()
        secTelem = self.Security.getTelemetry()

        formattedText = '{{ "plant": {plant}, "geolocation":{geolocation}, "security":{security}, "device":"{device}" }}'.format(plant=plantTelem, geolocation=geoTelem, security=secTelem, device=self.DeviceId)
        msg = Message(formattedText)
        self.__module_client__.patch_twin_reported_properties(json.loads(formattedText))

        print(msg)
        self.__module_client__.send_message(msg)

    def sendTelemetryLooping(self):
        try:
            while True:
                self.sendTelemetry()
                sleep(Container.Interval)
        except KeyboardInterrupt:
            print("\nStopping...")
            exit()

    def getDeviceIdFromConnectionString(self):
        splitString = self.__deviceConnectionString__.split(";")
        kvPair = splitString[1]
        return kvPair.split("=")[1]

def main():
    container = Container()
    container.sendTelemetryLooping()
    
if (__name__ == "__main__"):
    main() 